"use client";

import { API_BASE } from "@/app/lib/config";

import { useState, useEffect, useRef, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { ShieldCheck, Activity, Database, CheckCircle2, Lock, User, Terminal, Phone, Fingerprint } from "lucide-react";
import clsx from "clsx";

/* ─── Face Scanner Component ──────────────────────────────────────────────── */
const FaceScanner = ({ state }: { state: "idle" | "scanning" | "success" | "rejected" }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCamera, setHasCamera] = useState(false);

  useEffect(() => {
    let streamRef: MediaStream | null = null;
    
    const startCamera = async () => {
      try {
        if (state !== "idle" && !hasCamera && navigator.mediaDevices) {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            setHasCamera(true);
            streamRef = stream;
          }
        }
      } catch (err) {
        console.warn("Camera access denied or unavailable", err);
      }
    };

    startCamera();

    return () => {
      if (streamRef) {
        streamRef.getTracks().forEach(track => track.stop());
      }
    };
  }, [state, hasCamera]);

  return (
    <div className={clsx(
      "relative w-48 h-48 mx-auto mb-6 bg-black/60 overflow-hidden transition-all duration-700",
      state === "idle" ? "opacity-0 scale-95 pointer-events-none absolute" : "opacity-100 scale-100",
      state === "scanning" && "shadow-[0_0_30px_rgba(6,182,212,0.15)]",
      state === "success"  && "shadow-[0_0_30px_rgba(16,185,129,0.2)]",
      state === "rejected" && "shadow-[0_0_30px_rgba(239,68,68,0.2)]"
    )}>
      {/* Video Feed */}
      <video 
        ref={videoRef} 
        autoPlay playsInline muted 
        className={clsx(
          "absolute inset-0 w-full h-full object-cover transition-all duration-1000",
          !hasCamera && "hidden",
          state === "success" ? "sepia-[0.5] hue-rotate-90" : 
          state === "rejected" ? "sepia-[0.8] hue-rotate-[-50deg]" : "grayscale opacity-70"
        )} 
      />
      
      {/* Fallback Grid & Overlay */}
      <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-30 bg-[length:16px_16px] mix-blend-overlay" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-900/10 to-transparent" />

      {/* Target Reticle */}
      {state === "scanning" && (
        <div className="absolute inset-0 flex items-center justify-center opacity-30">
          <div className="w-24 h-24 border border-cyan-400 rounded-full animate-[spin_4s_linear_infinite] border-dashed" />
          <div className="absolute w-16 h-16 border border-cyan-300 rounded-full animate-[spin_3s_linear_infinite_reverse]" />
        </div>
      )}

      {/* Scanning Sweep Line */}
      {state === "scanning" && (
        <div className="absolute left-0 right-0 h-[2px] bg-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.9)] opacity-80 z-10"
             style={{ animation: "scanSweep 2s ease-in-out infinite" }} />
      )}

      {/* Frame Corners */}
      <div className={clsx("absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 transition-colors duration-500", 
        state === "scanning" ? "border-cyan-400" : state === "success" ? "border-emerald-400" : state === "rejected" ? "border-red-500" : "border-white/20")} />
      <div className={clsx("absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 transition-colors duration-500", 
        state === "scanning" ? "border-cyan-400" : state === "success" ? "border-emerald-400" : state === "rejected" ? "border-red-500" : "border-white/20")} />
      <div className={clsx("absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 transition-colors duration-500", 
        state === "scanning" ? "border-cyan-400" : state === "success" ? "border-emerald-400" : state === "rejected" ? "border-red-500" : "border-white/20")} />
      <div className={clsx("absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 transition-colors duration-500", 
        state === "scanning" ? "border-cyan-400" : state === "success" ? "border-emerald-400" : state === "rejected" ? "border-red-500" : "border-white/20")} />

      {/* Result Icons */}
      {state === "success" && (
        <div className="absolute inset-0 flex items-center justify-center bg-emerald-950/40 backdrop-blur-sm z-20 animate-[fadeIn_0.5s_ease-out]">
          <CheckCircle2 className="w-12 h-12 text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
        </div>
      )}
      {state === "rejected" && (
        <div className="absolute inset-0 flex items-center justify-center bg-red-950/60 backdrop-blur-sm z-20 animate-[fadeIn_0.5s_ease-out]">
          <Lock className="w-10 h-10 text-red-400 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]" />
        </div>
      )}
    </div>
  );
};

/* ─── State Status Text ───────────────────────────────────────────────────── */
const STATUS_STEPS: Record<string, string[]> = {
  scanning: [
    "Identity Verified", 
    "Initiating Biometric Scan...", 
    "Biometric Match Confirmed", 
    "Security Check Running", 
    "Finalizing Access"
  ],
  success:  ["Authentication Complete.", "Access Granted."],
  rejected: ["Biometric Match Failed.", "Access Denied."],
};

function LoginForm() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const roleParam    = searchParams.get("role") || "doctor";

  const [role,        setRole]        = useState(roleParam);
  const [mode,        setMode]        = useState<"login" | "register">("login");
  const [username,    setUsername]    = useState("");
  const [password,    setPassword]    = useState("");
  const [fullName,    setFullName]    = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [orgName,     setOrgName]     = useState("");
  const [error,       setError]       = useState<string | null>(null);
  const [success,     setSuccess]     = useState<string | null>(null);
  const [loading,     setLoading]     = useState(false);

  // Cinematic state machine
  const [scanState,   setScanState]   = useState<"idle" | "scanning" | "success" | "rejected">("idle");
  const [statusText,  setStatusText]  = useState("");
  const [rejected,    setRejected]    = useState(false); // triggers rejection animation

  const formRef = useRef<HTMLDivElement>(null);

  const needsPhone = role === "patient";
  const needsOrg   = ["insurer", "hospital", "pharma"].includes(role);

  /* ── Status text stepper ───────────────────────────────────────────── */
  const runStatusSteps = (key: string, delay = 600) => {
    const steps = STATUS_STEPS[key] || [];
    steps.forEach((text, i) => {
      setTimeout(() => setStatusText(text), i * delay);
    });
  };

  /* ── Rejection audio (low-frequency, non-harsh) ─────────────────── */
  const playRejectionSound = () => {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(180, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(80, ctx.currentTime + 0.6);
      gain.gain.setValueAtTime(0.35, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.85);
    } catch (_) {}
  };

  /* ── Login handler ─────────────────────────────────────────────────── */
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    setLoading(true);
    setError(null);
    setRejected(false);
    setScanState("scanning");
    runStatusSteps("scanning", 600);

    try {
      // Allow camera to initialize before capturing frame
      await new Promise(r => setTimeout(r, 1200));

      let webcam_image_base64 = undefined;
      const video = document.querySelector('video');
      if (video && video.readyState >= 2) { // HAVE_CURRENT_DATA or better
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          webcam_image_base64 = canvas.toDataURL('image/jpeg', 0.6);
        }
      }

      // Minimum remaining scan phase
      const [res] = await Promise.all([
        fetch(`${API_BASE}/api/auth/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password, webcam_image_base64 }),
        }),
        new Promise(r => setTimeout(r, 1800)),
      ]);

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.detail || "Authentication failed");
      }

      const data = await res.json();
      setScanState("success");
      runStatusSteps("success", 700);
      localStorage.setItem("mg_token", data.token);
      await new Promise(r => setTimeout(r, 1200));
      router.push(`/dashboard/${role}`);

    } catch (err: any) {
      // Cinematic rejection sequence
      setScanState("rejected");
      runStatusSteps("rejected", 600);
      setRejected(true);
      playRejectionSound();

      // Red pulse from center
      await new Promise(r => setTimeout(r, 1400));
      setScanState("idle");
      setStatusText("");
      setRejected(false);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  /* ── Register handler ─────────────────────────────────────────────── */
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    setLoading(true);
    setError(null);
    setSuccess(null);
    setScanState("scanning");
    runStatusSteps("scanning", 600);

    try {
      const body: any = { username, password, full_name: fullName, role };
      if (needsPhone) body.phone_number = phoneNumber;
      if (needsOrg)   body.organization_name = orgName;

      const [res] = await Promise.all([
        fetch(`${API_BASE}/api/auth/register`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        }),
        new Promise(r => setTimeout(r, 2200)),
      ]);

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.detail || "Registration failed");
      }

      const data = await res.json();
      setScanState("success");
      runStatusSteps("success", 700);
      localStorage.setItem("mg_token", data.token);

      if (data.patient_code) {
        setSuccess(`Registered. Patient Code: ${data.patient_code}`);
        await new Promise(r => setTimeout(r, 3000));
      } else {
        await new Promise(r => setTimeout(r, 1200));
      }

      router.push(`/dashboard/${role}`);

    } catch (err: any) {
      setScanState("rejected");
      runStatusSteps("rejected", 600);
      setRejected(true);
      playRejectionSound();
      await new Promise(r => setTimeout(r, 1400));
      setScanState("idle");
      setStatusText("");
      setRejected(false);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const roleConfig = {
    doctor:  { icon: Activity,      color: "text-mg-primary",   accent: "rgba(6,182,212,0.08)" },
    insurer: { icon: Database,      color: "text-mg-glow",      accent: "rgba(56,189,248,0.08)" },
    patient: { icon: CheckCircle2,  color: "text-emerald-400",  accent: "rgba(16,185,129,0.08)" },
    hospital:{ icon: ShieldCheck,   color: "text-amber-500",    accent: "rgba(245,158,11,0.08)" },
    pharma:  { icon: Database,      color: "text-purple-400",   accent: "rgba(168,85,247,0.08)" },
  };
  const Config = roleConfig[role as keyof typeof roleConfig] || roleConfig.doctor;

  return (
    <div
      className="min-h-screen bg-mg-bg text-white flex flex-col items-center justify-center p-6 overflow-hidden relative"
      style={{ background: "radial-gradient(ellipse at center, #040d1a 0%, #010409 100%)" }}
    >
      {/* Ambient grid */}
      <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-[0.04] bg-[length:32px_32px] pointer-events-none" />

      {/* ── Rejection red pulse overlay ─────────────────────────────── */}
      <div
        className="fixed inset-0 pointer-events-none z-50 transition-opacity duration-300"
        style={{
          opacity: rejected ? 1 : 0,
          background: "radial-gradient(ellipse at center, rgba(239,68,68,0.12) 0%, transparent 65%)",
          transition: "opacity 0.2s ease-in, opacity 1s ease-out 0.2s",
        }}
      />

      {/* ── Scan line glow ─────────────────────────────────────────── */}
      {scanState === "scanning" && (
        <div className="fixed left-0 w-full h-[1px] pointer-events-none z-50 bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent"
          style={{ animation: "scanSweep 2s ease-in-out infinite", top: "50%" }}
        />
      )}

      {/* Return link */}
      <Link href="/" className="absolute top-8 left-8 flex items-center gap-3 text-slate-500 hover:text-white transition-colors z-20">
        <ShieldCheck className="w-4 h-4" />
        <span className="text-[10px] font-mono tracking-[0.4em] uppercase">Return</span>
      </Link>

      {/* ── Main panel ─────────────────────────────────────────────── */}
      <div
        ref={formRef}
        className="w-full max-w-md z-10 font-mono"
        style={{
          // Layer 1: camera focus zoom on rejection
          transform: rejected ? "scale(1.015)" : "scale(1)",
          filter:    rejected ? "blur(0.6px)"  : "blur(0px)",
          // Shake on rejection
          animation: rejected ? "rejectShake 0.5s cubic-bezier(0.36,0.07,0.19,0.97)" : "none",
          transition: "transform 0.6s ease, filter 0.6s ease",
        }}
      >
        {/* Header */}
        <div className="text-center mb-8 relative">
          
          <FaceScanner state={scanState} />

          <div className={clsx("transition-all duration-700", scanState !== "idle" && "opacity-0 scale-95 pointer-events-none absolute inset-x-0")}>
            <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center mx-auto mb-4 bg-white/[0.02]">
              <ShieldCheck className="w-6 h-6 text-slate-500" />
            </div>
            <h1 className="text-2xl font-light tracking-wider uppercase mb-2">
              {mode === "login" ? "Authenticate" : "Register"}
            </h1>
            <p className="text-slate-600 text-[10px] tracking-[0.4em] uppercase">
              {mode === "login" ? "Secure Access Node" : "Create New Identity"}
            </p>
          </div>

          {/* Active Status readout during scanning */}
          <div className={clsx(
            "transition-all duration-700 mt-4",
            scanState === "idle" ? "opacity-0 pointer-events-none absolute inset-x-0" : "opacity-100"
          )}>
            <div className="flex items-center justify-center gap-2 mb-2">
              <span className={clsx("w-1.5 h-1.5 rounded-full animate-pulse", 
                scanState === "scanning" ? "bg-cyan-500" : 
                scanState === "success" ? "bg-emerald-500" : "bg-red-500")} />
              <p className={clsx(
                "text-[10px] tracking-[0.4em] uppercase transition-colors duration-500 min-h-[1.2em]",
                scanState === "rejected" ? "text-red-400/80"   :
                scanState === "success"  ? "text-emerald-400/80" :
                scanState === "scanning" ? "text-cyan-400/80"  : "text-slate-600"
              )}>
                {statusText}
              </p>
            </div>
          </div>
        </div>

        {/* Mode Toggle & Form - Fade out during scan */}
        <div className={clsx("transition-all duration-700", scanState !== "idle" && "opacity-0 scale-[0.98] pointer-events-none absolute inset-x-0")}>
          <div className="flex mb-6 border border-white/5">
          <button type="button" onClick={() => { setMode("login"); setError(null); setSuccess(null); setScanState("idle"); setStatusText(""); }}
            className={clsx("flex-1 py-3 text-[10px] font-light tracking-[0.3em] uppercase transition-all",
              mode === "login" ? "bg-white/[0.04] text-white/80" : "text-slate-600 hover:text-slate-400"
            )}>
            Login
          </button>
          <button type="button" onClick={() => { setMode("register"); setError(null); setSuccess(null); setScanState("idle"); setStatusText(""); }}
            className={clsx("flex-1 py-3 text-[10px] font-light tracking-[0.3em] uppercase transition-all",
              mode === "register" ? "bg-white/[0.04] text-white/80" : "text-slate-600 hover:text-slate-400"
            )}>
            Register
          </button>
        </div>

        {/* Form panel */}
        <div className="relative">
          {/* Glass distortion overlay on rejection */}
          <div
            className="absolute inset-0 rounded-sm z-10 pointer-events-none transition-all duration-700"
            style={{
              backdropFilter: rejected ? "blur(1px) brightness(0.9)" : "blur(0px) brightness(1)",
              background:     rejected ? "rgba(239,68,68,0.04)" : "transparent",
              border:         rejected ? "1px solid rgba(239,68,68,0.15)" : "1px solid transparent",
            }}
          />

          <form onSubmit={mode === "login" ? handleLogin : handleRegister}
            className="glass-panel p-8 relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent" />

            {/* Scanning progress bar */}
            {scanState === "scanning" && (
              <div className="absolute top-0 left-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-500/60 to-transparent"
                style={{ animation: "progressBar 2.2s ease-in-out forwards" }} />
            )}
            {scanState === "success" && (
              <div className="absolute top-0 left-0 w-full h-[2px] bg-emerald-500/40" />
            )}
            {scanState === "rejected" && (
              <div className="absolute top-0 left-0 w-full h-[2px] bg-red-500/40" />
            )}

            {/* Role Selector */}
            <div className="mb-6 flex flex-wrap gap-2">
              {(["doctor", "insurer", "patient", "hospital", "pharma"] as const).map((r) => (
                <button key={r} type="button" onClick={() => setRole(r)}
                  className={clsx("flex-1 py-2 px-1 text-[9px] tracking-[0.2em] uppercase border transition-all duration-300",
                    role === r
                      ? "bg-white/[0.04] border-white/15 text-white/70"
                      : "border-white/[0.04] text-slate-700 hover:text-slate-500 hover:border-white/10"
                  )}>
                  {r}
                </button>
              ))}
            </div>

            {/* Register-Only Fields */}
            {mode === "register" && (
              <>
                <div className="mb-5">
                  <label className="block text-[10px] text-slate-500 mb-2 uppercase tracking-[0.3em]">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-700" />
                    <input type="text" required value={fullName} onChange={e => setFullName(e.target.value)}
                      className="w-full bg-mg-bg/80 border border-white/5 p-3 pl-10 text-white/80 outline-none text-xs tracking-wider focus:border-white/15 transition-colors"
                      placeholder="Full name..." />
                  </div>
                </div>

                {needsPhone && (
                  <div className="mb-5">
                    <label className="block text-[10px] text-slate-500 mb-2 uppercase tracking-[0.3em]">
                      Phone <span className="text-white/20">— Permanent Identity</span>
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-700" />
                      <input type="tel" required value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)}
                        className="w-full bg-mg-bg/80 border border-white/5 p-3 pl-10 text-white/80 outline-none text-xs tracking-wider focus:border-white/15 transition-colors"
                        placeholder="+91 98765 43210" />
                    </div>
                  </div>
                )}

                {needsOrg && (
                  <div className="mb-5">
                    <label className="block text-[10px] text-slate-500 mb-2 uppercase tracking-[0.3em]">Organization</label>
                    <input type="text" required value={orgName} onChange={e => setOrgName(e.target.value)}
                      className="w-full bg-mg-bg/80 border border-white/5 p-3 text-white/80 outline-none text-xs tracking-wider focus:border-white/15 transition-colors"
                      placeholder="Organization name..." />
                  </div>
                )}
              </>
            )}

            {/* Username */}
            <div className="mb-5">
              <label className="block text-[10px] text-slate-500 mb-2 uppercase tracking-[0.3em]">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-700" />
                <input type="text" required value={username} onChange={e => setUsername(e.target.value)}
                  className="w-full bg-mg-bg/80 border border-white/5 p-3 pl-10 text-white/80 outline-none text-xs tracking-wider focus:border-white/15 transition-colors"
                  placeholder="Enter username..." />
              </div>
            </div>

            {/* Password */}
            <div className="mb-7">
              <label className="block text-[10px] text-slate-500 mb-2 uppercase tracking-[0.3em]">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-700" />
                <input type="password" required value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full bg-mg-bg/80 border border-white/5 p-3 pl-10 text-white/80 outline-none text-xs tracking-wider focus:border-white/15 transition-colors"
                  placeholder="••••••••" />
              </div>
            </div>

            {/* Submit */}
            <button type="submit" disabled={loading}
              className={clsx(
                "w-full py-4 text-xs font-light uppercase tracking-[0.3em] transition-all relative overflow-hidden flex justify-center items-center border disabled:opacity-40 gap-2",
                scanState === "rejected"
                  ? "border-red-500/30 text-red-400/70 bg-red-500/[0.03]"
                  : "border-white/10 text-white/60 hover:text-white/90 hover:bg-white/[0.04]"
              )}>
              {scanState === "scanning" && (
                <span className="flex items-center gap-2">
                  <Terminal className="w-3 h-3 animate-pulse" /> Verifying
                </span>
              )}
              {scanState === "success" && (
                <span className="flex items-center gap-2 text-emerald-400/80">
                  <CheckCircle2 className="w-3 h-3" /> Granted
                </span>
              )}
              {scanState === "rejected" && (
                <span className="flex items-center gap-2 text-red-400/70">
                  <Lock className="w-3 h-3" /> Access Denied
                </span>
              )}
              {scanState === "idle" && (
                <span>{mode === "login" ? "Authenticate" : "Create Account"}</span>
              )}
            </button>

            {/* Error & success messages */}
            {error && (
              <div className="mt-4 text-[10px] text-red-400/70 border border-red-500/20 p-3 tracking-wider bg-red-500/[0.03]">
                {error}
              </div>
            )}
            {success && (
              <div className="mt-4 text-[10px] text-emerald-400/80 border border-emerald-500/20 p-3 tracking-wider bg-emerald-500/[0.03] flex items-center gap-2">
                <CheckCircle2 className="w-3 h-3 flex-shrink-0" /> {success}
              </div>
            )}
          </form>
        </div>
        </div>
      </div>

      {/* ── Keyframe styles ─────────────────────────────────────────── */}
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes scanLine {
          0%   { top: 20%; opacity: 0; }
          10%  { opacity: 1; }
          90%  { opacity: 1; }
          100% { top: 80%; opacity: 0; }
        }
        @keyframes scanSweep {
          0% { top: -10%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 110%; opacity: 0; }
        }
        @keyframes progressBar {
          0%   { width: 0%; opacity: 1; }
          80%  { width: 100%; opacity: 1; }
          100% { width: 100%; opacity: 0; }
        }
        @keyframes rejectShake {
          0%, 100% { transform: translateX(0) scale(1.015); }
          18%      { transform: translateX(-5px) scale(1.015); }
          36%      { transform: translateX(5px) scale(1.015); }
          54%      { transform: translateX(-4px) scale(1.015); }
          72%      { transform: translateX(4px) scale(1.015); }
          88%      { transform: translateX(-2px) scale(1.015); }
        }
      `}} />
    </div>
  );
}

export default function Login() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-mg-bg flex items-center justify-center text-white/30 font-mono tracking-[0.4em] text-xs uppercase">
        Initializing...
      </div>
    }>
      <LoginForm />
    </Suspense>
  );
}
