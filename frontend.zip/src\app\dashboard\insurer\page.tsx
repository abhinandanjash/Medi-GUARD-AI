"use client";

import { API_BASE } from "@/app/lib/config";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { Database, ShieldCheck, CheckCircle2, XCircle, LogOut, Clock, Terminal, FileText, Search, Pill, BrainCircuit, AlertTriangle, ChevronRight, Activity, Zap } from "lucide-react";
import clsx from "clsx";

type ProcessingState = "IDLE" | "PARSING" | "VALIDATING" | "READY" | "EXECUTING";

export default function InsurerDashboard() {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  
  // Left Column State
  const [viewMode, setViewMode] = useState<"queue" | "search">("queue");
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [searchCode, setSearchCode] = useState("");
  const [searchData, setSearchData] = useState<any>(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [loading, setLoading] = useState(true);

  // Active Item Context (Drives Center & Right columns)
  // Can be a completed Submission OR an unadjudicated Prescription
  const [activeItem, setActiveItem] = useState<any>(null);
  const [activeType, setActiveType] = useState<"submission" | "prescription" | null>(null);

  // Engine State for live pre-adjudication
  const [systemState, setSystemState] = useState<ProcessingState>("IDLE");
  const [targetPayer, setTargetPayer] = useState("starhealth_spinal_fusion");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const storedToken = localStorage.getItem("mg_token");
    if (!storedToken) {
      router.push("/auth/login?role=insurer");
    } else {
      setToken(storedToken);
      fetchDashboard(storedToken);
    }
  }, [router]);

  const fetchDashboard = async (authToken: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/dashboard`, {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      if (!res.ok) throw new Error("Failed to fetch dashboard");
      const data = await res.json();
      setSubmissions(data.submissions || []);
      
      // Auto-select first item if queue mode and no active item
      if (viewMode === "queue" && data.submissions.length > 0 && !activeItem) {
        setActiveItem(data.submissions[0]);
        setActiveType("submission");
        setSystemState("READY");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const lookupPatient = async () => {
    if (!token || !searchCode) return;
    setSearchLoading(true);
    setSearchData(null);
    setError(null);
    setActiveItem(null);
    setActiveType(null);
    setSystemState("IDLE");

    try {
      const res = await fetch(`${API_BASE}/api/patients/${searchCode}/prescriptions`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!res.ok) throw new Error((await res.json()).detail || "Lookup failed");
      const data = await res.json();
      setSearchData(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSearchLoading(false);
    }
  };

  const runAdjudication = async () => {
    if (!token || activeType !== "prescription" || !activeItem) return;
    
    setSystemState("PARSING");
    setError(null);

    // Simulate cinematic processing wait before hitting API
    setTimeout(() => setSystemState("VALIDATING"), 800);
    setTimeout(() => setSystemState("EXECUTING"), 1600);

    setTimeout(async () => {
      try {
        const res = await fetch(`${API_BASE}/api/patients/${searchData.patient_code}/adjudicate`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          },
          body: JSON.stringify({
            report_id: activeItem.id,
            payer_id: targetPayer,
          }),
        });

        if (!res.ok) throw new Error((await res.json()).detail || "Adjudication failed");
        const data = await res.json();
        
        // Transform the prescription into a completed submission in state
        setActiveItem(data);
        setActiveType("submission");
        setSystemState("READY");
        
        // Refresh master queue in background
        fetchDashboard(token);
      } catch (err: any) {
        setError(err.message);
        setSystemState("IDLE");
      }
    }, 2400);
  };

  const handleOverride = async (decision: string) => {
    if (!token || activeType !== "submission" || !activeItem?.id) return;
    
    try {
      const res = await fetch(`${API_BASE}/api/submissions/${activeItem.id}/override`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ override_decision: decision, override_reason: "Manual review by Insurer Control Panel." })
      });
      if (res.ok) {
        // Refresh queue
        fetchDashboard(token);
        // We'd ideally fetch the single updated submission here, but for now just update local state slightly
        // so UI reacts. The proper way is reloading activeItem from API.
        const updated = await res.json();
        setActiveItem((prev: any) => ({ ...prev, status: updated.new_status }));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("mg_token");
    router.push("/");
  };

  if (!token) return null;

  return (
    <div className="min-h-screen bg-[#020617] text-white font-mono overflow-x-hidden selection:bg-mg-glow/30">
      
      {/* Background Ambient Effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10 bg-[length:32px_32px]" />
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-mg-glow/5 blur-[120px] rounded-full mix-blend-screen" />
      </div>

      {/* Header */}
      <header className="relative z-50 border-b border-white/5 bg-[#020617]/80 backdrop-blur-xl h-14 flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <Database className="w-5 h-5 text-mg-glow" />
          <span className="font-bold tracking-[0.2em] text-xs text-slate-200">CONTROL CENTER</span>
          <div className="h-4 w-px bg-slate-800 mx-2" />
          <span className="text-[10px] tracking-widest text-mg-glow/60 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-mg-glow animate-pulse" />
            NODE: PAYER_SYS_01
          </span>
        </div>
        <button onClick={handleLogout} className="flex items-center text-[10px] tracking-widest text-slate-500 hover:text-red-400 transition-colors uppercase">
          <LogOut className="w-3 h-3 mr-2" /> Disconnect
        </button>
      </header>

      {/* 3-COLUMN ARCHITECTURE */}
      <main className="relative z-10 flex h-[calc(100vh-56px)] overflow-hidden">
        
        {/* ─── LEFT: LIVE QUEUE (30%) ─── */}
        <section className="w-[30%] min-w-[350px] border-r border-white/5 bg-[#020617]/50 backdrop-blur-md flex flex-col relative z-20">
          
          {/* View Selector */}
          <div className="flex border-b border-white/5 bg-black/20">
            <button 
              onClick={() => setViewMode("queue")}
              className={clsx("flex-1 py-4 text-[10px] font-bold tracking-[0.2em] uppercase transition-all flex items-center justify-center gap-2 relative",
                viewMode === "queue" ? "text-mg-glow" : "text-slate-600 hover:text-slate-400"
              )}
            >
              <Activity className="w-3.5 h-3.5" />
              Live Queue
              {viewMode === "queue" && <div className="absolute bottom-0 left-0 w-full h-[2px] bg-mg-glow shadow-[0_0_10px_rgba(56,189,248,0.5)]" />}
            </button>
            <button 
              onClick={() => setViewMode("search")}
              className={clsx("flex-1 py-4 text-[10px] font-bold tracking-[0.2em] uppercase transition-all flex items-center justify-center gap-2 relative",
                viewMode === "search" ? "text-mg-primary" : "text-slate-600 hover:text-slate-400"
              )}
            >
              <Search className="w-3.5 h-3.5" />
              Pre-Adjudicate
              {viewMode === "search" && <div className="absolute bottom-0 left-0 w-full h-[2px] bg-mg-primary shadow-[0_0_10px_rgba(6,182,212,0.5)]" />}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col">
            
            {viewMode === "queue" && (
              <div className="p-4 space-y-2">
                {loading ? (
                  <div className="text-[10px] text-slate-500 tracking-[0.2em] uppercase text-center py-8 animate-pulse">
                    Syncing Telemetry...
                  </div>
                ) : submissions.length > 0 ? (
                  submissions.map((sub) => (
                    <button
                      key={sub.id}
                      onClick={() => { setActiveItem(sub); setActiveType("submission"); setSystemState("READY"); setError(null); }}
                      className={clsx(
                        "w-full text-left p-4 border rounded-sm transition-all relative overflow-hidden group",
                        activeItem?.id === sub.id 
                          ? "bg-white/[0.04] border-white/20" 
                          : "bg-white/[0.01] border-white/5 hover:bg-white/[0.02]"
                      )}
                    >
                      <div className={clsx("absolute left-0 top-0 w-1 h-full",
                        sub.status.includes("APPROVED") || sub.status === "SUBMISSION_READY" ? "bg-emerald-500" :
                        sub.status.includes("DENIED") ? "bg-red-500" : "bg-amber-500"
                      )} />
                      <div className="flex justify-between items-start mb-2 pl-2">
                        <span className="text-[9px] text-slate-500 tracking-widest uppercase flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {new Date(sub.timestamp).toLocaleDateString()}
                        </span>
                        <span className={clsx("text-[9px] font-bold tracking-[0.2em] uppercase",
                          sub.status.includes("APPROVED") || sub.status === "SUBMISSION_READY" ? "text-emerald-400" :
                          sub.status.includes("DENIED") ? "text-red-400" : "text-amber-400"
                        )}>
                          {sub.status.split("_")[0]}
                        </span>
                      </div>
                      <div className="pl-2">
                        <h4 className="text-sm font-bold text-slate-200 tracking-wider mb-1">PT-{sub.patient_code}</h4>
                        <p className="text-[10px] text-slate-500 uppercase tracking-widest truncate">{sub.payer?.procedure_name || sub.insurer_id}</p>
                      </div>
                    </button>
                  ))
                ) : (
                  <div className="text-[10px] text-slate-600 tracking-[0.2em] uppercase text-center py-8">
                    No Submissions Found
                  </div>
                )}
              </div>
            )}

            {viewMode === "search" && (
              <div className="p-6">
                <label className="text-[9px] text-slate-500 tracking-[0.2em] uppercase mb-2 flex items-center gap-2">
                  <Database className="w-3 h-3" /> Patient Identifier
                </label>
                <div className="flex gap-2 mb-8">
                  <input 
                    type="text" 
                    value={searchCode}
                    onChange={(e) => setSearchCode(e.target.value)}
                    className="flex-1 bg-white/[0.02] border border-white/10 focus:border-mg-primary/50 focus:bg-white/[0.04] p-3 text-slate-200 outline-none text-xs tracking-wider transition-all rounded-sm"
                    placeholder="e.g. PT-12345"
                  />
                  <button 
                    onClick={lookupPatient}
                    disabled={searchLoading || !searchCode}
                    className="px-6 border border-white/10 bg-white/[0.02] hover:bg-white/[0.05] text-slate-300 text-[10px] font-bold tracking-[0.2em] uppercase transition-all rounded-sm"
                  >
                    {searchLoading ? "..." : "SCAN"}
                  </button>
                </div>

                {searchData && searchData.prescriptions && (
                  <div className="space-y-4">
                    <h3 className="text-[10px] text-mg-primary/70 tracking-[0.2em] uppercase border-b border-white/5 pb-2">
                      Unadjudicated Prescriptions
                    </h3>
                    {searchData.prescriptions.length > 0 ? (
                      searchData.prescriptions.map((rx: any) => (
                        <button
                          key={rx.id}
                          onClick={() => { setActiveItem(rx); setActiveType("prescription"); setSystemState("IDLE"); setError(null); }}
                          className={clsx(
                            "w-full text-left p-4 border rounded-sm transition-all relative overflow-hidden text-xs",
                            activeItem?.id === rx.id 
                              ? "bg-mg-primary/10 border-mg-primary/50" 
                              : "bg-white/[0.01] border-white/5 hover:bg-white/[0.03]"
                          )}
                        >
                          <div className="flex items-center gap-2 text-mg-primary mb-2">
                            <Pill className="w-3.5 h-3.5" />
                            <span className="font-bold tracking-widest uppercase">RX Node</span>
                          </div>
                          <p className="text-[10px] text-slate-400 line-clamp-3 leading-relaxed font-sans">{rx.content}</p>
                          <p className="text-[9px] text-slate-500 mt-3 tracking-widest uppercase">By: {rx.submitted_by}</p>
                        </button>
                      ))
                    ) : (
                      <div className="text-[10px] text-slate-600 tracking-[0.2em] uppercase text-center py-4">
                        No Prescriptions Found
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </section>

        {/* ─── CENTER: DECISION ENGINE VISUALIZATION (35%) ─── */}
        <section className="w-[35%] min-w-[400px] border-r border-white/5 bg-[#020617]/70 backdrop-blur-md relative z-10 flex flex-col">
          <div className="h-14 border-b border-white/5 bg-black/20 flex items-center px-6 justify-between">
            <span className="text-[9px] tracking-[0.2em] text-slate-500 uppercase flex items-center gap-2">
              <BrainCircuit className="w-3 h-3" /> Engine Telemetry
            </span>
            {activeType === "prescription" && systemState === "IDLE" && (
               <span className="text-[9px] text-mg-primary tracking-widest animate-pulse">AWAITING ADJUDICATION COMMAND</span>
            )}
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-6 flex flex-col">
            {!activeItem ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-700">
                <Terminal className="w-16 h-16 mb-6 opacity-20" />
                <p className="text-[10px] tracking-[0.2em] uppercase">System Monitor Standing By</p>
                <p className="text-[10px] text-slate-800 tracking-widest uppercase mt-2">Select a queue item to initialize engine</p>
              </div>
            ) : (
              <>
                {/* Engine Processing Core Animation */}
                <div className="mb-10 flex flex-col items-center pt-4">
                  <div className="relative w-40 h-40 flex items-center justify-center mb-6">
                    {/* Outer Rings */}
                    <div className={clsx("absolute inset-0 rounded-full border transition-all duration-700",
                      systemState === "IDLE" ? "border-slate-800" :
                      systemState === "PARSING" ? "border-mg-glow/30 border-dashed animate-[spin_4s_linear_infinite]" :
                      systemState === "VALIDATING" ? "border-mg-glow/60 border-dotted animate-[spin_2s_linear_infinite]" :
                      systemState === "EXECUTING" ? "border-purple-500 shadow-[0_0_30px_rgba(168,85,247,0.4)] animate-[spin_1s_linear_infinite]" :
                      "border-emerald-500/30"
                    )} />
                    <div className={clsx("absolute inset-4 rounded-full border transition-all duration-500",
                      systemState === "IDLE" ? "border-slate-800/50" :
                      systemState === "EXECUTING" ? "border-purple-500/50 animate-[spin_1.5s_linear_infinite_reverse]" :
                      "border-transparent"
                    )} />
                    
                    {/* Inner Core */}
                    <div className={clsx("w-20 h-20 rounded-full transition-all duration-500 flex items-center justify-center",
                      systemState === "IDLE" ? "bg-slate-900 border border-slate-800" :
                      systemState === "PARSING" ? "bg-mg-glow/10 border border-mg-glow/30" :
                      systemState === "VALIDATING" ? "bg-mg-glow/20 border border-mg-glow/50" :
                      systemState === "EXECUTING" ? "bg-purple-900/40 border border-purple-500" :
                      "bg-emerald-950/40 border border-emerald-500/50"
                    )}>
                      <Zap className={clsx("w-8 h-8 transition-colors duration-500",
                        systemState === "IDLE" ? "text-slate-700" :
                        systemState === "PARSING" ? "text-mg-glow/70" :
                        systemState === "VALIDATING" ? "text-mg-glow" :
                        systemState === "EXECUTING" ? "text-purple-400" :
                        "text-emerald-400"
                      )} />
                    </div>
                  </div>

                  <div className="text-center space-y-1">
                    <div className="text-[10px] tracking-[0.3em] text-slate-500 uppercase">Engine Phase</div>
                    <div className={clsx("text-xl font-bold tracking-widest uppercase transition-colors duration-300",
                      systemState === "IDLE" ? "text-slate-600" :
                      systemState === "PARSING" ? "text-mg-glow/70" :
                      systemState === "VALIDATING" ? "text-mg-glow" :
                      systemState === "EXECUTING" ? "text-purple-400 animate-pulse" :
                      "text-emerald-400"
                    )}>
                      {systemState}
                    </div>
                  </div>
                </div>

                {/* Data Panel: Pre-Adjudication Input */}
                {activeType === "prescription" && (
                  <div className="animate-[fadeIn_0.5s_ease-out]">
                    <h3 className="text-[9px] tracking-[0.2em] text-slate-500 uppercase mb-4 border-b border-white/5 pb-2">
                      Target Policy Binding
                    </h3>
                    <select 
                      value={targetPayer} 
                      onChange={(e) => setTargetPayer(e.target.value)}
                      disabled={systemState !== "IDLE"}
                      className="w-full bg-white/[0.02] border border-white/10 focus:border-mg-glow/50 p-3 text-slate-200 outline-none text-xs tracking-wider transition-all rounded-sm mb-6 disabled:opacity-50 appearance-none"
                    >
                      <option value="starhealth_spinal_fusion">StarHealth - Lumbar Fusion</option>
                      <option value="apollohealth_knee_replacement">ApolloHealth - Knee Replacement</option>
                      <option value="maxbupa_lumbar_mri">MaxBupa - Lumbar MRI</option>
                    </select>

                    <h3 className="text-[9px] tracking-[0.2em] text-slate-500 uppercase mb-4 border-b border-white/5 pb-2">
                      Raw Clinical Input
                    </h3>
                    <div className="bg-black/30 border border-slate-800 p-4 text-xs text-slate-400 leading-relaxed font-sans max-h-48 overflow-y-auto custom-scrollbar rounded-sm">
                      {activeItem.content}
                    </div>
                  </div>
                )}

                {/* Data Panel: Extracted Entities (Completed Submission) */}
                {activeType === "submission" && activeItem.extracted_data && (
                  <div className="animate-[fadeIn_0.5s_ease-out]">
                    <h3 className="text-[9px] tracking-[0.2em] text-mg-glow uppercase mb-4 border-b border-white/5 pb-2 flex items-center justify-between">
                      Neural Extracted Entities
                      <span className="text-[8px] text-slate-600">CONFIDENCE: 98.4%</span>
                    </h3>
                    <div className="space-y-2">
                      {Object.entries(activeItem.extracted_data).map(([key, val]: any, idx) => {
                        if (typeof val !== "string" && typeof val !== "number" && typeof val !== "boolean") return null;
                        return (
                          <div 
                            key={key} 
                            className="flex items-center justify-between p-3 bg-white/[0.02] border border-white/5 rounded-sm"
                          >
                            <span className="text-[9px] text-slate-400 tracking-widest uppercase">{key.replace(/_/g, " ")}</span>
                            <span className="text-xs font-mono text-mg-glow font-bold tracking-wider">{String(val)}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </section>

        {/* ─── RIGHT: AUDIT PANEL & CONTROLS (35%) ─── */}
        <section className="flex-1 bg-black/40 relative z-0 flex flex-col">
          <div className="h-14 border-b border-white/5 bg-black/40 flex items-center px-6">
            <span className="text-[9px] tracking-[0.2em] text-slate-500 uppercase flex items-center gap-2">
              <ShieldCheck className="w-3 h-3" /> Audit Trail & Controls
            </span>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-8 flex flex-col">
            
            {!activeItem && (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-700">
                <ShieldCheck className="w-16 h-16 mb-6 opacity-20" />
                <div className="h-px w-24 bg-gradient-to-r from-transparent via-slate-700/50 to-transparent mb-6" />
                <p className="text-[10px] tracking-[0.2em] uppercase">No Record Selected</p>
              </div>
            )}

            {/* Run Pre-Adjudication Control */}
            {activeType === "prescription" && systemState === "IDLE" && (
               <div className="flex-1 flex flex-col items-center justify-center">
                 <button 
                  onClick={runAdjudication}
                  className="px-12 py-5 border border-mg-glow/50 text-mg-glow bg-mg-glow/5 hover:bg-mg-glow/10 transition-all font-bold tracking-[0.2em] uppercase text-xs rounded-sm group relative overflow-hidden"
                 >
                   <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]" />
                   INITIALIZE ENGINE
                 </button>
                 {error && <div className="mt-6 text-[10px] text-red-500 tracking-widest uppercase">{error}</div>}
               </div>
            )}

            {/* Processing State Anim */}
            {activeType === "prescription" && systemState !== "IDLE" && (
              <div className="flex-1 flex flex-col items-center justify-center">
                <div className="w-64 space-y-6">
                  {['Extracting features', 'Querying policy matrices', 'Applying symbolic logic', 'Formatting audit graph'].map((step, i) => (
                    <div key={i} className="flex items-center gap-4 animate-[fadeIn_0.5s_ease-out_forwards]" style={{ animationDelay: `${i * 600}ms`, opacity: 0 }}>
                      <Terminal className="w-4 h-4 text-mg-glow animate-pulse" />
                      <div className="flex-1">
                        <div className="text-[10px] text-mg-glow/80 tracking-widest uppercase mb-1">{step}</div>
                        <div className="h-0.5 w-full bg-slate-900 rounded-full overflow-hidden">
                          <div className="h-full bg-mg-glow animate-[shimmer_1s_infinite] w-1/2" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Audit Trail (Completed Submission) */}
            {activeType === "submission" && activeItem.evaluation && (
              <div className="flex-1 animate-[fadeIn_0.5s_ease-out] flex flex-col pb-6">
                
                {/* Result Header */}
                <div className={clsx("p-6 border-l-2 bg-gradient-to-r mb-8 rounded-sm",
                  activeItem.status.includes("APPROVED") || activeItem.status === "SUBMISSION_READY"
                    ? "border-emerald-500 from-emerald-950/40 to-transparent" 
                    : activeItem.status.includes("DENIED") ? "border-red-500 from-red-950/40 to-transparent"
                    : "border-amber-500 from-amber-950/40 to-transparent"
                )}>
                  <div className="text-[10px] uppercase tracking-[0.2em] mb-2 text-slate-500">System Recommendation</div>
                  <div className={clsx("text-3xl font-black tracking-widest uppercase mb-4",
                    activeItem.status.includes("APPROVED") || activeItem.status === "SUBMISSION_READY" ? "text-emerald-400" :
                    activeItem.status.includes("DENIED") ? "text-red-400" : "text-amber-400"
                  )}>
                    {activeItem.status}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans border-t border-white/5 pt-4">
                    {activeItem.evaluation.reasoning || activeItem.reasoning}
                  </p>
                </div>

                {/* Logic Timeline */}
                <h3 className="text-[10px] tracking-[0.2em] text-slate-500 uppercase mb-6 flex items-center gap-3">
                  <Database className="w-3 h-3" /> Logic Execution Trace
                  <div className="flex-1 h-px bg-gradient-to-r from-slate-800 to-transparent" />
                </h3>

                <div className="relative border-l border-slate-800 ml-4 space-y-6 mb-12">
                  {Object.entries(activeItem.evaluation.rule_results).map(([ruleKey, ruleData]: any, idx) => (
                    <div key={ruleKey} className="relative pl-6 animate-[fadeIn_0.4s_ease-out_forwards]" style={{ animationDelay: `${idx * 100}ms`, opacity: 0 }}>
                      <div className={clsx("absolute left-[-4px] top-1.5 w-2 h-2 rounded-full border-2 bg-[#020617]",
                        ruleData.passed ? "border-emerald-500" : "border-red-500"
                      )} />
                      <div className="bg-white/[0.02] border border-white/5 p-4 rounded-sm">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-[10px] font-bold text-slate-200 uppercase tracking-widest">
                            {ruleKey.replace(/_/g, " ")}
                          </h4>
                          <span className={clsx("text-[9px] px-2 py-0.5 uppercase tracking-[0.2em] font-bold rounded-sm",
                            ruleData.passed ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"
                          )}>
                            {ruleData.passed ? "PASS" : "FAIL"}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                          {ruleData.explanation || (ruleData.passed ? "Criteria met." : "Requirement missing.")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Manual Override Controls */}
                <div className="mt-auto border-t border-white/5 pt-6">
                  <h3 className="text-[9px] tracking-[0.2em] text-slate-500 uppercase mb-4 text-center">
                    Manual Control Override
                  </h3>
                  <div className="flex gap-4">
                    <button 
                      onClick={() => handleOverride("APPROVED_OVERRIDE")}
                      className="flex-1 h-12 border border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/10 transition-all font-bold tracking-[0.2em] uppercase text-[10px] rounded-sm flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Force Approve
                    </button>
                    <button 
                      onClick={() => handleOverride("DENIED_OVERRIDE")}
                      className="flex-1 h-12 border border-red-500/30 text-red-500 hover:bg-red-500/10 transition-all font-bold tracking-[0.2em] uppercase text-[10px] rounded-sm flex items-center justify-center gap-2"
                    >
                      <XCircle className="w-3.5 h-3.5" /> Force Deny
                    </button>
                  </div>
                </div>

              </div>
            )}
          </div>
        </section>

      </main>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.1); border-radius: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(255, 255, 255, 0.2); }
      `}} />
    </div>
  );
}
