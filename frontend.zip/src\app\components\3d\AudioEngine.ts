"use client";

// ─── MEDI-GUARD AI: CINEMATIC SOUND ENGINE ──────────────────────────────────
// Minimal, refined audio system with Web Audio API.
// Generates all sounds procedurally — no external files needed.

class CinematicAudio {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private ambientOsc: OscillatorNode | null = null;
  private ambientGain: GainNode | null = null;
  private isInitialized = false;
  private isPlaying = false;

  init() {
    if (this.isInitialized || typeof window === "undefined") return;
    try {
      this.ctx = new AudioContext();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.7; // Master volume — clearly audible
      this.masterGain.connect(this.ctx.destination);
      this.isInitialized = true;
    } catch {
      // Audio not supported
    }
  }

  // Continuous low ambient hum
  startAmbient() {
    if (!this.ctx || !this.masterGain || this.isPlaying) return;
    this.ambientGain = this.ctx.createGain();
    this.ambientGain.gain.value = 0;
    this.ambientGain.connect(this.masterGain);

    this.ambientOsc = this.ctx.createOscillator();
    this.ambientOsc.type = "sine";
    this.ambientOsc.frequency.value = 55; // Deep A1
    this.ambientOsc.connect(this.ambientGain);
    this.ambientOsc.start();

    // Slow fade in
    this.ambientGain.gain.linearRampToValueAtTime(0.8, this.ctx.currentTime + 3);
    this.isPlaying = true;
  }

  // Soft pulse for neural activity
  pulse() {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 220 + Math.random() * 110;
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    const now = this.ctx.currentTime;
    gain.gain.linearRampToValueAtTime(0.4, now + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
    osc.stop(now + 0.9);
  }

  // Click for rule activation
  click() {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "square";
    osc.frequency.value = 1200;
    gain.gain.value = 0.25;
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    const now = this.ctx.currentTime;
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
    osc.stop(now + 0.06);
  }

  // Tick for audit network
  tick() {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "triangle";
    osc.frequency.value = 800;
    gain.gain.value = 0.2;
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    const now = this.ctx.currentTime;
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    osc.stop(now + 0.1);
  }

  // Confirmation tone for decision
  confirm() {
    if (!this.ctx || !this.masterGain) return;
    const freqs = [440, 554, 659]; // A4, C#5, E5 — major chord
    freqs.forEach((f, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = "sine";
      osc.frequency.value = f;
      gain.gain.value = 0;
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(this.ctx!.currentTime + i * 0.15);
      const t = this.ctx!.currentTime + i * 0.15;
      gain.gain.linearRampToValueAtTime(0.3, t + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 1.5);
      osc.stop(t + 1.6);
    });
  }

  // Swell for brain formation completion
  swell() {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 110;
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    const now = this.ctx.currentTime;
    osc.frequency.linearRampToValueAtTime(220, now + 2);
    gain.gain.linearRampToValueAtTime(0.5, now + 1);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 3);
    osc.stop(now + 3.1);
  }

  resume() {
    if (this.ctx?.state === "suspended") {
      this.ctx.resume();
    }
  }
}

// Singleton
export const audioEngine = new CinematicAudio();
