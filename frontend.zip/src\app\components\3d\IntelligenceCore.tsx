"use client";

import { useRef, useEffect, useMemo, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, PerspectiveCamera } from "@react-three/drei";
import { EffectComposer, Bloom, Vignette, DepthOfField } from "@react-three/postprocessing";
import * as THREE from "three";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") { gsap.registerPlugin(ScrollTrigger); }

// Global reactivity tracker
const globalMouseActivity = { current: 0 };
if (typeof window !== "undefined") {
  window.addEventListener("mousemove", (e) => {
    globalMouseActivity.current = Math.min(globalMouseActivity.current + 0.1, 2.0); // max activity 2.0
  });
}

/* ═══════════════════════════════════════════════════════════════════════════
   SCENE 1 — CORE REVEAL  (z: 20)
═══════════════════════════════════════════════════════════════════════════ */
const CoreReveal = () => {
  const shellRef = useRef<THREE.Mesh>(null);
  const innerRef = useRef<THREE.Mesh>(null);
  const lightRef = useRef<THREE.PointLight>(null);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const activity = globalMouseActivity.current;
    
    if (shellRef.current) {
      shellRef.current.rotation.y = t * 0.015 + (activity * 0.01);
      shellRef.current.rotation.x = Math.sin(t * 0.08) * 0.03;
    }
    if (innerRef.current) {
      innerRef.current.rotation.y = t * -0.025 - (activity * 0.02);
      const baseS = 1 + Math.sin(t * 0.5) * 0.008;
      const actS = baseS + (activity * 0.05); // swell on activity
      innerRef.current.scale.set(actS, actS, actS);
    }
    if (lightRef.current) {
      lightRef.current.intensity = 1.5 + (activity * 1.5); // Glow intensifies
    }
  });

  return (
    <group position={[0, 0, 20]}>
      <mesh ref={innerRef}>
        <icosahedronGeometry args={[0.6, 1]} />
        <meshPhysicalMaterial
          color="#0c4a6e" emissive="#0891b2" emissiveIntensity={0.6}
          metalness={0.3} roughness={0.4} wireframe transparent opacity={0.4}
        />
      </mesh>
      <mesh ref={shellRef}>
        <sphereGeometry args={[1.2, 64, 64]} />
        <meshPhysicalMaterial
          color="#070d18" transmission={0.9} metalness={0} roughness={0.06}
          ior={1.5} thickness={0.8} envMapIntensity={0.5}
          clearcoat={1} clearcoatRoughness={0.03} transparent
        />
      </mesh>
      <pointLight ref={lightRef} color="#0891b2" intensity={1.5} distance={5} decay={2} />
      {/* Subtle volumetric beam hint */}
      <mesh position={[0, 0, 0]}>
         <cylinderGeometry args={[1.5, 0.5, 8, 32, 1, true]} />
         <meshBasicMaterial color="#0891b2" transparent opacity={0.02} side={THREE.DoubleSide} blending={THREE.AdditiveBlending} />
      </mesh>
    </group>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   SCENE 2 — DATA INGESTION  (z: 10)
═══════════════════════════════════════════════════════════════════════════ */
const DataIngestion = () => {
  const ref = useRef<THREE.Points>(null);
  const count = 600;
  const { pos, tgt, col } = useMemo(() => {
    const p = new Float32Array(count * 3);
    const t = new Float32Array(count * 3);
    const c = new Float32Array(count * 3);
    const base = new THREE.Color("#1e3a5f");
    const accent = new THREE.Color("#0e7490");
    for (let i = 0; i < count; i++) {
      p[i*3]=(Math.random()-.5)*12; p[i*3+1]=(Math.random()-.5)*8; p[i*3+2]=10+(Math.random()-.5)*6;
      const col2=Math.floor(Math.random()*6)-3;
      t[i*3]=col2*0.6; t[i*3+1]=(Math.random()-.5)*5; t[i*3+2]=10+(Math.random()-.5)*1;
      const m=Math.random(); const cc=base.clone().lerp(accent,m*0.5);
      c[i*3]=cc.r; c[i*3+1]=cc.g; c[i*3+2]=cc.b;
    }
    return { pos: p, tgt: t, col: c };
  }, []);

  useFrame(({ clock }) => {
    if (!ref.current) return;
    const arr = ref.current.geometry.attributes.position.array as Float32Array;
    const time = clock.elapsedTime;
    const activity = globalMouseActivity.current;
    
    for (let i = 0; i < count; i++) {
      const idx = i * 3;
      const sp = 0.0005 + Math.sin(i * 0.1) * 0.0002 + (activity * 0.001); // speeds up on activity
      arr[idx] += (tgt[idx] - arr[idx]) * sp;
      arr[idx+1] += (tgt[idx+1] - arr[idx+1]) * sp;
      arr[idx+2] += (tgt[idx+2] - arr[idx+2]) * sp;
      arr[idx] += Math.sin(time * 0.3 + i) * 0.0006;
      arr[idx+1] += Math.cos(time * 0.25 + i * 0.5) * 0.0006;
    }
    ref.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[pos, 3]} />
        <bufferAttribute attach="attributes-color" args={[col, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.03} vertexColors transparent opacity={0.5}
        blending={THREE.AdditiveBlending} depthWrite={false} sizeAttenuation />
    </points>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   SCENE 3 — NEURAL BRAIN  (z: 0)
═══════════════════════════════════════════════════════════════════════════ */
const NeuralBrain = () => {
  const brainRef = useRef<THREE.Mesh>(null);
  const shellRef = useRef<THREE.Mesh>(null);
  const r1 = useRef<THREE.Mesh>(null);
  const r2 = useRef<THREE.Mesh>(null);
  const r3 = useRef<THREE.Mesh>(null);
  const linesRef = useRef<THREE.Group>(null);

  const signalPaths = useMemo(() => {
    const paths: THREE.BufferGeometry[] = [];
    for (let p = 0; p < 12; p++) {
      const pts: THREE.Vector3[] = [];
      const baseAngle = (p / 12) * Math.PI * 2;
      for (let i = 0; i <= 20; i++) {
        const t = i / 20;
        const r = 0.6 + t * 0.5;
        const angle = baseAngle + t * Math.PI * 0.5;
        pts.push(new THREE.Vector3(
          Math.cos(angle) * r, Math.sin(angle * 1.5) * r * 0.4, Math.sin(angle) * r
        ));
      }
      paths.push(new THREE.BufferGeometry().setFromPoints(pts));
    }
    return paths;
  }, []);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const act = globalMouseActivity.current;
    
    if (brainRef.current) {
      brainRef.current.rotation.y = t * 0.04 + (act * 0.05);
      brainRef.current.rotation.x = Math.sin(t * 0.1) * 0.05;
      (brainRef.current.material as THREE.MeshPhysicalMaterial).emissiveIntensity = 0.5 + act * 0.5;
    }
    if (shellRef.current) shellRef.current.rotation.y = t * -0.02 - (act * 0.02);
    
    if (r1.current) { r1.current.rotation.x = t * 0.03 + (act*0.02); r1.current.rotation.z = Math.PI / 3; }
    if (r2.current) { r2.current.rotation.y = t * -0.04 - (act*0.02); r2.current.rotation.x = Math.PI / 4; }
    if (r3.current) { r3.current.rotation.z = t * 0.025 + (act*0.02); r3.current.rotation.y = Math.PI / 5; }
    
    if (linesRef.current) {
      linesRef.current.rotation.y = t * 0.1 + (act * 0.2);
    }
  });

  return (
    <group position={[0, 0, 0]}>
      <mesh ref={brainRef}>
        <icosahedronGeometry args={[0.8, 2]} />
        <meshPhysicalMaterial
          color="#0f172a" emissive="#0891b2" emissiveIntensity={0.5}
          metalness={0.2} roughness={0.3} wireframe transparent opacity={0.55}
        />
      </mesh>
      
      <group ref={linesRef}>
        {signalPaths.map((geom, i) => (
          // @ts-expect-error - R3F <line> conflicts with SVG <line> in TypeScript
          <line key={`sig-${i}`} geometry={geom}>
            <lineBasicMaterial color="#0891b2" transparent opacity={0.15 + Math.sin(i) * 0.1} blending={THREE.AdditiveBlending} />
          </line>
        ))}
      </group>

      <mesh ref={r1}><torusGeometry args={[1.0, 0.006, 8, 64]} /><meshPhysicalMaterial color="#164e63" emissive="#0891b2" emissiveIntensity={0.2} metalness={0.9} roughness={0.1} /></mesh>
      <mesh ref={r2}><torusGeometry args={[1.2, 0.005, 8, 64]} /><meshPhysicalMaterial color="#1e1b4b" emissive="#6366f1" emissiveIntensity={0.15} metalness={0.9} roughness={0.1} /></mesh>
      <mesh ref={r3}><torusGeometry args={[1.4, 0.004, 8, 64]} /><meshPhysicalMaterial color="#1c1917" emissive="#0d9488" emissiveIntensity={0.1} metalness={0.9} roughness={0.1} /></mesh>

      <mesh ref={shellRef}>
        <sphereGeometry args={[1.6, 64, 64]} />
        <meshPhysicalMaterial
          color="#070d18" transmission={0.88} metalness={0} roughness={0.07}
          ior={1.5} thickness={1} envMapIntensity={0.4}
          clearcoat={1} clearcoatRoughness={0.03} transparent
        />
      </mesh>

      <pointLight color="#0891b2" intensity={2} distance={5} decay={2} />
      <pointLight color="#4f46e5" intensity={0.5} distance={3} decay={2} position={[0, 1, 0]} />
    </group>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   SCENE 4 — SYMBOLIC RULE ENGINE  (z: -12)
═══════════════════════════════════════════════════════════════════════════ */
const RuleEngine = () => {
  const nodesRef = useRef<THREE.Group>(null);

  useFrame(({ clock }) => {
    if (nodesRef.current) nodesRef.current.rotation.y = clock.elapsedTime * 0.015 + (globalMouseActivity.current * 0.02);
  });

  const nodes = useMemo(() => {
    const items: { pos: [number, number, number]; h: number; s: number; c: string; e: string }[] = [];
    for (let x = -2; x <= 2; x++) {
      for (let z = -2; z <= 2; z++) {
        if (Math.abs(x) + Math.abs(z) > 3) continue;
        items.push({
          pos: [x * 1.3, 0, z * 1.3],
          h: 0.3 + Math.abs(Math.sin(x * z * 0.5)) * 0.5,
          s: 0.12 + Math.random() * 0.08,
          c: (x + z) % 2 === 0 ? "#065f46" : "#0c4a6e",
          e: (x + z) % 2 === 0 ? "#10b981" : "#0891b2",
        });
      }
    }
    return items;
  }, []);

  const conns = useMemo(() => {
    const lines: { from: THREE.Vector3; to: THREE.Vector3 }[] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const d = Math.hypot(nodes[i].pos[0] - nodes[j].pos[0], nodes[i].pos[2] - nodes[j].pos[2]);
        if (d < 2) lines.push({
          from: new THREE.Vector3(nodes[i].pos[0], nodes[i].h, nodes[i].pos[2]),
          to: new THREE.Vector3(nodes[j].pos[0], nodes[j].h, nodes[j].pos[2]),
        });
      }
    }
    return lines;
  }, [nodes]);

  return (
    <group position={[0, -1.2, -12]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.2, 0]}>
        <circleGeometry args={[5, 64]} />
        <meshPhysicalMaterial color="#050a14" metalness={0.97} roughness={0.1}
          clearcoat={0.9} clearcoatRoughness={0.06} envMapIntensity={0.35} />
      </mesh>
      <gridHelper args={[10, 20, "#0a1628", "#060e1a"]} position={[0, -0.19, 0]} />

      <group ref={nodesRef}>
        {nodes.map((n, i) => (
          <group key={i} position={n.pos}>
            <mesh position={[0, n.h, 0]}>
              <octahedronGeometry args={[n.s, 0]} />
              <meshPhysicalMaterial color={n.c} emissive={n.e} emissiveIntensity={0.3}
                metalness={0.85} roughness={0.12} clearcoat={1} clearcoatRoughness={0.04} />
            </mesh>
            <mesh position={[0, (n.h - 0.2) / 2, 0]}>
              <cylinderGeometry args={[0.003, 0.003, n.h + 0.2, 4]} />
              <meshBasicMaterial color={n.e} transparent opacity={0.15} blending={THREE.AdditiveBlending} />
            </mesh>
          </group>
        ))}
        {conns.map((c, i) => {
          const g = new THREE.BufferGeometry().setFromPoints([c.from, c.to]);
          // @ts-expect-error - R3F <line> conflicts with SVG <line> in TypeScript
          return <line key={`rc-${i}`} geometry={g}><lineBasicMaterial color="#0891b2" transparent opacity={0.08} /></line>;
        })}
      </group>
      <pointLight color="#10b981" intensity={1.5} distance={6} decay={2} position={[0, 2, 0]} />
    </group>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   SCENE 5 — AUDIT NETWORK  (z: -22)
═══════════════════════════════════════════════════════════════════════════ */
const AuditNetwork = () => {
  const groupRef = useRef<THREE.Group>(null);
  const materialRefs = useRef<THREE.MeshPhysicalMaterial[]>([]);

  const { auditNodes, auditLinks } = useMemo(() => {
    const nodes: THREE.Vector3[] = [];
    const links: { from: THREE.Vector3; to: THREE.Vector3 }[] = [];
    const layers = [
      { y: 2.5, count: 3, radius: 1.2 },
      { y: 1.5, count: 5, radius: 2.0 },
      { y: 0.5, count: 7, radius: 2.8 },
      { y: -0.3, count: 5, radius: 2.0 },
    ];

    let prevLayer: THREE.Vector3[] = [];
    layers.forEach((layer) => {
      const currentLayer: THREE.Vector3[] = [];
      for (let i = 0; i < layer.count; i++) {
        const angle = (i / layer.count) * Math.PI * 2;
        const pos = new THREE.Vector3(
          Math.cos(angle) * layer.radius, layer.y, Math.sin(angle) * layer.radius
        );
        nodes.push(pos);
        currentLayer.push(pos);
      }
      if (prevLayer.length > 0) {
        currentLayer.forEach((cn) => {
          const closest = prevLayer.reduce((a, b) => cn.distanceTo(a) < cn.distanceTo(b) ? a : b);
          links.push({ from: closest, to: cn });
          const second = prevLayer.filter(p => p !== closest).reduce((a, b) => cn.distanceTo(a) < cn.distanceTo(b) ? a : b, prevLayer[0]);
          if (second !== closest) links.push({ from: second, to: cn });
        });
      }
      prevLayer = currentLayer;
    });

    return { auditNodes: nodes, auditLinks: links };
  }, []);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (groupRef.current) groupRef.current.rotation.y = t * 0.01 + (globalMouseActivity.current * 0.01);
    
    // Ripple emissive effect
    materialRefs.current.forEach((mat, i) => {
      if (mat) mat.emissiveIntensity = 0.3 + Math.sin(t * 2 + i * 0.5) * 0.2 + (globalMouseActivity.current * 0.5);
    });
  });

  return (
    <group ref={groupRef} position={[0, -0.5, -22]}>
      {auditNodes.map((pos, i) => (
        <mesh key={`an-${i}`} position={pos}>
          <sphereGeometry args={[0.06, 16, 16]} />
          <meshPhysicalMaterial
            ref={(el) => { if (el) materialRefs.current[i] = el; }}
            color="#065f46" emissive="#10b981" emissiveIntensity={0.3}
            metalness={0.8} roughness={0.2}
          />
        </mesh>
      ))}

      {auditLinks.map((link, i) => {
        const geom = new THREE.BufferGeometry().setFromPoints([link.from, link.to]);
        return (
          // @ts-expect-error - R3F <line> conflicts with SVG <line> in TypeScript
          <line key={`al-${i}`} geometry={geom}>
            <lineBasicMaterial color="#10b981" transparent opacity={0.2} blending={THREE.AdditiveBlending} />
          </line>
        );
      })}

      <mesh position={[0, 1.1, 0]}>
        <cylinderGeometry args={[0.02, 0.02, 3, 8]} />
        <meshBasicMaterial color="#10b981" transparent opacity={0.1} />
      </mesh>

      <pointLight color="#10b981" intensity={1.5} distance={6} decay={2} position={[0, 2, 0]} />
    </group>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   SCENE 6 — DECISION OUTPUT  (z: -32)
═══════════════════════════════════════════════════════════════════════════ */
const DecisionOutput = () => {
  const glowRef = useRef<THREE.PointLight>(null);
  const beamRef = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const act = globalMouseActivity.current;
    if (glowRef.current) glowRef.current.intensity = 1.2 + Math.sin(t * 0.5) * 0.3 + (act * 1.5);
    if (beamRef.current) {
      (beamRef.current.material as THREE.MeshBasicMaterial).opacity = 0.08 + Math.sin(t * 0.5) * 0.03 + (act * 0.1);
    }
  });

  return (
    <group position={[0, 0, -32]}>
      <mesh position={[0, 1, 0]}>
        <boxGeometry args={[2.5, 4, 0.2]} />
        <meshPhysicalMaterial color="#020408" metalness={1} roughness={0.03}
          clearcoat={1} clearcoatRoughness={0.03} envMapIntensity={0.5} />
      </mesh>
      <mesh position={[0, 1, 0.11]}>
        <boxGeometry args={[2.1, 3.5, 0.005]} />
        <meshStandardMaterial color="#064e3b" emissive="#059669"
          emissiveIntensity={0.2} transparent opacity={0.3} />
      </mesh>
      <mesh ref={beamRef} position={[0, 3.2, 0.4]}>
        <cylinderGeometry args={[0.25, 0.008, 2.5, 8, 1, true]} />
        <meshBasicMaterial color="#10b981" transparent opacity={0.1}
          side={THREE.DoubleSide} blending={THREE.AdditiveBlending} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1, 0]}>
        <circleGeometry args={[3, 64]} />
        <meshPhysicalMaterial color="#030810" metalness={0.97} roughness={0.06}
          clearcoat={0.5} envMapIntensity={0.25} />
      </mesh>
      <pointLight ref={glowRef} color="#10b981" intensity={1.5} distance={7} decay={2} position={[0, 1, 1.5]} />
    </group>
  );
};



/* ═══════════════════════════════════════════════════════════════════════════
   CAMERA RIG — Cinematic mouse tracking with heavy damping
═══════════════════════════════════════════════════════════════════════════ */
const CameraRig = () => {
  const { camera } = useThree();
  const mouse = useRef({ x: 0, y: 0 });
  const smooth = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const h = (e: MouseEvent) => {
      mouse.current.x = e.clientX / window.innerWidth - 0.5;
      mouse.current.y = e.clientY / window.innerHeight - 0.5;
    };
    window.addEventListener("mousemove", h);
    return () => window.removeEventListener("mousemove", h);
  }, []);

  useFrame(() => {
    // Activity decay
    globalMouseActivity.current = Math.max(0, globalMouseActivity.current - 0.02);
    
    smooth.current.x += (mouse.current.x - smooth.current.x) * 0.006;
    smooth.current.y += (mouse.current.y - smooth.current.y) * 0.006;
    camera.rotation.y = smooth.current.x * 0.012;
    camera.rotation.x = -smooth.current.y * 0.006;
    // Add subtle camera drift based on activity
    camera.position.x += (Math.sin(Date.now() * 0.001) * 0.0005 * globalMouseActivity.current);
    camera.position.y += (Math.cos(Date.now() * 0.0012) * 0.0005 * globalMouseActivity.current);
  });

  return null;
};

/* ═══════════════════════════════════════════════════════════════════════════
   MAIN CINEMATIC SCENE
═══════════════════════════════════════════════════════════════════════════ */
const CinematicScene = () => {
  const cam = useRef<THREE.Group>(null);

  useEffect(() => {
    if (!cam.current) return;

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: "#scroll-container",
        start: "top top", end: "bottom bottom",
        scrub: 2.5,
      },
    });

    tl.to(cam.current.position, { x: 0, y: 0.2, z: 12, ease: "power1.inOut" }, 0);
    tl.to(cam.current.rotation, { x: 0, y: 0, z: 0, ease: "power1.inOut" }, 0);

    tl.to(cam.current.position, { x: 0.6, y: 0.5, z: 1, ease: "power2.inOut" }, 1);
    tl.to(cam.current.rotation, { x: -0.04, y: 0.1, z: 0, ease: "power2.inOut" }, 1);

    tl.to(cam.current.position, { x: -0.2, y: 0.3, z: -10, ease: "power2.inOut" }, 2);
    tl.to(cam.current.rotation, { x: -0.06, y: -0.03, z: 0, ease: "power2.inOut" }, 2);

    tl.to(cam.current.position, { x: 0.4, y: 0.6, z: -20, ease: "power2.inOut" }, 3);
    tl.to(cam.current.rotation, { x: -0.03, y: 0.06, z: 0, ease: "power2.inOut" }, 3);

    tl.to(cam.current.position, { x: 0, y: 0.3, z: -30, ease: "power2.inOut" }, 4);
    tl.to(cam.current.rotation, { x: 0, y: 0, z: 0, ease: "power2.inOut" }, 4);

    tl.to(cam.current.position, { x: 0, y: 0.3, z: -32, ease: "power1.inOut" }, 5);

    return () => { tl.kill(); };
  }, []);

  return (
    <>
      <group ref={cam} position={[0, 0.2, 24]}>
        <PerspectiveCamera makeDefault position={[0, 0, 0]} fov={38} near={0.1} far={120} />
      </group>

      <CameraRig />

      {/* Cinematic 3-Point Lighting */}
      <directionalLight position={[10, 8, 6]} intensity={0.5} color="#d4d4d8" />
      <directionalLight position={[-8, 2, 4]} intensity={0.15} color="#155e75" />
      <directionalLight position={[0, 6, -12]} intensity={0.2} color="#4c1d95" />
      <ambientLight intensity={0.03} />

      {/* All 6 3D Scenes */}
      <CoreReveal />
      <DataIngestion />
      <NeuralBrain />
      <RuleEngine />
      <AuditNetwork />
      <DecisionOutput />

      <Environment preset="night" environmentIntensity={0.15} />

      {/* Film-grade post-processing */}
      <EffectComposer enableNormalPass={false}>
        <DepthOfField focusDistance={0} focalLength={0.02} bokehScale={2.5} height={480} />
        <Bloom luminanceThreshold={0.8} mipmapBlur intensity={0.4} radius={0.5} />
        <Vignette eskil={false} offset={0.2} darkness={0.85} />
      </EffectComposer>
    </>
  );
};

export default function IntelligenceCore() {
  return (
    <div className="fixed inset-0 w-full h-full z-0 pointer-events-none bg-mg-bg">
      <Canvas
        dpr={[1, 1.5]}
        gl={{
          antialias: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.1,
          outputColorSpace: THREE.SRGBColorSpace,
        }}
      >
        <fog attach="fog" args={["#020617", 5, 50]} />
        <CinematicScene />
      </Canvas>
    </div>
  );
}
