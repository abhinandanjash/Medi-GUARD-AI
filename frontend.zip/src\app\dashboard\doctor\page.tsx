"use client";

import { API_BASE } from "@/app/lib/config";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { Activity, ShieldCheck, Terminal, BrainCircuit, Database, CheckCircle2, FileText, LogOut, Pill, XCircle, ChevronRight, ActivitySquare, AlertCircle } from "lucide-react";
import clsx from "clsx";

// Types for our live processing visualization
type ProcessingState = "IDLE" | "PARSING" | "VALIDATING" | "READY" | "EXECUTING";
type ExtractedTag = { label: string; value: string; type: "demographic" | "symptom" | "treatment" | "duration" | "unknown" };

export default function DoctorDashboard() {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  
  // Base State
  const [recordMode, setRecordMode] = useState<"auth" | "prescription">("auth");
  const [patientCode, setPatientCode] = useState("PT-99432");
  
  // Auth Mode State
  const [notes, setNotes] = useState("Patient is a 65yo male presenting with severe lower back pain and leg numbness. MRI shows L4-L5 herniation. Has tried 6 months of physical therapy and NSAIDs without relief. Recommending lumbar spinal fusion.");
  const [payer, setPayer] = useState("starhealth_spinal_fusion");
  
  // Prescription Mode State
  const [rxMedication, setRxMedication] = useState("");
  const [rxContent, setRxContent] = useState("");

  // Processing & Results State
  const [systemState, setSystemState] = useState<ProcessingState>("IDLE");
  const [liveTags, setLiveTags] = useState<ExtractedTag[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Debounce ref for parsing simulation
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const storedToken = localStorage.getItem("mg_token");
    if (!storedToken) {
      router.push("/auth/login?role=doctor");
    } else {
      setToken(storedToken);
    }
  }, [router]);

  // Handle Logout
  const handleLogout = () => {
    localStorage.removeItem("mg_token");
    router.push("/");
  };

  // --- LIVE PARSING SIMULATOR ---
  // This simulates the "Live Extraction" without hitting the backend on every keystroke
  useEffect(() => {
    const textToParse = recordMode === "auth" ? notes : rxContent;
    
    if (textToParse.length === 0) {
      setSystemState("IDLE");
      setLiveTags([]);
      return;
    }

    // Doctor is typing
    setSystemState("PARSING");
    
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    
    typingTimeoutRef.current = setTimeout(() => {
      setSystemState("VALIDATING");
      
      setTimeout(() => {
        // Simple regex-based mock extraction for visual feedback
        const newTags: ExtractedTag[] = [];
        
        // Match Age
        const ageMatch = textToParse.match(/(\d{1,3})(?:yo|-year-old| year old| years old)/i);
        if (ageMatch) newTags.push({ label: "Age", value: ageMatch[1], type: "demographic" });
        
        // Match Gender
        const genderMatch = textToParse.match(/\b(male|female|man|woman|boy|girl)\b/i);
        if (genderMatch) newTags.push({ label: "Gender", value: genderMatch[1], type: "demographic" });

        // Match Duration
        const durationMatch = textToParse.match(/(\d+)\s*(days|weeks|months|years)/i);
        if (durationMatch) newTags.push({ label: "Duration", value: durationMatch[0], type: "duration" });

        // Match common symptoms/keywords
        const keywords = ["pain", "numbness", "fever", "swelling", "herniation", "fracture"];
        keywords.forEach(kw => {
          if (textToParse.toLowerCase().includes(kw)) {
            newTags.push({ label: "Symptom", value: kw, type: "symptom" });
          }
        });

        setLiveTags(newTags);
        setSystemState("READY");
      }, 600);
    }, 800);

    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    };
  }, [notes, rxContent, recordMode]);

  // --- BACKEND SUBMISSION ---
  const submitCase = async () => {
    if (!token) return;
    setIsProcessing(true);
    setSystemState("EXECUTING");
    setError(null);
    setResult(null);

    try {
      const res = await fetch(`${API_BASE}/api/submissions/evaluate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          patient_code: patientCode,
          clinical_notes: notes,
          payer_id: payer,
        }),
      });

      if (!res.ok) throw new Error((await res.json()).detail || "Submission failed");
      const data = await res.json();
      setResult(data);
      
      // Update tags with actual extracted data
      if (data.extracted_data) {
        const realTags: ExtractedTag[] = [];
        Object.entries(data.extracted_data).forEach(([key, val]: any) => {
          if (typeof val === 'string' || typeof val === 'number') {
            realTags.push({ label: key.replace(/_/g, " "), value: String(val), type: "unknown" });
          }
        });
        setLiveTags(realTags);
      }
      
      setSystemState("READY");
    } catch (err: any) {
      setError(err.message);
      setSystemState("IDLE");
    } finally {
      setIsProcessing(false);
    }
  };

  const submitPrescription = async () => {
    if (!token || !patientCode || !rxContent) return;
    setIsProcessing(true);
    setSystemState("EXECUTING");
    setError(null);
    setResult(null);

    try {
      const res = await fetch(`${API_BASE}/api/patients/${patientCode}/reports`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          report_type: "prescription",
          content: rxContent,
          medication_name: rxMedication || undefined,
        }),
      });

      if (!res.ok) throw new Error((await res.json()).detail || "Prescription submission failed");
      const data = await res.json();
      
      // Create a mock successful result to show in the decision engine for prescriptions
      setResult({
        type: "prescription_success",
        report_id: data.report_id,
        status: "STORED IN LEDGER",
        reasoning: "Prescription successfully added to patient record. Ready for insurer pre-adjudication."
      });
      
      setSystemState("READY");
    } catch (err: any) {
      setError(err.message);
      setSystemState("IDLE");
    } finally {
      setIsProcessing(false);
    }
  };

  if (!token) return null;

  return (
    <div className="min-h-screen bg-[#020617] text-white font-mono overflow-x-hidden selection:bg-mg-primary/30">
      
      {/* Background Ambient Effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10 bg-[length:32px_32px]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-mg-primary/5 blur-[120px] rounded-full mix-blend-screen" />
      </div>

      {/* Header */}
      <header className="relative z-50 border-b border-white/5 bg-[#020617]/80 backdrop-blur-xl h-14 flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <ActivitySquare className="w-5 h-5 text-mg-primary" />
          <span className="font-bold tracking-[0.2em] text-xs text-slate-200">INTELLIGENCE TERMINAL</span>
          <div className="h-4 w-px bg-slate-800 mx-2" />
          <span className="text-[10px] tracking-widest text-mg-primary/60 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-mg-primary animate-pulse" />
            NODE: DOCTOR_01
          </span>
        </div>
        <button onClick={handleLogout} className="flex items-center text-[10px] tracking-widest text-slate-500 hover:text-red-400 transition-colors uppercase">
          <LogOut className="w-3 h-3 mr-2" /> Disconnect
        </button>
      </header>

      {/* 3-COLUMN ARCHITECTURE */}
      <main className="relative z-10 flex h-[calc(100vh-56px)] overflow-hidden">
        
        {/* ─── LEFT: CLINICAL INPUT STREAM (35%) ─── */}
        <section className="w-[35%] min-w-[400px] border-r border-white/5 bg-[#020617]/50 backdrop-blur-md flex flex-col relative z-20">
          
          {/* View Selector */}
          <div className="flex border-b border-white/5 bg-black/20">
            <button 
              onClick={() => { setRecordMode("auth"); setResult(null); setError(null); }}
              className={clsx("flex-1 py-4 text-[10px] font-bold tracking-[0.2em] uppercase transition-all flex items-center justify-center gap-2 relative",
                recordMode === "auth" ? "text-mg-primary" : "text-slate-600 hover:text-slate-400"
              )}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Prior Auth
              {recordMode === "auth" && <div className="absolute bottom-0 left-0 w-full h-[2px] bg-mg-primary shadow-[0_0_10px_rgba(6,182,212,0.5)]" />}
            </button>
            <button 
              onClick={() => { setRecordMode("prescription"); setResult(null); setError(null); }}
              className={clsx("flex-1 py-4 text-[10px] font-bold tracking-[0.2em] uppercase transition-all flex items-center justify-center gap-2 relative",
                recordMode === "prescription" ? "text-emerald-400" : "text-slate-600 hover:text-slate-400"
              )}
            >
              <Pill className="w-3.5 h-3.5" />
              Prescription
              {recordMode === "prescription" && <div className="absolute bottom-0 left-0 w-full h-[2px] bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" />}
            </button>
          </div>

          <div className="p-6 flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-6">
            
            {/* Global Input: Patient Code */}
            <div>
              <label className="text-[9px] text-slate-500 tracking-[0.2em] uppercase mb-2 flex items-center gap-2">
                <Database className="w-3 h-3" /> Patient Identifier
              </label>
              <input 
                type="text" 
                value={patientCode}
                onChange={(e) => setPatientCode(e.target.value)}
                className="w-full bg-white/[0.02] border border-white/10 focus:border-mg-primary/50 focus:bg-white/[0.04] p-3 text-slate-200 outline-none text-xs tracking-wider transition-all rounded-sm"
              />
            </div>

            {/* Mode: PRIOR AUTH */}
            {recordMode === "auth" && (
              <>
                <div>
                  <label className="text-[9px] text-slate-500 tracking-[0.2em] uppercase mb-2 flex items-center gap-2">
                    <BrainCircuit className="w-3 h-3" /> Target Policy Node
                  </label>
                  <div className="relative">
                    <select 
                      value={payer} 
                      onChange={(e) => setPayer(e.target.value)}
                      className="w-full bg-white/[0.02] border border-white/10 focus:border-mg-primary/50 p-3 text-slate-200 outline-none text-xs tracking-wider transition-all rounded-sm appearance-none cursor-pointer"
                    >
                      <option value="starhealth_spinal_fusion">StarHealth - Lumbar Fusion</option>
                      <option value="apollohealth_knee_replacement">ApolloHealth - Knee Replacement</option>
                      <option value="maxbupa_lumbar_mri">MaxBupa - Lumbar MRI</option>
                    </select>
                    <ChevronDownIcon className="w-3 h-3 absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                  </div>
                </div>

                <div className="flex-1 flex flex-col">
                  <label className="text-[9px] text-slate-500 tracking-[0.2em] uppercase mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-2"><FileText className="w-3 h-3" /> Clinical Stream</span>
                    <span className={clsx("text-[8px] animate-pulse", 
                      systemState === "PARSING" ? "text-amber-400" :
                      systemState === "VALIDATING" ? "text-mg-primary" : "text-transparent"
                    )}>
                      SCANNING...
                    </span>
                  </label>
                  <textarea 
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="flex-1 min-h-[200px] w-full bg-white/[0.02] border border-white/10 focus:border-mg-primary/50 p-4 text-slate-300 outline-none text-xs leading-relaxed resize-none transition-all rounded-sm font-sans"
                    placeholder="Enter unstructured clinical notes..."
                  />
                </div>
              </>
            )}

            {/* Mode: PRESCRIPTION */}
            {recordMode === "prescription" && (
              <>
                <div>
                  <label className="text-[9px] text-emerald-500/70 tracking-[0.2em] uppercase mb-2 flex items-center gap-2">
                    <Pill className="w-3 h-3" /> Medication Formulation
                  </label>
                  <input 
                    type="text" 
                    value={rxMedication}
                    onChange={(e) => setRxMedication(e.target.value)}
                    className="w-full bg-emerald-950/20 border border-emerald-900/30 focus:border-emerald-500/50 p-3 text-emerald-100 outline-none text-xs tracking-wider transition-all rounded-sm"
                    placeholder="e.g. Ibuprofen 400mg"
                  />
                </div>

                <div className="flex-1 flex flex-col">
                  <label className="text-[9px] text-emerald-500/70 tracking-[0.2em] uppercase mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-2"><FileText className="w-3 h-3" /> Prescription Details</span>
                  </label>
                  <textarea 
                    value={rxContent}
                    onChange={(e) => setRxContent(e.target.value)}
                    className="flex-1 min-h-[200px] w-full bg-emerald-950/20 border border-emerald-900/30 focus:border-emerald-500/50 p-4 text-emerald-100/80 outline-none text-xs leading-relaxed resize-none transition-all rounded-sm font-sans"
                    placeholder="Dosage, frequency, duration, clinical reasoning..."
                  />
                </div>
              </>
            )}

            {/* Submit Actions */}
            <div className="mt-auto pt-4">
              {error && (
                <div className="mb-4 p-3 bg-red-950/40 border border-red-900/50 flex items-start gap-3 rounded-sm">
                  <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                  <p className="text-[10px] text-red-400 uppercase tracking-widest leading-relaxed">{error}</p>
                </div>
              )}

              <button 
                onClick={recordMode === "auth" ? submitCase : submitPrescription}
                disabled={isProcessing || (recordMode === "prescription" && (!rxContent || !patientCode))}
                className={clsx(
                  "w-full h-12 border flex items-center justify-center gap-3 text-xs tracking-[0.2em] font-bold uppercase transition-all rounded-sm group relative overflow-hidden",
                  recordMode === "auth" 
                    ? "border-mg-primary/50 text-mg-primary hover:bg-mg-primary/10 disabled:border-slate-800 disabled:text-slate-600"
                    : "border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10 disabled:border-slate-800 disabled:text-slate-600"
                )}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]" />
                {isProcessing ? (
                  <><Terminal className="w-4 h-4 animate-pulse" /> PROCESSING PIPELINE</>
                ) : (
                  <>{recordMode === "auth" ? "INITIALIZE ADJUDICATION" : "COMMIT PRESCRIPTION"}</>
                )}
              </button>
            </div>
          </div>
        </section>

        {/* ─── CENTER: AI PROCESSING LAYER (30%) ─── */}
        <section className="w-[25%] min-w-[300px] border-r border-white/5 bg-[#020617]/70 backdrop-blur-md relative z-10 flex flex-col">
          <div className="h-14 border-b border-white/5 bg-black/20 flex items-center px-6">
            <span className="text-[9px] tracking-[0.2em] text-slate-500 uppercase flex items-center gap-2">
              <Terminal className="w-3 h-3" /> Live Telemetry
            </span>
          </div>

          <div className="flex-1 p-6 overflow-y-auto custom-scrollbar flex flex-col">
            
            {/* System State Visualizer */}
            <div className="mb-10 flex flex-col items-center pt-8">
              <div className="relative w-32 h-32 flex items-center justify-center mb-6">
                {/* Outer Ring */}
                <div className={clsx("absolute inset-0 rounded-full border border-dashed transition-all duration-700",
                  systemState === "IDLE" ? "border-slate-800 rotate-0" :
                  systemState === "PARSING" ? "border-amber-500/50 animate-[spin_4s_linear_infinite]" :
                  systemState === "VALIDATING" ? "border-mg-primary animate-[spin_2s_linear_infinite]" :
                  systemState === "EXECUTING" ? "border-purple-500 shadow-[0_0_30px_rgba(168,85,247,0.4)] animate-[spin_1s_linear_infinite]" :
                  "border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.2)] rotate-45"
                )} />
                {/* Inner Core */}
                <div className={clsx("w-16 h-16 rounded-full transition-all duration-500 flex items-center justify-center",
                  systemState === "IDLE" ? "bg-slate-900 border border-slate-800" :
                  systemState === "PARSING" ? "bg-amber-950/50 border border-amber-500/30" :
                  systemState === "VALIDATING" ? "bg-mg-primary/10 border border-mg-primary/50" :
                  systemState === "EXECUTING" ? "bg-purple-900/40 border border-purple-500" :
                  "bg-emerald-950/40 border border-emerald-500/50"
                )}>
                  <BrainCircuit className={clsx("w-6 h-6 transition-colors duration-500",
                    systemState === "IDLE" ? "text-slate-700" :
                    systemState === "PARSING" ? "text-amber-500" :
                    systemState === "VALIDATING" ? "text-mg-primary" :
                    systemState === "EXECUTING" ? "text-purple-400" :
                    "text-emerald-400"
                  )} />
                </div>
              </div>

              <div className="text-center space-y-1">
                <div className="text-[10px] tracking-[0.3em] text-slate-500 uppercase">Engine Status</div>
                <div className={clsx("text-lg font-bold tracking-widest uppercase transition-colors duration-300",
                  systemState === "IDLE" ? "text-slate-600" :
                  systemState === "PARSING" ? "text-amber-400" :
                  systemState === "VALIDATING" ? "text-mg-primary" :
                  systemState === "EXECUTING" ? "text-purple-400 animate-pulse" :
                  "text-emerald-400"
                )}>
                  {systemState}
                </div>
              </div>
            </div>

            {/* Extracted Entities Stream */}
            <div className="flex-1">
              <h3 className="text-[9px] tracking-[0.2em] text-slate-500 uppercase mb-4 border-b border-white/5 pb-2">
                Structured Entities
              </h3>
              
              <div className="space-y-2">
                {liveTags.length === 0 && systemState === "IDLE" && (
                  <div className="text-[10px] text-slate-700 uppercase tracking-widest text-center py-8">
                    Awaiting Input Stream...
                  </div>
                )}
                
                {liveTags.map((tag, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-center justify-between p-3 bg-white/[0.02] border border-white/5 rounded-sm animate-[fadeIn_0.3s_ease-out_forwards]"
                    style={{ animationDelay: `${idx * 50}ms`, opacity: 0 }}
                  >
                    <span className="text-[9px] text-slate-500 tracking-widest uppercase">{tag.label}</span>
                    <span className={clsx("text-xs font-bold tracking-wider",
                      tag.type === "demographic" ? "text-blue-400" :
                      tag.type === "symptom" ? "text-amber-400" :
                      tag.type === "duration" ? "text-purple-400" :
                      "text-slate-300"
                    )}>{tag.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ─── RIGHT: DECISION & AUDIT ENGINE (40%) ─── */}
        <section className="flex-1 bg-black/40 relative z-0 flex flex-col">
          <div className="h-14 border-b border-white/5 bg-black/40 flex items-center px-6">
            <span className="text-[9px] tracking-[0.2em] text-slate-500 uppercase flex items-center gap-2">
              <Database className="w-3 h-3" /> Audit Trail & Output
            </span>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
            
            {!result && systemState !== "EXECUTING" && (
              <div className="h-full flex flex-col items-center justify-center text-slate-700">
                <ShieldCheck className="w-16 h-16 mb-6 opacity-20" />
                <div className="h-px w-24 bg-gradient-to-r from-transparent via-slate-700/50 to-transparent mb-6" />
                <p className="text-[10px] tracking-[0.2em] uppercase">Pipeline Inactive</p>
                <p className="text-[10px] text-slate-800 tracking-widest uppercase mt-2">Initialize adjudication to view decision nodes</p>
              </div>
            )}

            {systemState === "EXECUTING" && (
              <div className="h-full flex flex-col items-center justify-center">
                <div className="w-64 space-y-6">
                  {/* Fake progress lines */}
                  {['Ingesting clinical text', 'Extracting neural vectors', 'Applying symbolic constraints', 'Generating audit trace'].map((step, i) => (
                    <div key={i} className="flex items-center gap-4 animate-[fadeIn_0.5s_ease-out_forwards]" style={{ animationDelay: `${i * 800}ms`, opacity: 0 }}>
                      <Terminal className="w-4 h-4 text-purple-500 animate-pulse" />
                      <div className="flex-1">
                        <div className="text-[10px] text-purple-400 tracking-widest uppercase mb-1">{step}</div>
                        <div className="h-0.5 w-full bg-slate-900 rounded-full overflow-hidden">
                          <div className="h-full bg-purple-500 animate-[shimmer_1s_infinite] w-1/2" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {result && result.type === "prescription_success" && (
               <div className="animate-[fadeIn_0.5s_ease-out]">
                 <div className="p-6 border-l-2 border-emerald-500 bg-emerald-950/20 mb-8 rounded-sm">
                    <h3 className="text-[10px] text-emerald-500/70 uppercase tracking-[0.2em] mb-2 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" /> System Confirmation
                    </h3>
                    <div className="text-2xl font-black text-emerald-400 tracking-widest uppercase mb-4">
                      {result.status}
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">{result.reasoning}</p>
                 </div>
                 
                 <div className="p-4 border border-white/5 bg-white/[0.02] rounded-sm">
                   <p className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-2">
                     <FileText className="w-3 h-3" /> Report ID: <span className="text-slate-300">{result.report_id}</span>
                   </p>
                 </div>
               </div>
            )}

            {result && result.evaluation && (
              <div className="animate-[fadeIn_0.5s_ease-out] max-w-2xl mx-auto pb-20">
                {/* Top Decision Banner */}
                <div className={clsx("p-8 border-l-2 bg-gradient-to-r mb-8 rounded-sm",
                  result.approved 
                    ? "border-emerald-500 from-emerald-950/40 to-transparent" 
                    : "border-red-500 from-red-950/40 to-transparent"
                )}>
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h3 className={clsx("text-[10px] uppercase tracking-[0.2em] mb-2",
                        result.approved ? "text-emerald-500/70" : "text-red-500/70"
                      )}>Final Determination</h3>
                      <div className={clsx("text-4xl font-black tracking-widest uppercase",
                        result.approved ? "text-emerald-400" : "text-red-400"
                      )}>
                        {result.status}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Confidence Score</div>
                      <div className="text-2xl font-light text-white">
                        {((result.evaluation.readiness_score / result.evaluation.maximum_possible_score) * 100).toFixed(0)}%
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-xs text-slate-300 leading-relaxed font-sans border-t border-white/5 pt-4 mt-4">
                    {result.reasoning}
                  </p>
                </div>

                {/* Rule Engine Timeline */}
                <div className="mt-12">
                  <h3 className="text-[10px] tracking-[0.2em] text-slate-500 uppercase mb-8 flex items-center gap-3">
                    <Database className="w-3 h-3" /> Logic Execution Trace
                    <div className="flex-1 h-px bg-gradient-to-r from-slate-800 to-transparent" />
                  </h3>

                  <div className="relative border-l border-slate-800 ml-4 space-y-8 pb-8">
                    {Object.entries(result.evaluation.rule_results).map(([ruleKey, ruleData]: any, idx) => (
                      <div key={ruleKey} className="relative pl-8 animate-[fadeIn_0.4s_ease-out_forwards]" style={{ animationDelay: `${idx * 100}ms`, opacity: 0 }}>
                        {/* Node Connector */}
                        <div className={clsx("absolute left-[-5px] top-1 w-2.5 h-2.5 rounded-full border-2 bg-[#020617]",
                          ruleData.passed ? "border-emerald-500" : "border-red-500"
                        )} />

                        {/* Node Content */}
                        <div className="bg-white/[0.02] border border-white/5 p-4 hover:border-white/10 transition-colors rounded-sm group">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-widest">
                              {ruleKey.replace(/_/g, " ")}
                            </h4>
                            <span className={clsx("text-[9px] px-2 py-1 uppercase tracking-[0.2em] font-bold rounded-sm",
                              ruleData.passed ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"
                            )}>
                              {ruleData.passed ? "PASS" : "FAIL"}
                            </span>
                          </div>

                          <p className="text-[11px] text-slate-400 font-sans leading-relaxed mb-4">
                            {ruleData.explanation || (ruleData.passed ? "Criteria satisfactorily met within clinical notes." : "Critical requirement missing from documentation.")}
                          </p>

                          {/* Rule Evidence Details */}
                          {ruleData.details && Object.keys(ruleData.details).length > 0 && (
                            <div className="bg-black/30 border border-slate-800 p-3 mt-3 rounded-sm">
                              {Object.entries(ruleData.details).map(([key, val]: any) => (
                                <div key={key} className="flex justify-between items-center text-[9px] mb-1.5 last:mb-0">
                                  <span className="text-slate-500 uppercase tracking-widest">{key.replace(/_/g, " ")}</span>
                                  <span className={clsx("font-mono", 
                                    val === true ? "text-emerald-400" : 
                                    val === false ? "text-red-400" : "text-slate-300"
                                  )}>
                                    {String(val).toUpperCase()}
                                  </span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

      </main>

      {/* Global CSS for Animations */}
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}} />
    </div>
  );
}

// Helper icon
function ChevronDownIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m6 9 6 6 6-6"/>
    </svg>
  )
}
