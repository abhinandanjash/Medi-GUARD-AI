"use client";

import { API_BASE } from "@/app/lib/config";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, Activity, BrainCircuit, Database, ShieldCheck, CheckCircle2, XCircle, Clock } from "lucide-react";
import clsx from "clsx";

export default function Simulator() {
  const [notes, setNotes] = useState("Patient is a 65yo male presenting with severe lower back pain and leg numbness. MRI shows L4-L5 herniation. Has tried 6 months of physical therapy and NSAIDs without relief. Recommending lumbar spinal fusion.");
  const [payer, setPayer] = useState("starhealth_spinal_fusion");
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState(0); // 0: Idle, 1: Neural, 2: Symbolic, 3: Complete
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const runSimulator = async () => {
    setIsProcessing(true);
    setStep(1);
    setError(null);
    setResult(null);

    try {
      // Create a dummy token for the simulator to pass auth
      // In a real scenario, this would use the logged-in doctor's token
      const dummyPayload = btoa(JSON.stringify({ sub: "simulator", role: "doctor" }));
      const dummyToken = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${dummyPayload}.dummy_signature`;

      // Wait a bit for the "Neural Layer" visual effect
      await new Promise((r) => setTimeout(r, 2000));
      setStep(2); // Move to Symbolic Layer

      // Actual API Call
      const res = await fetch(`${API_BASE}/api/submissions/evaluate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${dummyToken}`,
        },
        body: JSON.stringify({
          patient_code: "SIM12345",
          clinical_notes: notes,
          payer_id: payer,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Evaluation failed");
      }

      const data = await res.json();
      
      // Wait a bit for the "Symbolic Layer" visual effect
      await new Promise((r) => setTimeout(r, 1500));
      setStep(3); // Complete
      setResult(data);

    } catch (err: any) {
      setError(err.message);
      setStep(0);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-mg-bg text-white p-6 md:p-12">
      <Link href="/" className="inline-flex items-center text-slate-400 hover:text-white transition-colors mb-8">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Vault
      </Link>

      <div className="max-w-6xl mx-auto">
        <div className="mb-10">
          <h1 className="text-4xl font-bold mb-4 flex items-center">
            <Activity className="text-blue-500 mr-4" /> Live Decision Simulator
          </h1>
          <p className="text-slate-400 text-lg">Watch the Neuro-Symbolic Engine adjudicate a clinical note in real-time.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="glass-card p-8">
            <h2 className="text-2xl font-semibold mb-6 flex items-center border-b border-slate-700 pb-4">
               Raw Data Input
            </h2>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-400 mb-2">Select Insurance Policy</label>
              <select 
                value={payer} 
                onChange={(e) => setPayer(e.target.value)}
                className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="starhealth_spinal_fusion">StarHealth - Lumbar Spinal Fusion</option>
                <option value="apollohealth_knee_replacement">ApolloHealth - Knee Replacement</option>
                <option value="maxbupa_lumbar_mri">MaxBupa - Lumbar MRI</option>
              </select>
            </div>

            <div className="mb-8">
              <label className="block text-sm font-medium text-slate-400 mb-2">Unstructured Clinical Notes</label>
              <textarea 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full h-48 bg-slate-800/50 border border-slate-700 rounded-lg p-4 text-white focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm resize-none"
              />
            </div>

            <button 
              onClick={runSimulator}
              disabled={isProcessing}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 rounded-xl font-bold text-lg shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isProcessing ? (
                <><span className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-3" /> Processing...</>
              ) : (
                <>Run Adjudication</>
              )}
            </button>

            {error && (
              <div className="mt-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-200">
                {error}
              </div>
            )}
          </div>

          {/* Output Section */}
          <div className="glass-card p-8 flex flex-col">
            <h2 className="text-2xl font-semibold mb-6 flex items-center border-b border-slate-700 pb-4">
               System Pipeline
            </h2>

            <div className="flex-1 space-y-6">
              
              {/* Step 1: Neural Layer */}
              <div className={clsx("p-6 rounded-xl border transition-all duration-500", step >= 1 ? "bg-purple-900/20 border-purple-500/50" : "bg-slate-800/30 border-slate-700/50 opacity-50")}>
                <div className="flex items-center mb-4">
                  <BrainCircuit className={clsx("w-6 h-6 mr-3", step >= 1 ? "text-purple-400" : "text-slate-500")} />
                  <h3 className="font-bold text-lg">Neural Extraction Layer</h3>
                  {step === 1 && <Clock className="w-4 h-4 ml-auto text-purple-400 animate-pulse" />}
                  {step > 1 && <CheckCircle2 className="w-5 h-5 ml-auto text-green-400" />}
                </div>
                {step === 1 && (
                  <p className="text-purple-300 text-sm font-mono animate-pulse">LLM parsing unstructured text into standard JSON schema...</p>
                )}
                {step > 1 && result && (
                  <div className="bg-black/50 p-3 rounded text-xs font-mono text-green-300 overflow-x-auto">
                    {JSON.stringify(result.extracted_data, null, 2)}
                  </div>
                )}
              </div>

              {/* Step 2: Symbolic Layer */}
              <div className={clsx("p-6 rounded-xl border transition-all duration-500", step >= 2 ? "bg-blue-900/20 border-blue-500/50" : "bg-slate-800/30 border-slate-700/50 opacity-50")}>
                <div className="flex items-center mb-4">
                  <Database className={clsx("w-6 h-6 mr-3", step >= 2 ? "text-blue-400" : "text-slate-500")} />
                  <h3 className="font-bold text-lg">Symbolic Rule Engine</h3>
                  {step === 2 && <Clock className="w-4 h-4 ml-auto text-blue-400 animate-pulse" />}
                  {step > 2 && <CheckCircle2 className="w-5 h-5 ml-auto text-green-400" />}
                </div>
                {step === 2 && (
                  <p className="text-blue-300 text-sm font-mono animate-pulse">Evaluating extracted entities against deterministic policy nodes...</p>
                )}
                {step > 2 && result && (
                  <div className="space-y-2 mt-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Total Score</span>
                      <span className="font-bold text-white">{result.evaluation.readiness_score.toFixed(1)} / {result.evaluation.maximum_possible_score.toFixed(1)}</span>
                    </div>
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500" 
                        style={{ width: `${(result.evaluation.readiness_score / result.evaluation.maximum_possible_score) * 100}%` }} 
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Step 3: Output */}
              <div className={clsx("p-6 rounded-xl border transition-all duration-500", step >= 3 ? "bg-emerald-900/20 border-emerald-500/50" : "bg-slate-800/30 border-slate-700/50 opacity-50")}>
                <div className="flex items-center">
                  <ShieldCheck className={clsx("w-8 h-8 mr-4", step >= 3 ? "text-emerald-400" : "text-slate-500")} />
                  <div>
                    <h3 className="font-bold text-xl">Final Decision</h3>
                    {step === 3 && result && (
                       <p className={clsx(
                         "font-mono font-bold mt-1",
                         result.status === "SUBMISSION_READY" ? "text-green-400" :
                         result.status === "NEEDS_MORE_EVIDENCE" ? "text-amber-400" : "text-red-400"
                       )}>
                         {result.status.replace(/_/g, " ")}
                       </p>
                    )}
                    {step < 3 && <p className="text-slate-500 text-sm">Awaiting adjudication...</p>}
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
