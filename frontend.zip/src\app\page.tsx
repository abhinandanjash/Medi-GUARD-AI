"use client";

import { API_BASE } from "@/app/lib/config";

import { useEffect, useState, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ShieldCheck, Activity, BrainCircuit, Database, CheckCircle2, Clock, Terminal, Volume2, VolumeX } from "lucide-react";
import IntelligenceCore from "./components/3d/IntelligenceCore";
import { audioEngine } from "./components/3d/AudioEngine";
import Link from "next/link";
import clsx from "clsx";

/* ═══════════════════════════════════════════════════════════════════════════
   LIVE DECISION SIMULATOR — Scene 7
   Minimal glass interface. Medical-grade intelligence system feel.
═══════════════════════════════════════════════════════════════════════════ */
const DecisionSimulator = () => {
  const [notes, setNotes] = useState("Patient is a 65yo male with severe lower back pain and leg numbness. MRI shows L4-L5 herniation. Has tried 6 months of physical therapy and NSAIDs without relief. Recommending lumbar spinal fusion.");
  const [payer, setPayer] = useState("starhealth_spinal_fusion");
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState(0);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setIsProcessing(true); setStep(1); setError(null); setResult(null);
    audioEngine.pulse();
    try {
      const payload = btoa(JSON.stringify({ sub: "simulator", role: "doctor" }));
      const token = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${payload}.sig`;
      await new Promise(r => setTimeout(r, 2000));
      setStep(2);
      audioEngine.click();
      const res = await fetch(`${API_BASE}/api/submissions/evaluate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ patient_code: "SIM12345", clinical_notes: notes, payer_id: payer }),
      });
      if (!res.ok) throw new Error((await res.json()).detail || "Failed");
      const data = await res.json();
      await new Promise(r => setTimeout(r, 1500));
      setStep(3); setResult(data);
      audioEngine.confirm();
    } catch (err: any) {
      setError(err.message); setStep(0);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto mt-16">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="glass-panel p-7 relative">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/8 to-transparent" />
          <h3 className="text-[10px] text-slate-500 mb-5 uppercase tracking-[0.4em] border-b border-white/[0.03] pb-3">Input</h3>
          <div className="mb-5">
            <label className="block text-[9px] text-slate-600 mb-1.5 uppercase tracking-[0.3em]">Policy</label>
            <select value={payer} onChange={e => setPayer(e.target.value)}
              className="w-full bg-mg-bg/80 border border-white/[0.04] p-2.5 text-white/70 outline-none text-[11px] tracking-wider focus:border-white/10 transition-colors">
              <option value="starhealth_spinal_fusion">StarHealth — Lumbar Fusion</option>
              <option value="apollohealth_knee_replacement">ApolloHealth — Knee Replacement</option>
              <option value="maxbupa_lumbar_mri">MaxBupa — Lumbar MRI</option>
            </select>
          </div>
          <div className="mb-5">
            <label className="block text-[9px] text-slate-600 mb-1.5 uppercase tracking-[0.3em]">Clinical Data</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)}
              className="w-full h-28 bg-mg-bg/80 border border-white/[0.04] p-3 text-white/60 outline-none text-[11px] resize-none leading-relaxed focus:border-white/10 transition-colors" />
          </div>
          <button onClick={run} disabled={isProcessing}
            className="w-full py-3 bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.06] text-white/50 hover:text-white/80 transition-all uppercase tracking-[0.3em] text-[10px] disabled:opacity-20">
            {isProcessing ? "Processing..." : "Initialize"}
          </button>
          {error && <div className="mt-3 text-[9px] text-red-400/60 border border-red-500/15 p-2 tracking-wider">{error}</div>}
        </div>

        {/* Output */}
        <div className="glass-panel p-7 relative flex flex-col">
          <h3 className="text-[10px] text-slate-500 mb-5 uppercase tracking-[0.4em] border-b border-white/[0.03] pb-3">Telemetry</h3>
          <div className="flex-1 space-y-3">
            <div className={clsx("p-3 border transition-all duration-700", step >= 1 ? "bg-indigo-500/[0.04] border-indigo-500/15" : "border-white/[0.02] opacity-25")}>
              <div className="flex items-center">
                <BrainCircuit className={clsx("w-3.5 h-3.5 mr-2", step >= 1 ? "text-indigo-400/70" : "text-slate-800")} />
                <span className="text-[9px] uppercase tracking-[0.3em] text-slate-500">Neural Extractor</span>
                {step === 1 && <Clock className="w-2.5 h-2.5 ml-auto text-indigo-400/50 animate-spin" />}
                {step > 1 && <CheckCircle2 className="w-2.5 h-2.5 ml-auto text-indigo-400/50" />}
              </div>
              {step > 1 && result && (
                <div className="bg-black/30 p-2 mt-2 text-[8px] text-indigo-300/50 font-mono border border-indigo-500/8 overflow-x-auto max-h-20">
                  {JSON.stringify(result.extracted_data, null, 2)}
                </div>
              )}
            </div>
            <div className={clsx("p-3 border transition-all duration-700", step >= 2 ? "bg-cyan-500/[0.04] border-cyan-500/15" : "border-white/[0.02] opacity-25")}>
              <div className="flex items-center">
                <Database className={clsx("w-3.5 h-3.5 mr-2", step >= 2 ? "text-cyan-400/70" : "text-slate-800")} />
                <span className="text-[9px] uppercase tracking-[0.3em] text-slate-500">Symbolic Engine</span>
                {step === 2 && <Clock className="w-2.5 h-2.5 ml-auto text-cyan-400/50 animate-spin" />}
                {step > 2 && <CheckCircle2 className="w-2.5 h-2.5 ml-auto text-cyan-400/50" />}
              </div>
              {step > 2 && result && (
                <div className="mt-2">
                  <div className="flex justify-between text-[8px] text-cyan-400/40 tracking-wider mb-1">
                    <span>Confidence</span>
                    <span>{result.evaluation.readiness_score.toFixed(1)} / {result.evaluation.maximum_possible_score.toFixed(1)}</span>
                  </div>
                  <div className="h-[1px] bg-white/[0.03]">
                    <div className="h-full bg-cyan-500/30" style={{ width: `${(result.evaluation.readiness_score / result.evaluation.maximum_possible_score) * 100}%` }} />
                  </div>
                </div>
              )}
            </div>
            <div className={clsx("p-3 border transition-all duration-700", step >= 3 ? "bg-emerald-500/[0.04] border-emerald-500/15" : "border-white/[0.02] opacity-25")}>
              <div className="flex items-center">
                <ShieldCheck className={clsx("w-4 h-4 mr-2", step >= 3 ? "text-emerald-400/70" : "text-slate-800")} />
                <div>
                  <span className="text-[9px] uppercase tracking-[0.3em] text-slate-500">Decision</span>
                  {step === 3 && result && (
                    <p className={clsx("text-sm font-light mt-0.5 tracking-wider",
                      result.status === "SUBMISSION_READY" ? "text-emerald-400/70" :
                      result.status === "NEEDS_MORE_EVIDENCE" ? "text-amber-400/70" : "text-red-400/70"
                    )}>{result.status}</p>
                  )}
                  {step < 3 && <p className="text-[8px] text-slate-800 mt-0.5 tracking-wider">Awaiting</p>}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   NEURO-SIGNAL TRANSITIONS — 3-Layer Precision Transition System
   Layer 1: Optical Fade (base, via GSAP)
   Layer 2: Neuro Signal Sweep (thin line)
   Layer 3: State Transition (system readout text)
═══════════════════════════════════════════════════════════════════════════ */
const STATE_SEQUENCES = [
  ["Initializing", "Parsing Data", "Validating", "Completed"],
  ["Data Ingestion", "Structuring", "Encoding", "Indexed"],
  ["Neural Activation", "Signal Mapping", "Entity Extraction", "Verified"],
  ["Rule Loading", "Policy Matching", "Constraint Check", "Resolved"],
  ["Audit Start", "Node Linking", "Chain Building", "Proof Generated"],
  ["Convergence", "Logic Assembly", "Decision Formed", "Output Ready"],
  ["System Live", "Engine Active", "Monitoring", "Standby"],
];

const NeuroSignalTransition = () => {
  const [active, setActive] = useState(false);
  const [sweepX, setSweepX] = useState(-100);          // % from left
  const [stateLabel, setStateLabel] = useState("");
  const [stateVisible, setStateVisible] = useState(false);
  const sequenceRef = useRef(0);

  const trigger = () => {
    if (active) return;
    setActive(true);

    const seq = STATE_SEQUENCES[sequenceRef.current % STATE_SEQUENCES.length];
    sequenceRef.current++;

    // --- Layer 2: Neuro Signal Sweep ---
    setSweepX(-5); // start just off left
    setTimeout(() => setSweepX(105), 50);  // sweep to right, takes 1.4s via CSS transition

    // --- Layer 3: State Readout ---
    seq.forEach((label, i) => {
      setTimeout(() => {
        setStateLabel(label);
        setStateVisible(true);
      }, i * 320);
    });
    // Fade out state label
    setTimeout(() => setStateVisible(false), seq.length * 320 + 200);
    setTimeout(() => setSweepX(-100), 1600);
    setTimeout(() => setActive(false), 1700);
  };

  useEffect(() => {
    window.addEventListener("trigger-neuro", trigger);
    return () => window.removeEventListener("trigger-neuro", trigger);
  }, [active]);

  return (
    <>
      {/* Layer 2: Neuro Signal Sweep — thin horizontal light line */}
      <div
        className="fixed top-0 left-0 h-full w-[2px] pointer-events-none z-50"
        style={{
          left: `${sweepX}%`,
          transition: sweepX === 105 ? "left 1.4s cubic-bezier(0.25, 0.1, 0.25, 1)" : "none",
          background: "linear-gradient(to bottom, transparent 0%, rgba(8,145,178,0.0) 10%, rgba(6,182,212,0.35) 40%, rgba(8,145,178,0.5) 50%, rgba(6,182,212,0.35) 60%, rgba(8,145,178,0.0) 90%, transparent 100%)",
          boxShadow: "0 0 12px 2px rgba(6,182,212,0.15), 0 0 30px 5px rgba(8,145,178,0.08)",
          filter: "blur(0.5px)",
        }}
      />

      {/* Layer 3: State Transition Readout */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
        <div
          style={{
            opacity: stateVisible ? 1 : 0,
            transform: stateVisible ? "translateY(0)" : "translateY(4px)",
            transition: "opacity 0.3s ease, transform 0.3s ease",
          }}
          className="flex items-center gap-2"
        >
          <div className="w-1 h-1 rounded-full bg-cyan-500/60 animate-pulse" />
          <span className="text-[9px] font-mono tracking-[0.5em] uppercase text-cyan-500/50">
            {stateLabel}
          </span>
        </div>
      </div>
    </>
  );
};

/* ═══════════════════════════════════════════════════════════════════════════
   MAIN PAGE — 7-section scroll experience with cinematic text
═══════════════════════════════════════════════════════════════════════════ */
export default function Home() {
  const [audioEnabled, setAudioEnabled] = useState(false);
  const scrollRef = useRef(0);
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });

  const toggleAudio = () => {
    if (!audioEnabled) {
      audioEngine.init();
      audioEngine.resume();
      audioEngine.startAmbient();
      setAudioEnabled(true);
    }
  };

  // Track scroll for audio triggers
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const docH = document.documentElement.scrollHeight - window.innerHeight;
      const progress = scrollY / docH;

      // Audio triggers at scene boundaries
      if (audioEnabled) {
        const prev = scrollRef.current;
        if (prev < 0.28 && progress >= 0.28) audioEngine.swell();  // Brain peak
        if (prev < 0.42 && progress >= 0.42) audioEngine.click();   // Rule engine
        if (prev < 0.58 && progress >= 0.58) audioEngine.tick();    // Audit network
        if (prev < 0.72 && progress >= 0.72) audioEngine.confirm(); // Decision
      }
      scrollRef.current = progress;
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    
    // Parallax Foreground
    const handleMouse = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 20; // 20px max shift
      const y = (e.clientY / window.innerHeight - 0.5) * 20;
      setMouseOffset({ x, y });
    };
    window.addEventListener("mousemove", handleMouse, { passive: true });
    
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("mousemove", handleMouse);
    };
  }, [audioEnabled]);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const sections = gsap.utils.toArray<HTMLElement>(".reveal");
    sections.forEach((sec, i) => {
      gsap.fromTo(sec,
        // Layer 1: Optical Fade — soft opacity, blur, minimal scale
        { opacity: 0, y: 22, scale: 0.985, filter: "blur(5px)" },
        { opacity: 1, y: 0, scale: 1, filter: "blur(0px)", duration: 1.8, ease: "power2.inOut",
          scrollTrigger: {
            trigger: sec, start: "top 88%", end: "bottom 12%",
            toggleActions: "play reverse play reverse",
            onEnter: () => window.dispatchEvent(new Event("trigger-neuro")),
            onEnterBack: () => window.dispatchEvent(new Event("trigger-neuro")),
          },
        }
      );
    });
  }, []);

  return (
    <main className="relative bg-mg-bg text-white overflow-x-hidden selection:bg-white/10 selection:text-white">
      <IntelligenceCore />
      <NeuroSignalTransition />

      {/* Audio Toggle */}
      <button onClick={toggleAudio}
        className="fixed top-6 right-6 z-50 w-10 h-10 flex items-center justify-center border border-white/[0.06] bg-mg-bg/50 backdrop-blur-xl text-white/30 hover:text-white/80 hover:bg-white/[0.05] transition-all duration-500 pointer-events-auto rounded-full"
        aria-label="Toggle audio">
        {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
      </button>

      {/* Parallax Container */}
      <div id="scroll-container" 
           className="relative z-10 w-full transition-transform duration-100 ease-out"
           style={{ transform: `translate3d(${-mouseOffset.x}px, ${-mouseOffset.y}px, 0)` }}>

        {/* ── 1: CORE REVEAL ─────────────────────────────────── */}
        <section className="h-screen w-full flex flex-col items-center justify-center px-6 relative pointer-events-none">
          <div className="absolute top-8 left-8 flex items-center gap-2.5 opacity-30">
            <ShieldCheck className="w-3.5 h-3.5 text-white/40" />
            <span className="text-[9px] font-mono tracking-[0.6em] uppercase text-white/30">Medi-Guard AI</span>
          </div>
          <div className="reveal max-w-xl mx-auto text-center">
            <h1 className="text-3xl md:text-5xl font-extralight tracking-tight mb-7 text-white/85 leading-[1.2]">
              Every Medical Decision.<br/>
              <span className="font-normal">Verified.</span>
            </h1>
            <p className="text-[10px] text-slate-600 font-mono tracking-[0.4em] max-w-sm mx-auto leading-relaxed uppercase">
              Neuro-symbolic intelligence for<br/>zero-hallucination adjudication
            </p>
          </div>
          <div className="absolute bottom-16 left-1/2 -translate-x-1/2 opacity-20">
            <div className="w-[1px] h-8 bg-gradient-to-b from-white/20 to-transparent" />
          </div>
        </section>

        {/* ── 2: DATA INGESTION ──────────────────────────────── */}
        <section className="h-screen w-full flex items-center px-8 md:px-20 pointer-events-none">
          <div className="reveal max-w-xs">
            <p className="text-[8px] font-mono tracking-[0.8em] text-white/15 mb-4">01</p>
            <h2 className="text-xl md:text-2xl font-extralight mb-4 text-white/75 leading-tight tracking-tight">
              Data Ingestion
            </h2>
            <p className="text-slate-700 text-[11px] leading-[2] font-light">
              Raw clinical text enters the system. Unstructured notes transform into precision intelligence streams.
            </p>
          </div>
        </section>

        {/* ── 3: NEURAL BRAIN — VISUAL PEAK 1 ────────────────── */}
        <section className="h-screen w-full flex items-center justify-end px-8 md:px-20 pointer-events-none">
          <div className="reveal max-w-xs text-right">
            <p className="text-[8px] font-mono tracking-[0.8em] text-white/15 mb-4">02</p>
            <h2 className="text-xl md:text-2xl font-extralight mb-4 text-white/75 leading-tight tracking-tight">
              From data…<br/>to understanding.
            </h2>
            <p className="text-slate-700 text-[11px] leading-[2] font-light">
              Neural networks form structured intelligence. Controlled signal pulses extract precise medical entities without hallucination.
            </p>
          </div>
        </section>

        {/* ── 4: RULE ENGINE ─────────────────────────────────── */}
        <section className="h-screen w-full flex items-center px-8 md:px-20 pointer-events-none">
          <div className="reveal max-w-xs">
            <p className="text-[8px] font-mono tracking-[0.8em] text-white/15 mb-4">03</p>
            <h2 className="text-xl md:text-2xl font-extralight mb-4 text-white/75 leading-tight tracking-tight">
              Understanding<br/>is not enough.
            </h2>
            <p className="text-slate-700 text-[11px] leading-[2] font-light">
              Deterministic rules activate with mechanical precision. Every fact verified against exact policy nodes. No probabilistic guessing.
            </p>
          </div>
        </section>

        {/* ── 5: AUDIT NETWORK — VISUAL PEAK 2 ───────────────── */}
        <section className="h-screen w-full flex items-center justify-end px-8 md:px-20 pointer-events-none">
          <div className="reveal max-w-xs text-right">
            <p className="text-[8px] font-mono tracking-[0.8em] text-white/15 mb-4">04</p>
            <h2 className="text-xl md:text-2xl font-extralight mb-4 text-white/75 leading-tight tracking-tight">
              Understanding…<br/>proven.
            </h2>
            <p className="text-slate-700 text-[11px] leading-[2] font-light">
              Every pathway is documented. Every decision has a proof trail. The audit network makes trust visible.
            </p>
          </div>
        </section>

        {/* ── 6: DECISION OUTPUT ──────────────────────────────── */}
        <section className="h-screen w-full flex items-center justify-center px-8 md:px-20 pointer-events-none">
          <div className="reveal max-w-md text-center">
            <p className="text-[8px] font-mono tracking-[0.8em] text-white/15 mb-4">05</p>
            <h2 className="text-xl md:text-2xl font-extralight mb-4 text-white/75 leading-tight tracking-tight">
              Every decision is constructed.<br/>Not guessed.
            </h2>
            <p className="text-slate-700 text-[11px] leading-[2] font-light max-w-xs mx-auto">
              Energy converges. Audit trails remain visible. The verdict forms through provable logic, not statistical approximation.
            </p>
          </div>
        </section>

        {/* ── 7: SIMULATOR + PORTALS ─────────────────────────── */}
        <section className="min-h-screen w-full bg-gradient-to-b from-transparent via-mg-bg/95 to-mg-bg border-t border-white/[0.02] py-28 px-6 relative z-20" style={{ backdropFilter: "blur(80px)" }}>
          <div className="reveal text-center max-w-md mx-auto mb-16">
            <h2 className="text-xl md:text-2xl font-extralight mb-4 text-white/70 tracking-tight">
              Experience the system.
            </h2>
            <p className="text-slate-700 text-[10px] tracking-[0.4em] uppercase">Live adjudication demonstration</p>
          </div>

          <DecisionSimulator />

          {/* PORTAL ACCESS */}
          <div className="w-full max-w-5xl mx-auto mt-28 reveal">
            <div className="text-center mb-10">
              <h2 className="text-lg font-extralight text-white/60 tracking-wider mb-1">System Access</h2>
              <p className="text-slate-800 text-[9px] tracking-[0.5em] uppercase">Authenticate to Initialize Portal</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {[
                { role: "doctor", label: "Doctor", icon: Activity },
                { role: "insurer", label: "Insurer", icon: Database },
                { role: "patient", label: "Patient", icon: CheckCircle2 },
                { role: "hospital", label: "Hospital", icon: ShieldCheck },
                { role: "pharma", label: "Pharmacy", icon: Database },
              ].map(p => (
                <Link key={p.role} href={`/auth/login?role=${p.role}`}
                  className="glass-panel p-5 text-center group hover:border-white/15 hover:bg-white/[0.02] transition-all duration-700 relative overflow-hidden">
                  <div className="absolute inset-0 bg-mg-glow/0 group-hover:bg-mg-glow/5 transition-colors duration-700" />
                  <div className="w-10 h-10 mx-auto mb-3 border border-white/[0.04] flex items-center justify-center rounded-full group-hover:border-mg-glow/30 group-hover:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all duration-700 relative z-10">
                    <p.icon className="w-4 h-4 text-white/20 group-hover:text-mg-glow transition-colors duration-700" />
                  </div>
                  <h3 className="text-[10px] text-white/60 font-light tracking-[0.2em] uppercase mb-1.5 relative z-10 group-hover:text-white transition-colors duration-700">{p.label}</h3>
                  <span className="text-white/12 text-[8px] tracking-[0.4em] uppercase group-hover:text-mg-glow/70 transition-colors duration-700 relative z-10">
                    Enter
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>

      </div>
    </main>
  );
}
