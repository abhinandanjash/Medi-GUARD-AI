"use client";

import { useRef, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, Sparkles, PerspectiveCamera } from "@react-three/drei";
import * as THREE from "three";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

// Register ScrollTrigger
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

const VaultCorridor = () => {
  const cameraGroup = useRef<THREE.Group>(null);
  const capsuleRef = useRef<THREE.Mesh>(null);
  const coreRef = useRef<THREE.Mesh>(null);
  const gridRef = useRef<THREE.Group>(null);

  useEffect(() => {
    if (!cameraGroup.current) return;

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: "#scroll-container",
        start: "top top",
        end: "bottom bottom",
        scrub: 1, // Smooth scrubbing
      },
    });

    // Scene 1: Raw Data (Camera at z = 15)
    // Scene 2: Neural Core (Camera moves to z = 5)
    tl.to(cameraGroup.current.position, {
      z: 5,
      ease: "power1.inOut",
    }, 0);

    // Scene 3: Symbolic Rule Engine (Camera moves to z = -5)
    tl.to(cameraGroup.current.position, {
      z: -5,
      ease: "power1.inOut",
    }, 1);

    // Scene 4: Decision Output (Camera moves to z = -15)
    tl.to(cameraGroup.current.position, {
      z: -15,
      ease: "power1.inOut",
    }, 2);

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <>
      <group ref={cameraGroup} position={[0, 0, 15]}>
        <PerspectiveCamera makeDefault position={[0, 0, 0]} fov={50} />
        <pointLight position={[0, 2, 0]} intensity={2} color="#3b82f6" />
      </group>

      <ambientLight intensity={0.1} />
      <directionalLight position={[10, 10, 5]} intensity={0.5} />

      {/* Floating Sparkles for Atmosphere */}
      <Sparkles count={500} scale={20} size={2} speed={0.4} opacity={0.2} color="#60a5fa" />

      {/* Scene 1: Glass Capsule (Z: 10) */}
      <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
        <mesh ref={capsuleRef} position={[0, 0, 10]}>
          <capsuleGeometry args={[1, 2.5, 4, 16]} />
          <meshPhysicalMaterial 
            color="#ffffff"
            transmission={0.9}
            opacity={1}
            metalness={0.1}
            roughness={0.1}
            ior={1.5}
            thickness={0.5}
            envMapIntensity={1}
          />
          {/* Inner raw data representation */}
          <mesh>
            <boxGeometry args={[0.8, 1.5, 0.8]} />
            <meshStandardMaterial color="#ef4444" wireframe />
          </mesh>
        </mesh>
      </Float>

      {/* Scene 2: Neural Core (Z: 0) */}
      <Float speed={3} rotationIntensity={1} floatIntensity={2}>
        <mesh ref={coreRef} position={[0, 0, 0]}>
          <icosahedronGeometry args={[1.5, 1]} />
          <meshStandardMaterial color="#8b5cf6" wireframe emissive="#8b5cf6" emissiveIntensity={0.5} />
        </mesh>
      </Float>

      {/* Scene 3: Symbolic Grid (Z: -10) */}
      <group ref={gridRef} position={[0, -2, -10]}>
        <gridHelper args={[20, 20, "#3b82f6", "#1e3a8a"]} />
        <mesh position={[0, 2, 0]}>
          <boxGeometry args={[2, 2, 2]} />
          <meshStandardMaterial color="#10b981" metalness={0.8} roughness={0.2} />
        </mesh>
      </group>

      <Environment preset="city" />
    </>
  );
};

export default function DecisionVault() {
  return (
    <div className="fixed inset-0 w-full h-full z-0 pointer-events-none bg-mg-bg">
      <Canvas dpr={[1, 2]}>
        <VaultCorridor />
      </Canvas>
    </div>
  );
}
