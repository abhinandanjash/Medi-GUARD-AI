import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: "Medi-Guard AI | Decision Vault",
  description: "Neuro-Symbolic Medical Prior-Authorization System. Every Medical Decision. Verified.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} font-sans antialiased bg-mg-bg text-white`}>
        {children}
      </body>
    </html>
  );
}
