// ─── Medi-Guard AI: Centralized Configuration ───────────────────────────────
// API_BASE reads from NEXT_PUBLIC_API_URL at build time.
// Development: http://localhost:8000  (set in .env.local)
// Production:  https://api.mediguard.site  (set in .env.production)

export const API_BASE =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
