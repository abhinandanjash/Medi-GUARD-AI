"use client";

import { API_BASE } from "@/app/lib/config";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, ShieldCheck, Clock, LogOut, Terminal, Activity, DollarSign, FileText, Pill, XCircle, BrainCircuit, AlertTriangle } from "lucide-react";
import clsx from "clsx";

export default function PatientDashboard() {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Financial & Records state
  const [bills, setBills] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [recordsLoading, setRecordsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"auth" | "prescriptions" | "bills" | "reports">("auth");
  const [patientCode, setPatientCode] = useState<string | null>(null);

  // Prescriptions state
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [adjudications, setAdjudications] = useState<any[]>([]);

  useEffect(() => {
    const storedToken = localStorage.getItem("mg_token");
    if (!storedToken) {
      router.push("/auth/login?role=patient");
    } else {
      setToken(storedToken);
      fetchDashboard(storedToken);
    }
  }, [router]);

  const fetchDashboard = async (authToken: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/dashboard`, {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      if (!res.ok) throw new Error("Failed to fetch dashboard");
      const data = await res.json();
      setSubmissions(data.submissions || []);

      // Extract patient_code from JWT payload
      try {
        const payload = JSON.parse(atob(authToken.split(".")[1]));
        if (payload.patient_code) {
          setPatientCode(payload.patient_code);
          fetchRecords(authToken, payload.patient_code);
          fetchPrescriptions(authToken, payload.patient_code);
        }
      } catch (_) {}
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecords = async (authToken: string, code: string) => {
    setRecordsLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/patients/${code}/records`, {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      if (!res.ok) return;
      const data = await res.json();
      setBills(data.bills || []);
      setReports(data.reports || []);
    } catch (_) {}
    finally { setRecordsLoading(false); }
  };

  const fetchPrescriptions = async (authToken: string, code: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/patients/${code}/prescriptions`, {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      if (!res.ok) return;
      const data = await res.json();
      setPrescriptions(data.prescriptions || []);
      setAdjudications(data.adjudications || []);
    } catch (_) {}
  };

  const handleLogout = () => {
    localStorage.removeItem("mg_token");
    router.push("/");
  };

  const totalBills = bills.reduce((sum, b) => sum + b.amount, 0);

  // Helper: find adjudication for a given prescription's clinical notes
  const getAdjudicationForRx = (rxContent: string) => {
    return adjudications.find(a => a.clinical_notes === rxContent);
  };

  if (!token) return null;

  return (
    <div className="min-h-screen bg-mg-bg text-white font-mono bg-grid pb-20">
      {/* Header */}
      <header className="border-b border-emerald-500/30 bg-mg-bg/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-bold tracking-widest uppercase text-emerald-400">Patient Portal</span>
          </div>
          <div className="flex items-center gap-6 text-xs tracking-widest uppercase">
            {patientCode && <span className="text-emerald-400/70">[{patientCode}]</span>}
            <span className="text-emerald-400/70">Session Active</span>
            <button onClick={handleLogout} className="flex items-center text-red-400 hover:text-red-300 transition-colors">
              <LogOut className="w-4 h-4 mr-2" /> Disconnect
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 mt-12">
        <div className="mb-10">
          <h1 className="text-3xl font-bold mb-2 text-white tracking-widest uppercase flex items-center gap-3">
            <Activity className="w-8 h-8 text-emerald-400" /> Health Dashboard
          </h1>
          <p className="text-emerald-400/70 text-sm tracking-widest uppercase">Track prescriptions, authorizations, bills, and medical reports.</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="glass-panel p-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-emerald-500 to-transparent opacity-50" />
            <span className="text-[9px] text-slate-500 uppercase tracking-widest">Prescriptions</span>
            <p className="text-2xl font-black text-emerald-400 mt-1 tracking-widest">{prescriptions.length}</p>
          </div>
          <div className="glass-panel p-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-mg-glow to-transparent opacity-50" />
            <span className="text-[9px] text-slate-500 uppercase tracking-widest">Adjudications</span>
            <p className="text-2xl font-black text-mg-glow mt-1 tracking-widest">{submissions.length}</p>
          </div>
          <div className="glass-panel p-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-amber-500 to-transparent opacity-50" />
            <span className="text-[9px] text-slate-500 uppercase tracking-widest">Total Billed</span>
            <p className="text-2xl font-black text-amber-500 mt-1 tracking-widest">${totalBills.toFixed(2)}</p>
          </div>
          <div className="glass-panel p-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-purple-500 to-transparent opacity-50" />
            <span className="text-[9px] text-slate-500 uppercase tracking-widest">Reports</span>
            <p className="text-2xl font-black text-purple-400 mt-1 tracking-widest">{reports.length}</p>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex flex-wrap gap-3 mb-8">
          <button onClick={() => setActiveTab("prescriptions")} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all flex items-center gap-2", activeTab === "prescriptions" ? "bg-emerald-500/20 border-emerald-500 text-emerald-400" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            <Pill className="w-3.5 h-3.5" /> Prescriptions
          </button>
          <button onClick={() => setActiveTab("auth")} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all", activeTab === "auth" ? "bg-mg-glow/20 border-mg-glow text-mg-glow" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            Policy Decisions
          </button>
          <button onClick={() => setActiveTab("bills")} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all", activeTab === "bills" ? "bg-amber-500/20 border-amber-500 text-amber-500" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            Financial Ledger
          </button>
          <button onClick={() => setActiveTab("reports")} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all", activeTab === "reports" ? "bg-purple-500/20 border-purple-500 text-purple-400" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            Medical Reports
          </button>
        </div>

        {error && <div className="p-4 bg-red-500/10 border border-red-500/50 text-red-500 mb-8 uppercase text-sm">ERR: {error}</div>}

        {loading ? (
          <div className="flex justify-center items-center h-64 text-emerald-400">
            <Terminal className="w-8 h-8 animate-pulse mr-3" />
            <span className="tracking-widest uppercase animate-pulse">Syncing Telemetry...</span>
          </div>
        ) : (
          <>
            {/* ═══ PRESCRIPTIONS TAB ═══ */}
            {activeTab === "prescriptions" && (
              <div className="grid gap-5">
                {prescriptions.length > 0 ? prescriptions.map((rx) => {
                  const adj = getAdjudicationForRx(rx.content);
                  return (
                    <div key={rx.id} className="glass-panel relative overflow-hidden">
                      <div className="absolute left-0 top-0 w-1 h-full bg-emerald-500" />
                      <div className="p-6 pl-8">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <Pill className="w-5 h-5 text-emerald-400" />
                            <div>
                              <h4 className="text-sm font-bold tracking-widest uppercase text-emerald-400">Prescription</h4>
                              <p className="text-[10px] text-slate-500 uppercase tracking-widest">Doctor: {rx.submitted_by} • {new Date(rx.timestamp).toLocaleString()}</p>
                            </div>
                          </div>
                          {adj && (
                            <div className={clsx("px-4 py-2 border text-xs font-bold uppercase tracking-widest",
                              adj.status.includes("APPROVED") || adj.status === "SUBMISSION_READY" ? "border-emerald-500/50 text-emerald-400 bg-emerald-500/10" :
                              adj.status.includes("DENIED") ? "border-red-500/50 text-red-400 bg-red-500/10" : "border-amber-500/50 text-amber-400 bg-amber-500/10"
                            )}>
                              {adj.status}
                            </div>
                          )}
                        </div>

                        <div className="text-xs text-slate-300 bg-black/40 p-4 border border-slate-800 whitespace-pre-wrap leading-relaxed mb-3">
                          {rx.content}
                        </div>

                        {adj && adj.audit_trail && (
                          (() => {
                            let rules = null;
                            try {
                              const parsed = typeof adj.audit_trail === "string" ? JSON.parse(adj.audit_trail) : adj.audit_trail;
                              rules = parsed.rule_results;
                            } catch(e) {}
                            
                            return rules ? (
                              <div className="p-3 border border-mg-glow/15 bg-mg-glow/5 mt-3">
                                <h5 className="text-[9px] text-mg-glow/50 uppercase tracking-widest mb-2">Policy Evaluation</h5>
                                <div className="space-y-1.5">
                                  {Object.entries(rules).map(([rule, res]: any) => (
                                    <div key={rule} className="flex items-center justify-between text-[9px] border-b border-slate-800/50 pb-1">
                                      <span className="text-slate-500 uppercase">{rule.replace(/_/g, " ")}</span>
                                      {res.passed ? (
                                        <span className="text-emerald-400 flex items-center gap-1"><CheckCircle2 className="w-2.5 h-2.5" /> Pass</span>
                                      ) : (
                                        <span className="text-red-400 flex items-center gap-1"><XCircle className="w-2.5 h-2.5" /> Fail</span>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ) : null;
                          })()
                        )}

                        {!adj && (
                          <div className="p-3 border border-slate-800 text-center">
                            <span className="text-[10px] text-slate-600 uppercase tracking-widest">Awaiting insurer review</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                }) : (
                  <div className="text-center p-12 glass-panel text-slate-500 uppercase tracking-widest">
                    No prescriptions found. Visit your doctor to get started.
                  </div>
                )}
              </div>
            )}

            {/* ═══ POLICY DECISIONS TAB ═══ */}
            {activeTab === "auth" && (
              <div className="grid gap-6">
                {submissions.map((sub) => (
                  <div key={sub.id} className="glass-panel p-8 relative overflow-hidden group">
                    <div className={clsx(
                      "absolute left-0 top-0 w-2 h-full",
                      sub.status.includes("APPROVED") || sub.status === "SUBMISSION_READY" ? "bg-emerald-500 shadow-[0_0_15px_#10b981]" :
                      sub.status.includes("DENIED") ? "bg-red-500 shadow-[0_0_15px_#ef4444]" : "bg-amber-500 shadow-[0_0_15px_#f59e0b]"
                    )} />
                    
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pl-4">
                      <div>
                        <h3 className="text-xl font-bold tracking-widest uppercase mb-2 text-white">Policy Decision</h3>
                        <p className="text-sm text-slate-400 uppercase tracking-widest flex items-center mb-1">
                          <Clock className="w-4 h-4 mr-2 text-emerald-400" /> {new Date(sub.timestamp).toLocaleString()}
                        </p>
                        <p className="text-sm text-slate-400 uppercase tracking-widest flex items-center">
                          <ShieldCheck className="w-4 h-4 mr-2 text-emerald-400" /> Policy: {sub.insurer_id}
                        </p>
                        <p className="text-sm text-slate-400 uppercase tracking-widest flex items-center mt-1">
                          <BrainCircuit className="w-4 h-4 mr-2 text-mg-glow" /> Doctor: {sub.doctor_id}
                        </p>
                      </div>

                      <div className={clsx(
                        "px-8 py-6 border backdrop-blur-md flex flex-col items-center justify-center min-w-[250px]",
                        sub.status.includes("APPROVED") || sub.status === "SUBMISSION_READY" ? "bg-emerald-500/10 border-emerald-500/50" :
                        sub.status.includes("DENIED") ? "bg-red-500/10 border-red-500/50" : "bg-amber-500/10 border-amber-500/50"
                      )}>
                        <span className="text-[10px] text-slate-400 tracking-widest uppercase mb-2">Final Output</span>
                        <span className={clsx(
                          "text-xl font-black tracking-widest uppercase",
                          sub.status.includes("APPROVED") || sub.status === "SUBMISSION_READY" ? "text-emerald-400" :
                          sub.status.includes("DENIED") ? "text-red-500" : "text-amber-400"
                        )}>
                          [{sub.status}]
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
                
                {submissions.length === 0 && (
                  <div className="text-center p-12 glass-panel text-slate-500 uppercase tracking-widest">
                    No policy decisions on file.
                  </div>
                )}
              </div>
            )}

            {/* ═══ FINANCIAL LEDGER TAB ═══ */}
            {activeTab === "bills" && (
              <div>
                {recordsLoading ? (
                  <div className="flex justify-center items-center h-32 text-amber-500">
                    <Terminal className="w-6 h-6 animate-pulse mr-3" />
                    <span className="tracking-widest uppercase animate-pulse text-sm">Fetching Ledger...</span>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {bills.map((bill) => (
                      <div key={bill.id} className="glass-panel p-6 relative overflow-hidden">
                        <div className={clsx(
                          "absolute left-0 top-0 w-1 h-full",
                          bill.bill_type === "inpatient" ? "bg-red-500" :
                          bill.bill_type === "outpatient" ? "bg-amber-500" : "bg-purple-500"
                        )} />
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pl-4">
                          <div>
                            <div className="flex items-center gap-3 mb-1">
                              <span className={clsx(
                                "text-[10px] px-3 py-1 border uppercase tracking-widest font-bold",
                                bill.bill_type === "inpatient" ? "border-red-500/50 text-red-400 bg-red-500/10" :
                                bill.bill_type === "outpatient" ? "border-amber-500/50 text-amber-400 bg-amber-500/10" : "border-purple-500/50 text-purple-400 bg-purple-500/10"
                              )}>{bill.bill_type}</span>
                              <span className="text-[10px] text-slate-500 tracking-widest">{new Date(bill.timestamp).toLocaleDateString()}</span>
                            </div>
                            <p className="text-sm text-slate-300 mt-2">{bill.description}</p>
                            <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Provider: {bill.submitted_by}</p>
                          </div>
                          <div className="text-right">
                            <DollarSign className="w-4 h-4 text-amber-500 inline mr-1" />
                            <span className="text-2xl font-black text-amber-500 tracking-widest">{bill.amount.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {bills.length === 0 && (
                      <div className="text-center p-12 glass-panel text-slate-500 uppercase tracking-widest">
                        No financial records found.
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* ═══ MEDICAL REPORTS TAB ═══ */}
            {activeTab === "reports" && (
              <div>
                {recordsLoading ? (
                  <div className="flex justify-center items-center h-32 text-mg-glow">
                    <Terminal className="w-6 h-6 animate-pulse mr-3" />
                    <span className="tracking-widest uppercase animate-pulse text-sm">Fetching Reports...</span>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {reports.filter(r => r.report_type !== "prescription").map((report) => (
                      <div key={report.id} className="glass-panel p-6 relative overflow-hidden">
                        <div className="absolute left-0 top-0 w-1 h-full bg-purple-500" />
                        <div className="pl-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <FileText className="w-4 h-4 text-purple-400" />
                              <span className="text-xs font-bold text-purple-400 uppercase tracking-widest">{report.report_type}</span>
                            </div>
                            <span className="text-[10px] text-slate-500 tracking-widest">{new Date(report.timestamp).toLocaleDateString()}</span>
                          </div>
                          <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-3">Facility: {report.submitted_by}</p>
                          <div className="text-xs text-slate-300 bg-black/40 p-4 border border-slate-800 whitespace-pre-wrap leading-relaxed">
                            {report.content}
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {reports.filter(r => r.report_type !== "prescription").length === 0 && (
                      <div className="text-center p-12 glass-panel text-slate-500 uppercase tracking-widest">
                        No medical reports found.
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
