"use client";

import { API_BASE } from "@/app/lib/config";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ShieldCheck, Terminal, BrainCircuit, Database, CheckCircle2, FileText, LogOut, Phone, UserPlus } from "lucide-react";
import clsx from "clsx";

export default function HospitalDashboard() {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  
  const [patientCode, setPatientCode] = useState("PT-12345");
  const [notes, setNotes] = useState("Patient requires extended facility stay due to post-operative complications following spinal fusion. Recommending additional 4 days of inpatient observation.");
  const [payer, setPayer] = useState("starhealth_spinal_fusion");
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  
  // New State for Bills and Reports
  const [recordMode, setRecordMode] = useState<"auth" | "bill" | "report" | "register">("auth");
  const [billAmount, setBillAmount] = useState("");
  const [billType, setBillType] = useState("inpatient");
  const [billDesc, setBillDesc] = useState("");
  const [reportType, setReportType] = useState("discharge");
  const [reportContent, setReportContent] = useState("");
  const [recordSuccess, setRecordSuccess] = useState<string | null>(null);

  // State for Patient Registration
  const [regPhone, setRegPhone] = useState("");
  const [regName, setRegName] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regResult, setRegResult] = useState<any>(null);

  useEffect(() => {
    const storedToken = localStorage.getItem("mg_token");
    if (!storedToken) {
      router.push("/auth/login?role=hospital");
    } else {
      setToken(storedToken);
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("mg_token");
    router.push("/");
  };

  const submitCase = async () => {
    if (!token) return;
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch(`${API_BASE}/api/submissions/evaluate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          patient_code: patientCode,
          clinical_notes: notes,
          payer_id: payer,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Submission failed");
      }

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const submitBill = async () => {
    if (!token) return;
    setIsProcessing(true);
    setError(null);
    setRecordSuccess(null);

    try {
      const res = await fetch(`${API_BASE}/api/patients/${patientCode}/bills`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          amount: parseFloat(billAmount),
          bill_type: billType,
          description: billDesc,
        }),
      });

      if (!res.ok) throw new Error((await res.json()).detail || "Bill submission failed");
      setRecordSuccess("Financial Bill logged successfully to the ledger.");
      setBillAmount("");
      setBillDesc("");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const submitReport = async () => {
    if (!token) return;
    setIsProcessing(true);
    setError(null);
    setRecordSuccess(null);

    try {
      const res = await fetch(`${API_BASE}/api/patients/${patientCode}/reports`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          report_type: reportType,
          content: reportContent,
        }),
      });

      if (!res.ok) throw new Error((await res.json()).detail || "Report submission failed");
      setRecordSuccess("Medical Report securely logged to patient record.");
      setReportContent("");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const registerPatient = async () => {
    if (!token) return;
    setIsProcessing(true);
    setError(null);
    setRegResult(null);
    setRecordSuccess(null);

    try {
      const res = await fetch(`${API_BASE}/api/patients/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          phone_number: regPhone,
          full_name: regName,
          password: regPassword || undefined,
        }),
      });

      if (!res.ok) throw new Error((await res.json()).detail || "Registration failed");
      const data = await res.json();
      setRegResult(data);
      if (!data.already_exists) {
        setRecordSuccess(`Patient registered! Code: ${data.patient_code}`);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!token) return null;

  return (
    <div className="min-h-screen bg-mg-bg text-white font-mono bg-grid pb-20">
      {/* Header */}
      <header className="border-b border-amber-500/30 bg-mg-bg/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-500" />
            <span className="font-bold tracking-widest uppercase text-amber-500">Hospital Mgt Portal</span>
          </div>
          <div className="flex items-center gap-6 text-xs tracking-widest uppercase">
            <span className="text-amber-500/70">Session Active</span>
            <button onClick={handleLogout} className="flex items-center text-red-400 hover:text-red-300 transition-colors">
              <LogOut className="w-4 h-4 mr-2" /> Disconnect
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 mt-12">
        <div className="mb-10">
          <h1 className="text-3xl font-bold mb-2 text-white tracking-widest uppercase flex items-center gap-3">
            <FileText className="w-8 h-8 text-amber-500" /> Facility Operations
          </h1>
          <p className="text-amber-500/70 text-sm tracking-widest uppercase">Manage prior authorizations, financial billing, and medical reports.</p>
        </div>

        {/* Mode Selector */}
        <div className="flex flex-wrap gap-3 mb-8">
          <button onClick={() => { setRecordMode("auth"); setError(null); setRecordSuccess(null); }} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all", recordMode === "auth" ? "bg-amber-500/20 border-amber-500 text-amber-500" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            Prior Authorization
          </button>
          <button onClick={() => { setRecordMode("bill"); setError(null); setRecordSuccess(null); }} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all", recordMode === "bill" ? "bg-emerald-500/20 border-emerald-500 text-emerald-400" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            Submit Patient Bill
          </button>
          <button onClick={() => { setRecordMode("report"); setError(null); setRecordSuccess(null); }} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all", recordMode === "report" ? "bg-mg-glow/20 border-mg-glow text-mg-glow" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            Submit Medical Report
          </button>
          <button onClick={() => { setRecordMode("register" as any); setError(null); setRecordSuccess(null); setRegResult(null); }} className={clsx("px-5 py-3 border text-xs font-bold tracking-widest uppercase transition-all flex items-center gap-2", recordMode === ("register" as any) ? "bg-mg-primary/20 border-mg-primary text-mg-primary" : "border-slate-800 text-slate-500 hover:border-slate-600")}>
            <UserPlus className="w-3.5 h-3.5" /> Register Patient
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Panel */}
          <div className="glass-panel p-8 relative">
            <div className={clsx("absolute top-0 left-0 w-full h-1 opacity-50", recordMode === "auth" ? "bg-gradient-to-r from-amber-500 to-transparent" : recordMode === "bill" ? "bg-gradient-to-r from-emerald-500 to-transparent" : "bg-gradient-to-r from-mg-glow to-transparent")} />
            
            <div className="mb-6">
              <label className="block text-xs text-slate-400 mb-2 uppercase tracking-wider">Patient Identifier</label>
              <input 
                type="text" 
                value={patientCode}
                onChange={(e) => setPatientCode(e.target.value)}
                className="w-full bg-mg-bg/80 border border-slate-800 focus:border-white rounded-none p-3 text-white outline-none text-sm tracking-wider"
              />
            </div>

            {recordMode === "auth" && (
              <>
                <div className="mb-6">
                  <label className="block text-xs text-amber-500/70 mb-2 uppercase tracking-wider">Target Policy Node</label>
                  <select 
                    value={payer} 
                    onChange={(e) => setPayer(e.target.value)}
                    className="w-full bg-mg-bg/80 border border-slate-800 focus:border-amber-500 rounded-none p-3 text-white outline-none text-sm tracking-wider"
                  >
                    <option value="starhealth_spinal_fusion">StarHealth - Lumbar Fusion</option>
                    <option value="apollohealth_knee_replacement">ApolloHealth - Knee Replacement</option>
                    <option value="maxbupa_lumbar_mri">MaxBupa - Lumbar MRI</option>
                  </select>
                </div>
                <div className="mb-8">
                  <label className="block text-xs text-amber-500/70 mb-2 uppercase tracking-wider">Clinical Notes (Raw Text)</label>
                  <textarea 
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full h-48 bg-mg-bg/80 border border-slate-800 focus:border-amber-500 rounded-none p-4 text-white outline-none text-sm resize-none"
                  />
                </div>
                <button 
                  onClick={submitCase}
                  disabled={isProcessing}
                  className="w-full py-4 border border-amber-500 text-amber-500 hover:bg-amber-500/10 transition-all uppercase tracking-widest text-sm font-bold disabled:opacity-50 flex justify-center items-center"
                >
                  {isProcessing ? <><Terminal className="w-4 h-4 mr-2 animate-pulse" /> EXECUTING...</> : "SUBMIT FOR ADJUDICATION"}
                </button>
              </>
            )}

            {recordMode === "bill" && (
              <>
                <div className="mb-6 flex gap-4">
                  <div className="flex-1">
                    <label className="block text-xs text-emerald-400/70 mb-2 uppercase tracking-wider">Bill Amount ($)</label>
                    <input 
                      type="number" 
                      value={billAmount}
                      onChange={(e) => setBillAmount(e.target.value)}
                      className="w-full bg-mg-bg/80 border border-slate-800 focus:border-emerald-500 rounded-none p-3 text-white outline-none text-sm tracking-wider"
                      placeholder="0.00"
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs text-emerald-400/70 mb-2 uppercase tracking-wider">Bill Type</label>
                    <select 
                      value={billType} 
                      onChange={(e) => setBillType(e.target.value)}
                      className="w-full bg-mg-bg/80 border border-slate-800 focus:border-emerald-500 rounded-none p-3 text-white outline-none text-sm tracking-wider"
                    >
                      <option value="inpatient">Inpatient Facility</option>
                      <option value="outpatient">Outpatient Services</option>
                      <option value="pharmacy">Pharmacy</option>
                    </select>
                  </div>
                </div>
                <div className="mb-8">
                  <label className="block text-xs text-emerald-400/70 mb-2 uppercase tracking-wider">Line Item Description</label>
                  <textarea 
                    value={billDesc}
                    onChange={(e) => setBillDesc(e.target.value)}
                    className="w-full h-32 bg-mg-bg/80 border border-slate-800 focus:border-emerald-500 rounded-none p-4 text-white outline-none text-sm resize-none"
                  />
                </div>
                <button 
                  onClick={submitBill}
                  disabled={isProcessing}
                  className="w-full py-4 border border-emerald-500 text-emerald-400 hover:bg-emerald-500/10 transition-all uppercase tracking-widest text-sm font-bold disabled:opacity-50 flex justify-center items-center"
                >
                  {isProcessing ? <><Terminal className="w-4 h-4 mr-2 animate-pulse" /> PROCESSING...</> : "LOG FINANCIAL BILL"}
                </button>
              </>
            )}

            {recordMode === "report" && (
              <>
                <div className="mb-6">
                  <label className="block text-xs text-mg-glow/70 mb-2 uppercase tracking-wider">Report Category</label>
                  <select 
                    value={reportType} 
                    onChange={(e) => setReportType(e.target.value)}
                    className="w-full bg-mg-bg/80 border border-slate-800 focus:border-mg-glow rounded-none p-3 text-white outline-none text-sm tracking-wider"
                  >
                    <option value="discharge">Discharge Summary</option>
                    <option value="lab">Laboratory Results</option>
                    <option value="imaging">Imaging (MRI/CT/X-Ray)</option>
                    <option value="surgical">Surgical Notes</option>
                  </select>
                </div>
                <div className="mb-8">
                  <label className="block text-xs text-mg-glow/70 mb-2 uppercase tracking-wider">Report Contents</label>
                  <textarea 
                    value={reportContent}
                    onChange={(e) => setReportContent(e.target.value)}
                    className="w-full h-48 bg-mg-bg/80 border border-slate-800 focus:border-mg-glow rounded-none p-4 text-white outline-none text-sm resize-none"
                  />
                </div>
                <button 
                  onClick={submitReport}
                  disabled={isProcessing}
                  className="w-full py-4 border border-mg-glow text-mg-glow hover:bg-mg-glow/10 transition-all uppercase tracking-widest text-sm font-bold disabled:opacity-50 flex justify-center items-center"
                >
                  {isProcessing ? <><Terminal className="w-4 h-4 mr-2 animate-pulse" /> PROCESSING...</> : "STORE SECURE REPORT"}
                </button>
              </>
            )}

            {recordMode === ("register" as any) && (
              <>
                <div className="mb-6">
                  <label className="block text-xs text-mg-primary/70 mb-2 uppercase tracking-wider flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5" /> Phone Number
                  </label>
                  <input 
                    type="tel" 
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full bg-mg-bg/80 border border-slate-800 focus:border-mg-primary rounded-none p-3 text-white outline-none text-sm tracking-wider"
                    placeholder="+91 98765 43210"
                  />
                  <p className="text-[10px] text-slate-600 mt-1.5 tracking-wider">One phone = one permanent patient code</p>
                </div>
                <div className="mb-6">
                  <label className="block text-xs text-mg-primary/70 mb-2 uppercase tracking-wider">Patient Full Name</label>
                  <input 
                    type="text" 
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full bg-mg-bg/80 border border-slate-800 focus:border-mg-primary rounded-none p-3 text-white outline-none text-sm tracking-wider"
                    placeholder="Patient full name..."
                  />
                </div>
                <div className="mb-8">
                  <label className="block text-xs text-mg-primary/70 mb-2 uppercase tracking-wider">Password (Optional)</label>
                  <input 
                    type="password" 
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full bg-mg-bg/80 border border-slate-800 focus:border-mg-primary rounded-none p-3 text-white outline-none text-sm tracking-wider"
                    placeholder="Leave blank for auto-generated"
                  />
                </div>
                <button 
                  onClick={registerPatient}
                  disabled={isProcessing || !regPhone || !regName}
                  className="w-full py-4 border border-mg-primary text-mg-primary hover:bg-mg-primary/10 transition-all uppercase tracking-widest text-sm font-bold disabled:opacity-50 flex justify-center items-center"
                >
                  {isProcessing ? <><Terminal className="w-4 h-4 mr-2 animate-pulse" /> PROCESSING...</> : "REGISTER PATIENT"}
                </button>

                {regResult && (
                  <div className={clsx("mt-4 p-4 border text-xs", regResult.already_exists ? "border-amber-500/30 bg-amber-500/5" : "border-emerald-500/30 bg-emerald-500/5")}>
                    <div className="flex items-center mb-2">
                      <CheckCircle2 className={clsx("w-4 h-4 mr-2", regResult.already_exists ? "text-amber-400" : "text-emerald-400")} />
                      <span className={regResult.already_exists ? "text-amber-400" : "text-emerald-400"}>
                        {regResult.already_exists ? "Patient Already Registered" : "New Patient Registered"}
                      </span>
                    </div>
                    <div className="space-y-1 text-slate-400 tracking-wider">
                      <p>Name: <span className="text-white">{regResult.full_name}</span></p>
                      <p>Phone: <span className="text-white">{regResult.phone_number}</span></p>
                      <p>Patient Code: <span className="text-mg-primary font-bold text-base">{regResult.patient_code}</span></p>
                    </div>
                    <p className="mt-2 text-[10px] text-slate-600 tracking-wider">This code is the patient&apos;s permanent identity across all portals.</p>
                  </div>
                )}
              </>
            )}

            {error && <div className="mt-4 text-xs text-red-500 border border-red-500/50 p-3 uppercase bg-red-500/10">ERR: {error}</div>}
            {recordSuccess && recordMode !== ("register" as any) && <div className="mt-4 text-xs text-emerald-400 border border-emerald-500/50 p-3 uppercase bg-emerald-500/10 flex items-center"><CheckCircle2 className="w-4 h-4 mr-2"/> {recordSuccess}</div>}
          </div>

          {/* Output Panel */}
          <div className="glass-panel p-8 relative flex flex-col">
             <div className="absolute top-0 right-0 w-1 h-full bg-gradient-to-b from-amber-500 to-transparent opacity-50" />
             <h3 className="text-xl text-amber-500 mb-6 flex items-center border-b border-amber-500/30 pb-4 uppercase tracking-widest">
              [SYSTEM_RESPONSE]
            </h3>

            {recordMode === ("register" as any) && (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-600">
                <UserPlus className="w-16 h-16 mb-4 opacity-50" />
                <p className="text-sm tracking-widest uppercase text-center max-w-xs">Register patients by phone number. One phone = one permanent code.</p>
              </div>
            )}

            {recordMode === "auth" && !result && !isProcessing && (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-600">
                <ShieldCheck className="w-16 h-16 mb-4 opacity-50" />
                <p className="text-sm tracking-widest uppercase">Awaiting Submission</p>
              </div>
            )}

            {recordMode !== "auth" && (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-600">
                <Database className="w-16 h-16 mb-4 opacity-50" />
                <p className="text-sm tracking-widest uppercase text-center max-w-xs">Data synced to secure distributed ledger.</p>
              </div>
            )}

            {recordMode === "auth" && isProcessing && (
              <div className="flex-1 flex flex-col items-center justify-center text-amber-500">
                <Terminal className="w-12 h-12 mb-4 animate-pulse" />
                <p className="text-sm tracking-widest uppercase animate-pulse">Running Neuro-Symbolic Pipeline...</p>
              </div>
            )}

            {recordMode === "auth" && result && !isProcessing && (
              <div className="space-y-6">
                <div className="p-4 border border-slate-800 bg-black/40">
                  <div className="flex justify-between text-xs text-slate-500 mb-2 uppercase tracking-widest">
                    <span>Final Determination</span>
                    <span>ID: {result.submission_id}</span>
                  </div>
                  <div className={clsx(
                    "text-3xl font-bold tracking-widest uppercase",
                    result.status === "SUBMISSION_READY" ? "text-emerald-400" :
                    result.status === "NEEDS_MORE_EVIDENCE" ? "text-amber-400" : "text-red-500"
                  )}>
                    [{result.status}]
                  </div>
                </div>

                <div className="p-4 border border-mg-glow/30 bg-mg-glow/5">
                  <h4 className="text-xs text-mg-glow uppercase tracking-widest mb-3 flex items-center"><BrainCircuit className="w-4 h-4 mr-2"/> Extracted Entities</h4>
                  <pre className="text-[10px] text-mg-glow/80 overflow-x-auto">
                    {JSON.stringify(result.extracted_data, null, 2)}
                  </pre>
                </div>

                <div className="p-4 border border-amber-500/30 bg-amber-500/5">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="text-xs text-amber-500 uppercase tracking-widest flex items-center"><Database className="w-4 h-4 mr-2"/> Rule Evaluation</h4>
                    <span className="text-xs font-bold text-white">{result.evaluation.readiness_score.toFixed(1)} / {result.evaluation.maximum_possible_score.toFixed(1)}</span>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    {Object.entries(result.evaluation.rule_results).map(([rule, res]: any) => (
                      <div key={rule} className="flex items-center justify-between text-[10px] border-b border-slate-800 pb-2">
                        <span className="text-slate-400 uppercase">{rule.replace(/_/g, " ")}</span>
                        {res.passed ? <span className="text-emerald-400">PASS</span> : <span className="text-red-400">FAIL</span>}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
