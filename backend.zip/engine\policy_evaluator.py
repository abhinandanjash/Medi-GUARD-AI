"""
policy_evaluator.py — The Symbolic Layer of the Medi-Guard AI Neuro-Symbolic Engine.

Responsibilities:
  - Load JSON insurance policy files from the policies/ directory
  - Evaluate structured extracted data (from LLMExtractor) against policy rules
  - Produce a deterministic, auditable decision with step-by-step rule trace
  - Zero LLM involvement — pure Python logic only

This module is the "guardrail" that prevents hallucinations. It can only
produce decisions that the JSON policy files explicitly define.

Decisions:
  - SUBMISSION_READY:     All rules pass — claim is ready to submit.
  - NEEDS_MORE_EVIDENCE:  One or more evidence rules failed — doctor needs to provide more docs.
  - REJECTED:             A hard-stop rule failed — claim is ineligible under this policy.
"""

import os
import json
import logging
from typing import Optional

logger = logging.getLogger("medi_guard.evaluator")

POLICIES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "policies")


class PolicyEvaluator:
    """
    Symbolic Layer: Deterministic rule engine that evaluates extracted clinical
    data against structured insurance policy rules.

    Usage:
        evaluator = PolicyEvaluator()
        result = evaluator.evaluate(payer_id="starhealth_spinal_fusion", extracted_data={...})
    """

    def __init__(self):
        self._policy_cache: dict = {}
        logger.info("[SYMBOLIC] PolicyEvaluator initialized.")

    def list_payers(self) -> list[dict]:
        """Return a list of all available payer policies (id + name + procedure)."""
        payers = []
        for filename in os.listdir(POLICIES_DIR):
            if filename.endswith(".json"):
                payer_id = filename.replace(".json", "")
                try:
                    policy = self._load_policy(payer_id)
                    payers.append({
                        "payer_id": policy["payer_id"],
                        "payer_name": policy["payer_name"],
                        "procedure_name": policy["procedure_name"],
                        "description": policy.get("description", ""),
                    })
                except Exception as e:
                    logger.warning(f"[SYMBOLIC] Could not load policy {filename}: {e}")
        return payers

    def evaluate(self, payer_id: str, extracted_data: dict) -> dict:
        """
        Evaluate extracted clinical data against a specific payer's policy.

        Args:
            payer_id: The policy identifier (e.g. "starhealth_spinal_fusion")
            extracted_data: The structured dict returned by LLMExtractor.extract()

        Returns:
            {
                "payer_id": str,
                "payer_name": str,
                "procedure_name": str,
                "decision": "SUBMISSION_READY" | "NEEDS_MORE_EVIDENCE" | "REJECTED",
                "score": int (0-100),
                "audit_trail": [ { rule_id, name, status, message, field, actual_value, threshold } ]
            }
        """
        logger.info(f"[SYMBOLIC] Evaluating policy: {payer_id}")
        policy = self._load_policy(payer_id)
        rules = policy["rules"]

        audit_trail = []
        rules_passed = 0
        has_rejection = False
        has_evidence_gap = False

        for rule in rules:
            rule_result = self._evaluate_rule(rule, extracted_data)
            audit_trail.append(rule_result)

            if rule_result["status"] == "PASS":
                rules_passed += 1
                logger.info(f"[SYMBOLIC] Rule {rule['rule_id']} [{rule['name']}]: PASS ✓")
            else:
                on_fail = rule.get("on_fail", "NEEDS_MORE_EVIDENCE")
                if on_fail == "REJECTED":
                    has_rejection = True
                    logger.warning(f"[SYMBOLIC] Rule {rule['rule_id']} [{rule['name']}]: FAIL → REJECTED ✗")
                else:
                    has_evidence_gap = True
                    logger.info(f"[SYMBOLIC] Rule {rule['rule_id']} [{rule['name']}]: FAIL → NEEDS_MORE_EVIDENCE !")

        # Determine final decision (precedence: REJECTED > NEEDS_MORE_EVIDENCE > SUBMISSION_READY)
        if has_rejection:
            decision = "REJECTED"
        elif has_evidence_gap:
            decision = "NEEDS_MORE_EVIDENCE"
        else:
            decision = "SUBMISSION_READY"

        score = round((rules_passed / len(rules)) * 100) if rules else 0

        result = {
            "payer_id": policy["payer_id"],
            "payer_name": policy["payer_name"],
            "procedure_name": policy["procedure_name"],
            "decision": decision,
            "score": score,
            "rules_passed": rules_passed,
            "rules_total": len(rules),
            "audit_trail": audit_trail,
        }

        logger.info(
            f"[SYMBOLIC] ─── FINAL DECISION: {decision} "
            f"(Score: {score}/100, {rules_passed}/{len(rules)} rules passed) ───"
        )
        return result

    # ─── Private Methods ────────────────────────────────────────────────────────

    def _load_policy(self, payer_id: str) -> dict:
        """Load and cache a policy JSON by payer_id."""
        if payer_id in self._policy_cache:
            return self._policy_cache[payer_id]

        policy_path = os.path.join(POLICIES_DIR, f"{payer_id}.json")
        if not os.path.exists(policy_path):
            raise FileNotFoundError(f"No policy file found for payer_id: {payer_id!r}")

        with open(policy_path, "r", encoding="utf-8") as f:
            policy = json.load(f)

        self._policy_cache[payer_id] = policy
        logger.info(f"[SYMBOLIC] Policy loaded: {policy['payer_name']} — {policy['procedure_name']}")
        return policy

    def _evaluate_rule(self, rule: dict, data: dict) -> dict:
        """
        Evaluate a single rule against the extracted data.

        Returns a rule result dict:
        {
            rule_id, name, description, status (PASS|FAIL),
            operator, field, actual_value, threshold_or_list, message
        }
        """
        rule_id = rule["rule_id"]
        name = rule["name"]
        description = rule.get("description", "")
        operator = rule["operator"]
        field = rule.get("field")
        on_fail = rule.get("on_fail", "NEEDS_MORE_EVIDENCE")

        actual_value = data.get(field) if field else None

        base_result = {
            "rule_id": rule_id,
            "name": name,
            "description": description,
            "operator": operator,
            "field": field,
            "actual_value": actual_value,
            "on_fail": on_fail,
        }

        try:
            if operator == "gte":
                # Numeric: actual >= threshold
                threshold = rule["threshold"]
                if actual_value is None:
                    return {**base_result, "status": "FAIL",
                            "threshold": threshold,
                            "message": f"Field '{field}' is missing from clinical notes. Required: ≥ {threshold}."}
                passed = float(actual_value) >= float(threshold)
                msg = (
                    f"'{field}' = {actual_value} — meets minimum of {threshold}."
                    if passed else
                    f"'{field}' = {actual_value} — does NOT meet minimum of {threshold}. Need at least {threshold}."
                )
                return {**base_result, "status": "PASS" if passed else "FAIL",
                        "threshold": threshold, "message": msg}

            elif operator == "lte":
                # Numeric: actual <= threshold
                threshold = rule["threshold"]
                if actual_value is None:
                    return {**base_result, "status": "FAIL",
                            "threshold": threshold,
                            "message": f"Field '{field}' is missing. Required: ≤ {threshold}."}
                passed = float(actual_value) <= float(threshold)
                msg = (
                    f"'{field}' = {actual_value} — within acceptable limit of {threshold}."
                    if passed else
                    f"'{field}' = {actual_value} — EXCEEDS maximum of {threshold}. Claim ineligible."
                )
                return {**base_result, "status": "PASS" if passed else "FAIL",
                        "threshold": threshold, "message": msg}

            elif operator == "contains_any":
                # List field: at least one item must match a keyword
                allowed_terms = rule.get("contains_any", [])
                allowed_lower = [t.lower() for t in allowed_terms]
                if not actual_value:
                    return {**base_result, "status": "FAIL",
                            "allowed_values": allowed_terms,
                            "message": (
                                f"No conservative treatments recorded. "
                                f"Policy requires at least one of: {', '.join(allowed_terms[:5])}..."
                            )}
                # Check if any item in the actual list contains any keyword
                found_matches = []
                if isinstance(actual_value, list):
                    for item in actual_value:
                        item_lower = item.lower()
                        for term in allowed_lower:
                            if term in item_lower:
                                found_matches.append(item)
                                break
                elif isinstance(actual_value, str):
                    actual_lower = actual_value.lower()
                    found_matches = [t for t in allowed_terms if t.lower() in actual_lower]

                passed = len(found_matches) > 0
                msg = (
                    f"Conservative treatment verified: {', '.join(found_matches)}."
                    if passed else
                    f"No matching conservative treatment found in: {actual_value}. "
                    f"Required one of: {', '.join(allowed_terms[:5])}."
                )
                return {**base_result, "status": "PASS" if passed else "FAIL",
                        "allowed_values": allowed_terms,
                        "matched_values": found_matches,
                        "message": msg}

            elif operator == "in_list":
                # Exact match: actual must be in allowed_values list
                allowed_values = rule.get("allowed_values", [])
                if not actual_value:
                    return {**base_result, "status": "FAIL",
                            "allowed_values": allowed_values,
                            "message": f"Field '{field}' is missing. Must be one of: {allowed_values}."}
                passed = str(actual_value) in [str(v) for v in allowed_values]
                msg = (
                    f"CPT/code '{actual_value}' is in the approved list."
                    if passed else
                    f"CPT/code '{actual_value}' is NOT in the approved list: {allowed_values}."
                )
                return {**base_result, "status": "PASS" if passed else "FAIL",
                        "allowed_values": allowed_values, "message": msg}

            elif operator == "starts_with_any":
                # ICD-10 prefix check
                allowed_prefixes = rule.get("allowed_prefixes", [])
                if not actual_value:
                    return {**base_result, "status": "FAIL",
                            "allowed_prefixes": allowed_prefixes,
                            "message": f"Field '{field}' is missing. Must start with one of: {allowed_prefixes}."}
                code_str = str(actual_value).upper().strip()
                passed = any(code_str.startswith(p.upper()) for p in allowed_prefixes)
                msg = (
                    f"ICD-10 code '{actual_value}' matches approved prefix group {allowed_prefixes}."
                    if passed else
                    f"ICD-10 code '{actual_value}' does NOT match any approved prefix: {allowed_prefixes}."
                )
                return {**base_result, "status": "PASS" if passed else "FAIL",
                        "allowed_prefixes": allowed_prefixes, "message": msg}

            else:
                logger.error(f"[SYMBOLIC] Unknown operator: {operator!r} in rule {rule_id}")
                return {**base_result, "status": "FAIL",
                        "message": f"Unknown rule operator: {operator!r}. Contact system administrator."}

        except Exception as e:
            logger.error(f"[SYMBOLIC] Exception evaluating rule {rule_id}: {e}")
            return {**base_result, "status": "FAIL",
                    "message": f"Rule evaluation error: {e}"}
