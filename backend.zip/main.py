"""
main.py — Medi-Guard AI FastAPI Application

Endpoints:
  POST /api/auth/register        — Register a new user (any role)
  POST /api/auth/login           — Login, get JWT token
  GET  /api/payers               — List available insurance policies
  GET  /api/patients/search      — Doctor searches for a patient by patient_code
  POST /api/submissions/evaluate — Run Neuro-Symbolic engine and save submission
  GET  /api/dashboard            — Role-scoped submission dashboard
  POST /api/submissions/{id}/override — Insurer manual override

Architecture:
  Request → JWT Auth → API Handler → [LLMExtractor → PolicyEvaluator] → DB → Response
  The Neuro-Symbolic pipeline is ONLY invoked at /evaluate. All other routes are pure CRUD.
"""

import os
import json
import logging
import uuid
import base64
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from typing import Optional
from google import genai
from google.genai import types

# Load .env file if present (development)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv not installed — rely on system environment variables

from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session
import bcrypt as _bcrypt
from jose import JWTError, jwt

from database import (
    User, MedicalHistory, Submission, Bill, Report,
    get_db, init_db, generate_patient_code
)
from engine.llm_extractor import LLMExtractor
from engine.policy_evaluator import PolicyEvaluator

# ─── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("medi_guard.main")

# ─── Engine Singletons (declared early — referenced in lifespan) ───────────────────────
_extractor = None
_evaluator: PolicyEvaluator = PolicyEvaluator()


def get_extractor() -> LLMExtractor:
    global _extractor
    if _extractor is None:
        _extractor = LLMExtractor()
    return _extractor


# ─── Startup Lifespan ───────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app_: FastAPI):
    logger.info("=" * 60)
    logger.info("  Medi-Guard AI — Starting Up")
    logger.info("=" * 60)
    init_db()
    logger.info("[DB] Database initialized (medi_guard.db)")
    payers = _evaluator.list_payers()
    logger.info(f"[ENGINE] Loaded {len(payers)} payer policies: {[p['payer_id'] for p in payers]}")
    if not os.environ.get("GOOGLE_API_KEY"):
        logger.warning("[ENGINE] ⚠️  GOOGLE_API_KEY not set — LLM extraction will fail at runtime!")
    else:
        logger.info("[ENGINE] GOOGLE_API_KEY detected — LLM extraction ready.")
    logger.info("=" * 60)
    yield


# ─── App Setup ──────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Medi-Guard AI",
    description="Neuro-Symbolic Medical Prior Authorization System",
    version="2.0.0",
    lifespan=lifespan,
)

# ─── CORS — Read allowed origins from environment ───────────────────────────────
_raw_origins = os.environ.get("ALLOWED_ORIGINS", "http://localhost:3000")
ALLOWED_ORIGINS = [o.strip() for o in _raw_origins.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
)

logger.info(f"[CORS] Allowed origins: {ALLOWED_ORIGINS}")

# ─── Security ───────────────────────────────────────────────────────────────────
_jwt_secret = os.environ.get("JWT_SECRET")
if not _jwt_secret:
    raise RuntimeError(
        "FATAL: JWT_SECRET environment variable is not set. "
        "Set it in your .env file or system environment before starting the server."
    )
JWT_SECRET = _jwt_secret
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_HOURS = 24


def hash_password(plain: str) -> str:
    return _bcrypt.hashpw(plain[:72].encode(), _bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    return _bcrypt.checkpw(plain[:72].encode(), hashed.encode())



# ─── JWT Helpers ────────────────────────────────────────────────────────────────
def create_token(username: str, role: str, patient_code: Optional[str] = None) -> str:
    expire = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRE_HOURS)
    payload = {
        "sub": username,
        "role": role,
        "patient_code": patient_code,
        "exp": expire,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid or expired token: {e}",
        )


def get_current_user(request: Request) -> dict:
    """FastAPI dependency: extract and validate JWT from Authorization header."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or malformed Authorization header. Use: Bearer <token>",
        )
    token = auth_header.split(" ", 1)[1]
    return decode_token(token)


def require_role(*allowed_roles: str):
    """FastAPI dependency factory: enforce role-based access control."""
    def _check(current_user: dict = Depends(get_current_user)):
        if current_user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required role(s): {allowed_roles}. Your role: {current_user['role']}",
            )
        return current_user
    return _check


# ─── Pydantic Schemas ───────────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    username: str
    password: str
    full_name: str
    role: str                              # doctor | insurer | patient | hospital | pharma
    organization_name: Optional[str] = None  # For insurer, hospital, pharma
    phone_number: Optional[str] = None       # Required for patient role


class RegisterPatientRequest(BaseModel):
    """Used by doctor/hospital/pharma portals to register a new patient."""
    phone_number: str
    full_name: str
    password: Optional[str] = None           # If not given, auto-generate a simple one


class LoginRequest(BaseModel):
    username: str
    password: str
    webcam_image_base64: Optional[str] = None


class EvaluateRequest(BaseModel):
    patient_code: str
    clinical_notes: str
    payer_id: str


class OverrideRequest(BaseModel):
    override_decision: str                 # APPROVED_OVERRIDE | DENIED_OVERRIDE
    override_reason: Optional[str] = None


class BillRequest(BaseModel):
    amount: float
    bill_type: str                         # inpatient | outpatient | pharmacy
    description: str


class ReportRequest(BaseModel):
    report_type: str                       # lab | imaging | discharge | prescription | etc.
    content: str
    medication_name: Optional[str] = None  # For prescriptions


class AdjudicateRequest(BaseModel):
    report_id: str                         # Report ID containing the prescription
    payer_id: str                          # Target insurance policy


# ─── Auth Endpoints ─────────────────────────────────────────────────────────────
@app.post("/api/auth/register")
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    """Register a new user. Auto-generates a patient_code for patient role."""
    allowed_roles = {"doctor", "insurer", "patient", "hospital", "pharma"}
    if req.role not in allowed_roles:
        raise HTTPException(400, f"Invalid role. Must be one of: {allowed_roles}")

    if db.query(User).filter(User.username == req.username).first():
        raise HTTPException(409, f"Username '{req.username}' is already taken.")

    patient_code = None
    phone = None
    if req.role == "patient":
        if not req.phone_number:
            raise HTTPException(400, "Phone number is required for patient registration.")

        phone = req.phone_number.strip()
        # Check if this phone already exists — return existing patient code
        existing = db.query(User).filter(User.phone_number == phone).first()
        if existing:
            raise HTTPException(
                409,
                f"Phone number already registered. Your Patient Code is: {existing.patient_code}. Please login instead."
            )

        # Generate unique patient code
        for _ in range(10):
            code = generate_patient_code()
            if not db.query(User).filter(User.patient_code == code).first():
                patient_code = code
                break
        if not patient_code:
            raise HTTPException(500, "Could not generate unique patient code.")

    new_user = User(
        username=req.username,
        role=req.role,
        password_hash=hash_password(req.password),
        full_name=req.full_name,
        patient_code=patient_code,
        phone_number=phone,
        organization_name=req.organization_name,
    )
    db.add(new_user)
    db.commit()

    logger.info(f"[AUTH] Registered user: {req.username} | Role: {req.role} | Patient Code: {patient_code} | Phone: {phone}")

    token = create_token(req.username, req.role, patient_code)
    return {
        "token": token,
        "username": req.username,
        "full_name": req.full_name,
        "role": req.role,
        "patient_code": patient_code,
        "phone_number": phone,
        "organization_name": req.organization_name,
        "message": f"Registration successful. Welcome, {req.full_name}!",
    }


@app.post("/api/patients/register")
def register_patient_from_portal(
    req: RegisterPatientRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("doctor", "hospital", "pharma", "patient")),
):
    """
    Register a new patient by phone number from any portal.
    If the phone is already registered, returns the existing patient code.
    One phone = one permanent patient code.
    """
    phone = req.phone_number.strip()
    if not phone:
        raise HTTPException(400, "Phone number is required.")

    # Check if phone already exists
    existing = db.query(User).filter(User.phone_number == phone).first()
    if existing:
        return {
            "already_exists": True,
            "patient_code": existing.patient_code,
            "full_name": existing.full_name,
            "phone_number": phone,
            "message": f"Patient already registered. Code: {existing.patient_code}",
        }

    # Generate unique patient code
    patient_code = None
    for _ in range(10):
        code = generate_patient_code()
        if not db.query(User).filter(User.patient_code == code).first():
            patient_code = code
            break
    if not patient_code:
        raise HTTPException(500, "Could not generate unique patient code.")

    # Auto-generate username from phone
    username = f"patient_{phone}"
    if db.query(User).filter(User.username == username).first():
        username = f"patient_{phone}_{patient_code}"

    pwd = req.password or phone[-4:] + "Mg!"  # Simple default if no password given

    new_patient = User(
        username=username,
        role="patient",
        password_hash=hash_password(pwd),
        full_name=req.full_name,
        patient_code=patient_code,
        phone_number=phone,
    )
    db.add(new_patient)
    db.commit()

    logger.info(f"[AUTH] Patient registered via {current_user['role']} portal | Phone: {phone} | Code: {patient_code}")

    return {
        "already_exists": False,
        "patient_code": patient_code,
        "full_name": req.full_name,
        "phone_number": phone,
        "username": username,
        "message": f"Patient registered successfully! Code: {patient_code}",
    }


@app.post("/api/auth/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    """Authenticate a user and return a JWT token."""
    user = db.query(User).filter(User.username == req.username).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(401, "Invalid username or password.")

    # Biometric VLM Check
    if req.webcam_image_base64:
        try:
            logger.info(f"[AUTH] Performing biometric VLM check for {req.username}")
            # Strip data URI prefix if present
            b64_str = req.webcam_image_base64
            if "," in b64_str:
                b64_str = b64_str.split(",", 1)[1]
            
            image_bytes = base64.b64decode(b64_str)
            
            client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY"))
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=[
                    types.Part.from_bytes(data=image_bytes, mime_type='image/jpeg'),
                    "Analyze this image for biometric authentication. Does this image contain a real human face looking clearly at the camera? Reply with ONLY 'YES' or 'NO'."
                ]
            )
            
            vlm_result = response.text.strip().upper()
            logger.info(f"[AUTH] VLM Result for {req.username}: {vlm_result}")
            
            if "YES" not in vlm_result:
                raise HTTPException(401, "Biometric Verification Failed: Liveliness check rejected. Please ensure your face is clearly visible.")
                
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"[AUTH] VLM check failed with exception: {e}")
            raise HTTPException(500, "Biometric verification system is currently unavailable.")

    token = create_token(user.username, user.role, user.patient_code)
    logger.info(f"[AUTH] Login successful: {user.username} | Role: {user.role}")

    return {
        "token": token,
        "username": user.username,
        "full_name": user.full_name,
        "role": user.role,
        "patient_code": user.patient_code,
        "organization_name": user.organization_name,
        "message": f"Welcome back, {user.full_name}!",
    }


# ─── Payer Endpoints ────────────────────────────────────────────────────────────
@app.get("/api/payers")
def list_payers(current_user: dict = Depends(get_current_user)):
    """Return all available insurance payer policies."""
    return {"payers": _evaluator.list_payers()}


# ─── Patient Search ─────────────────────────────────────────────────────────────
@app.get("/api/patients/search")
def search_patient(
    code: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("doctor", "hospital", "pharma")),
):
    """
    Doctor/hospital/pharma searches for a patient by their unique patient_code.
    Returns patient's name, medical history, and any submitted reports.
    """
    patient = db.query(User).filter(
        User.patient_code == code.upper().strip(),
        User.role == "patient"
    ).first()

    if not patient:
        raise HTTPException(404, f"No patient found with code: {code}")

    # Fetch medical history
    history = db.query(MedicalHistory).filter(
        MedicalHistory.patient_code == patient.patient_code
    ).first()

    # Fetch medical reports
    reports = db.query(Report).filter(
        Report.patient_code == patient.patient_code
    ).order_by(Report.timestamp.desc()).all()

    return {
        "found": True,
        "patient_code": patient.patient_code,
        "full_name": patient.full_name,
        "medical_history": history.history_text if history else None,
        "reports": [
            {
                "id": r.id,
                "type": r.report_type,
                "content": r.content,
                "submitted_by": r.submitted_by,
                "timestamp": r.timestamp.isoformat()
            } for r in reports
        ]
    }


# ─── Neuro-Symbolic Evaluation Endpoint ─────────────────────────────────────────
@app.post("/api/submissions/evaluate")
def evaluate_submission(
    req: EvaluateRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("doctor", "hospital", "pharma")),
):
    """
    Core Neuro-Symbolic Pipeline:
    1. [NEURAL] LLMExtractor extracts structured entities from clinical_notes
    2. [SYMBOLIC] PolicyEvaluator deterministically evaluates entities against payer rules
    3. Save submission to database
    4. Return full extraction, evaluation, and audit trail

    This endpoint is the heart of Medi-Guard AI.
    """
    logger.info(f"[PIPELINE] ══════ Starting evaluation for patient {req.patient_code} ══════")
    logger.info(f"[PIPELINE] Submitted by: {current_user['sub']} | Payer: {req.payer_id}")

    # Validate patient exists
    patient = db.query(User).filter(
        User.patient_code == req.patient_code.upper().strip(),
        User.role == "patient"
    ).first()
    if not patient:
        raise HTTPException(404, f"Patient not found: {req.patient_code}")

    # Validate payer exists
    available_payers = {p["payer_id"] for p in _evaluator.list_payers()}
    if req.payer_id not in available_payers:
        raise HTTPException(400, f"Unknown payer_id: {req.payer_id}. Available: {available_payers}")

    # Fetch policy context for the LLM prompt
    payer_info = next(p for p in _evaluator.list_payers() if p["payer_id"] == req.payer_id)
    policy_context = (
        f"Payer: {payer_info['payer_name']}\n"
        f"Procedure: {payer_info['procedure_name']}\n"
        f"This authorization is for: {payer_info['description']}"
    )

    # Fetch patient medical history
    history = db.query(MedicalHistory).filter(
        MedicalHistory.patient_code == req.patient_code.upper()
    ).first()
    medical_history_text = history.history_text if history else None

    # ── STEP 1: NEURAL LAYER ────────────────────────────────────────────────────
    logger.info("[PIPELINE] ── Step 1: Running Neural Extraction Layer ──")
    try:
        extractor = get_extractor()
        extracted_data = extractor.extract(
            clinical_notes=req.clinical_notes,
            medical_history=medical_history_text,
            policy_context=policy_context,
        )
    except Exception as e:
        logger.error(f"[PIPELINE] Neural extraction failed: {e}")
        raise HTTPException(502, f"LLM extraction failed: {str(e)}")

    # ── STEP 2: SYMBOLIC LAYER ──────────────────────────────────────────────────
    logger.info("[PIPELINE] ── Step 2: Running Symbolic Evaluation Layer ──")
    try:
        evaluation_result = _evaluator.evaluate(req.payer_id, extracted_data)
    except FileNotFoundError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        logger.error(f"[PIPELINE] Symbolic evaluation failed: {e}")
        raise HTTPException(500, f"Policy evaluation failed: {str(e)}")

    decision = evaluation_result["decision"]
    logger.info(f"[PIPELINE] ── Final Decision: {decision} ──")

    # ── STEP 3: SAVE TO DATABASE ────────────────────────────────────────────────
    submission = Submission(
        id=str(uuid.uuid4()),
        patient_code=req.patient_code.upper(),
        doctor_id=current_user["sub"],
        insurer_id=req.payer_id,
        clinical_notes=req.clinical_notes,
        extracted_data=json.dumps(extracted_data),
        audit_trail=json.dumps(evaluation_result),
        status=decision,
        timestamp=datetime.utcnow(),
    )
    db.add(submission)
    db.commit()
    logger.info(f"[DB] Submission saved: {submission.id}")

    return {
        "submission_id": submission.id,
        "patient_code": req.patient_code,
        "patient_name": patient.full_name,
        "payer": {
            "payer_id": req.payer_id,
            "payer_name": payer_info["payer_name"],
            "procedure_name": payer_info["procedure_name"],
        },
        "extracted_data": extracted_data,
        "evaluation": evaluation_result,
        "status": decision,
        "timestamp": submission.timestamp.isoformat(),
    }


# ─── Dashboard Endpoint ─────────────────────────────────────────────────────────
@app.get("/api/dashboard")
def get_dashboard(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    """
    Role-scoped dashboard:
    - doctor/hospital/pharma: submissions they created
    - insurer: all submissions directed to their organization's payer_id(s)
    - patient: their own submissions
    """
    role = current_user["role"]
    username = current_user["sub"]

    if role == "patient":
        patient_code = current_user.get("patient_code")
        if not patient_code:
            return {"submissions": [], "message": "No patient code associated with this account."}
        submissions = db.query(Submission).filter(
            Submission.patient_code == patient_code
        ).order_by(Submission.timestamp.desc()).all()

    elif role in ("doctor", "hospital", "pharma"):
        submissions = db.query(Submission).filter(
            Submission.doctor_id == username
        ).order_by(Submission.timestamp.desc()).all()

    elif role == "insurer":
        # Get the insurer's organization name to match payer_ids
        user_obj = db.query(User).filter(User.username == username).first()
        org = user_obj.organization_name.lower().replace(" ", "") if user_obj and user_obj.organization_name else ""
        # Match submissions where payer_id starts with the org prefix
        all_subs = db.query(Submission).order_by(Submission.timestamp.desc()).all()
        submissions = [s for s in all_subs if org and s.insurer_id.lower().startswith(org[:4])]
        if not submissions:
            # Fallback: return all submissions if no org match
            submissions = all_subs

    else:
        raise HTTPException(403, f"Unsupported role: {role}")

    return {
        "role": role,
        "username": username,
        "submissions": [_format_submission(s) for s in submissions],
    }


@app.get("/api/submissions/{submission_id}")
def get_submission(
    submission_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    """Get full detail for a single submission."""
    sub = db.query(Submission).filter(Submission.id == submission_id).first()
    if not sub:
        raise HTTPException(404, f"Submission {submission_id} not found.")

    role = current_user["role"]
    username = current_user["sub"]

    # Access control
    if role == "patient" and sub.patient_code != current_user.get("patient_code"):
        raise HTTPException(403, "Access denied.")
    if role in ("doctor", "hospital", "pharma") and sub.doctor_id != username:
        raise HTTPException(403, "Access denied.")

    return _format_submission(sub, full=True)


@app.post("/api/submissions/{submission_id}/override")
def override_submission(
    submission_id: str,
    req: OverrideRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("insurer")),
):
    """Insurer manual override: approve or deny a claim."""
    allowed = {"APPROVED_OVERRIDE", "DENIED_OVERRIDE"}
    if req.override_decision not in allowed:
        raise HTTPException(400, f"override_decision must be one of: {allowed}")

    sub = db.query(Submission).filter(Submission.id == submission_id).first()
    if not sub:
        raise HTTPException(404, f"Submission {submission_id} not found.")

    old_status = sub.status
    sub.status = req.override_decision

    # Append override note to audit trail
    try:
        trail = json.loads(sub.audit_trail) if sub.audit_trail else {}
    except Exception:
        trail = {}

    trail["insurer_override"] = {
        "override_by": current_user["sub"],
        "override_decision": req.override_decision,
        "override_reason": req.override_reason or "No reason provided.",
        "override_timestamp": datetime.utcnow().isoformat(),
        "previous_status": old_status,
    }
    sub.audit_trail = json.dumps(trail)
    db.commit()

    logger.info(
        f"[OVERRIDE] Submission {submission_id} overridden by {current_user['sub']}: "
        f"{old_status} → {req.override_decision}"
    )

    return {
        "submission_id": submission_id,
        "previous_status": old_status,
        "new_status": req.override_decision,
        "override_by": current_user["sub"],
        "message": f"Submission successfully overridden to {req.override_decision}.",
    }


# ─── Medical History & Records ───────────────────────────────────────────
@app.post("/api/patients/{patient_code}/history")
def add_medical_history(
    patient_code: str,
    request: dict,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("doctor", "hospital")),
):
    """Add or update medical history for a patient."""
    history_text = request.get("history_text", "").strip()
    if not history_text:
        raise HTTPException(400, "history_text cannot be empty.")

    patient = db.query(User).filter(User.patient_code == patient_code.upper()).first()
    if not patient:
        raise HTTPException(404, f"Patient {patient_code} not found.")

    existing = db.query(MedicalHistory).filter(
        MedicalHistory.patient_code == patient_code.upper()
    ).first()

    if existing:
        existing.history_text = history_text
    else:
        db.add(MedicalHistory(patient_code=patient_code.upper(), history_text=history_text))

    db.commit()
    return {"message": f"Medical history updated for patient {patient_code}."}


@app.post("/api/patients/{patient_code}/bills")
def submit_bill(
    patient_code: str,
    req: BillRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("hospital", "pharma")),
):
    """Submit a financial bill for a patient."""
    patient = db.query(User).filter(User.patient_code == patient_code.upper()).first()
    if not patient:
        raise HTTPException(404, f"Patient {patient_code} not found.")

    new_bill = Bill(
        patient_code=patient_code.upper(),
        submitted_by=current_user["sub"],
        amount=req.amount,
        bill_type=req.bill_type,
        description=req.description
    )
    db.add(new_bill)
    db.commit()
    return {"message": "Bill submitted successfully", "bill_id": new_bill.id}


@app.post("/api/patients/{patient_code}/reports")
def submit_report(
    patient_code: str,
    req: ReportRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("hospital", "doctor")),
):
    """Submit a medical report or prescription for a patient. Doctors and hospitals can submit."""
    patient = db.query(User).filter(User.patient_code == patient_code.upper()).first()
    if not patient:
        raise HTTPException(404, f"Patient {patient_code} not found.")

    content = req.content
    if req.medication_name and req.report_type == "prescription":
        content = f"[MEDICATION: {req.medication_name}]\n\n{req.content}"

    new_report = Report(
        patient_code=patient_code.upper(),
        submitted_by=current_user["sub"],
        report_type=req.report_type,
        content=content
    )
    db.add(new_report)
    db.commit()
    logger.info(f"[REPORT] {req.report_type} submitted for {patient_code} by {current_user['sub']}")
    return {"message": "Report submitted successfully", "report_id": new_report.id}


@app.get("/api/patients/{patient_code}/records")
def get_patient_records(
    patient_code: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    """Get all bills, reports, and adjudication results for a patient."""
    patient = db.query(User).filter(User.patient_code == patient_code.upper()).first()
    if not patient:
        raise HTTPException(404, f"Patient {patient_code} not found.")

    # Access control: patient can only see their own, others can see if they have access
    if current_user["role"] == "patient" and current_user.get("patient_code") != patient_code.upper():
        raise HTTPException(403, "Access denied.")

    bills = db.query(Bill).filter(Bill.patient_code == patient_code.upper()).order_by(Bill.timestamp.desc()).all()
    reports = db.query(Report).filter(Report.patient_code == patient_code.upper()).order_by(Report.timestamp.desc()).all()
    submissions = db.query(Submission).filter(Submission.patient_code == patient_code.upper()).order_by(Submission.timestamp.desc()).all()

    return {
        "patient_code": patient_code.upper(),
        "patient_name": patient.full_name,
        "bills": [
            {
                "id": b.id,
                "amount": b.amount,
                "bill_type": b.bill_type,
                "description": b.description,
                "submitted_by": b.submitted_by,
                "timestamp": b.timestamp.isoformat()
            } for b in bills
        ],
        "reports": [
            {
                "id": r.id,
                "report_type": r.report_type,
                "content": r.content,
                "submitted_by": r.submitted_by,
                "timestamp": r.timestamp.isoformat()
            } for r in reports
        ],
        "submissions": [_format_submission(s, full=True) for s in submissions],
    }


@app.get("/api/patients/{patient_code}/prescriptions")
def get_prescriptions(
    patient_code: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    """Get all prescriptions for a patient (reports where report_type='prescription')."""
    patient = db.query(User).filter(User.patient_code == patient_code.upper()).first()
    if not patient:
        raise HTTPException(404, f"Patient {patient_code} not found.")

    prescriptions = db.query(Report).filter(
        Report.patient_code == patient_code.upper(),
        Report.report_type == "prescription"
    ).order_by(Report.timestamp.desc()).all()

    # Get adjudication results linked to these prescriptions
    submissions = db.query(Submission).filter(
        Submission.patient_code == patient_code.upper()
    ).all()

    return {
        "patient_code": patient_code.upper(),
        "patient_name": patient.full_name,
        "prescriptions": [
            {
                "id": r.id,
                "content": r.content,
                "submitted_by": r.submitted_by,
                "timestamp": r.timestamp.isoformat()
            } for r in prescriptions
        ],
        "adjudications": [_format_submission(s, full=True) for s in submissions],
    }


@app.post("/api/patients/{patient_code}/adjudicate")
def adjudicate_prescription(
    patient_code: str,
    req: AdjudicateRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role("insurer")),
):
    """
    Run the Neuro-Symbolic pipeline on a prescription.
    The insurer selects a prescription (report_id) and a payer policy.
    The system reads the prescription text and evaluates it against the policy.
    """
    logger.info(f"[ADJUDICATE] Insurer {current_user['sub']} adjudicating prescription {req.report_id} for {patient_code}")

    # Validate patient
    patient = db.query(User).filter(User.patient_code == patient_code.upper()).first()
    if not patient:
        raise HTTPException(404, f"Patient {patient_code} not found.")

    # Get the prescription
    prescription = db.query(Report).filter(Report.id == req.report_id).first()
    if not prescription:
        raise HTTPException(404, f"Prescription {req.report_id} not found.")
    if prescription.patient_code != patient_code.upper():
        raise HTTPException(400, "Prescription does not belong to this patient.")

    # Validate payer
    available_payers = {p["payer_id"] for p in _evaluator.list_payers()}
    if req.payer_id not in available_payers:
        raise HTTPException(400, f"Unknown payer_id: {req.payer_id}. Available: {available_payers}")

    payer_info = next(p for p in _evaluator.list_payers() if p["payer_id"] == req.payer_id)
    policy_context = (
        f"Payer: {payer_info['payer_name']}\n"
        f"Procedure: {payer_info['procedure_name']}\n"
        f"This authorization is for: {payer_info['description']}"
    )

    # Get medical history
    history = db.query(MedicalHistory).filter(
        MedicalHistory.patient_code == patient_code.upper()
    ).first()

    # ── STEP 1: NEURAL EXTRACTION ──
    logger.info("[ADJUDICATE] Running Neural Extraction on prescription text...")
    try:
        extractor = get_extractor()
        extracted_data = extractor.extract(
            clinical_notes=prescription.content,
            medical_history=history.history_text if history else None,
            policy_context=policy_context,
        )
    except Exception as e:
        logger.error(f"[ADJUDICATE] LLM extraction failed: {e}")
        raise HTTPException(502, f"LLM extraction failed: {str(e)}")

    # ── STEP 2: SYMBOLIC EVALUATION ──
    logger.info("[ADJUDICATE] Running Symbolic Rule Engine...")
    try:
        evaluation_result = _evaluator.evaluate(req.payer_id, extracted_data)
    except Exception as e:
        logger.error(f"[ADJUDICATE] Symbolic evaluation failed: {e}")
        raise HTTPException(500, f"Policy evaluation failed: {str(e)}")

    decision = evaluation_result["decision"]
    logger.info(f"[ADJUDICATE] Decision: {decision}")

    # ── STEP 3: SAVE SUBMISSION ──
    submission = Submission(
        id=str(uuid.uuid4()),
        patient_code=patient_code.upper(),
        doctor_id=prescription.submitted_by,
        insurer_id=req.payer_id,
        clinical_notes=prescription.content,
        extracted_data=json.dumps(extracted_data),
        audit_trail=json.dumps(evaluation_result),
        status=decision,
        timestamp=datetime.utcnow(),
    )
    db.add(submission)
    db.commit()

    is_approved = "SUBMISSION_READY" in decision or "APPROVED" in decision

    return {
        "submission_id": submission.id,
        "patient_code": patient_code.upper(),
        "patient_name": patient.full_name,
        "prescription_id": req.report_id,
        "payer": {
            "payer_id": req.payer_id,
            "payer_name": payer_info["payer_name"],
            "procedure_name": payer_info["procedure_name"],
        },
        "approved": is_approved,
        "status": decision,
        "extracted_data": extracted_data,
        "evaluation": evaluation_result,
        "reasoning": _build_reasoning(evaluation_result, is_approved),
        "timestamp": submission.timestamp.isoformat(),
    }


def _build_reasoning(evaluation: dict, approved: bool) -> str:
    """Build a human-readable explanation of why a prescription was approved or denied."""
    rules = evaluation.get("rule_results", {})
    passed = [r.replace("_", " ").title() for r, v in rules.items() if v.get("passed")]
    failed = [r.replace("_", " ").title() for r, v in rules.items() if not v.get("passed")]

    if approved:
        reason = f"APPROVED — All critical policy requirements satisfied. "
        if passed:
            reason += f"Passed checks: {', '.join(passed)}."
    else:
        reason = f"NOT APPROVED — Policy requirements not fully met. "
        if failed:
            reason += f"Failed checks: {', '.join(failed)}. "
        if passed:
            reason += f"Passed: {', '.join(passed)}."
    return reason


# ─── Frontend Static Files ──────────────────────────────────────────────────────
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")
if os.path.exists(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/")
    def serve_frontend():
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

    @app.get("/{path:path}")
    def serve_spa(path: str):
        """Catch-all for SPA — serve index.html for all non-API routes."""
        file_path = os.path.join(FRONTEND_DIR, path)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


# ─── Helper ────────────────────────────────────────────────────────────────────
def _format_submission(sub: Submission, full: bool = False) -> dict:
    """Convert a Submission ORM object to a JSON-serializable dict."""
    result = {
        "id": sub.id,
        "patient_code": sub.patient_code,
        "doctor_id": sub.doctor_id,
        "insurer_id": sub.insurer_id,
        "status": sub.status,
        "timestamp": sub.timestamp.isoformat() if sub.timestamp else None,
    }
    if full:
        result["clinical_notes"] = sub.clinical_notes
        result["extracted_data"] = json.loads(sub.extracted_data) if sub.extracted_data else None
        result["audit_trail"] = json.loads(sub.audit_trail) if sub.audit_trail else None
    return result


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
