import os
import sys

# Add the current directory to path
sys.path.insert(0, os.path.dirname(__file__))

from a2wsgi import ASGIMiddleware
from main import app

# Translate ASGI FastAPI app to WSGI for cPanel Phusion Passenger
application = ASGIMiddleware(app)
