"""
llm_extractor.py — The Neural Layer of the Medi-Guard AI Neuro-Symbolic Engine.

Responsibilities:
  - Accept unstructured clinical notes + patient medical history + target policy context
  - Use Google Gemini (gemini-2.5-flash) to extract a structured JSON object of medical entities
  - Return a validated Python dict; never make clinical decisions itself

This module deliberately does NOT evaluate or adjudicate. Its sole job is
fact extraction from text. All decision logic lives in policy_evaluator.py.
"""

import os
import json
import logging
import re
from typing import Optional

from google import genai
from google.genai import types as genai_types

logger = logging.getLogger("medi_guard.extractor")

# ─── Schema ─────────────────────────────────────────────────────────────────────
EXTRACTION_SCHEMA = {
    "primary_diagnosis": "string — full diagnosis name, e.g. 'Degenerative Disc Disease'",
    "primary_diagnosis_icd10": "string — ICD-10 code, e.g. 'M51.16'",
    "proposed_procedure": "string — procedure name, e.g. 'Lumbar Spinal Fusion L4-L5'",
    "proposed_procedure_cpt": "string — CPT code only, e.g. '22612'",
    "symptoms": "list[string] — each symptom as a separate string",
    "symptom_duration_weeks": "number — duration in weeks (integer or float). If months given, multiply by 4.33",
    "conservative_treatments_tried": "list[string] — each treatment tried",
    "bmi": "number — Body Mass Index value. null if not mentioned",
    "age": "number — patient age in years. null if not mentioned",
    "prior_auth_requested": "boolean — whether prior authorization is explicitly requested",
    "supporting_evidence": "string — any imaging, lab results, or specialist notes mentioned",
    "extraction_confidence": "string — LOW | MEDIUM | HIGH based on completeness of clinical notes"
}

SYSTEM_PROMPT = """You are a medical entity extraction AI for a prior authorization adjudication system.
Your ONLY job is to read clinical text and extract structured medical facts.
You MUST respond with a single valid JSON object and NOTHING ELSE — no markdown, no code blocks, no explanations.
If a field cannot be determined from the notes, set it to null.
Never invent or hallucinate information. If symptom duration is ambiguous, use the most conservative (lowest) estimate.
All CPT codes must be numeric strings without letters (e.g. "22612" not "CPT 22612").
All ICD-10 codes must follow standard format (e.g. "M51.16" not "M51 - Disc disorder").
"""


class LLMExtractor:
    """
    Neural Layer: Uses Google Gemini to extract structured clinical entities
    from unstructured clinical notes.

    Usage:
        extractor = LLMExtractor()
        result = extractor.extract(clinical_notes, medical_history, policy_context)
    """

    def __init__(self):
        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise EnvironmentError(
                "GOOGLE_API_KEY environment variable not set. "
                "Please set it before starting the server."
            )
        self.client = genai.Client(api_key=api_key)
        self.model_name = "gemini-2.0-flash"
        self.gen_config = genai_types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            temperature=0.1,
            top_p=0.9,
            max_output_tokens=2048,
            response_mime_type="application/json",
        )
        logger.info("[NEURAL] LLMExtractor initialized with gemini-2.0-flash")

    def extract(
        self,
        clinical_notes: str,
        medical_history: Optional[str] = None,
        policy_context: Optional[str] = None,
    ) -> dict:
        """
        Extract structured medical entities from clinical notes.

        Args:
            clinical_notes: Raw unstructured clinical text from the doctor/hospital/pharma.
            medical_history: Optional background history from MedicalHistory table.
            policy_context: Optional hint about which policy/procedure is being evaluated,
                            to guide code extraction.

        Returns:
            dict matching EXTRACTION_SCHEMA, with null for missing fields.

        Raises:
            ValueError: If the LLM returns malformed JSON after retries.
        """
        logger.info("[NEURAL] Starting entity extraction...")
        logger.debug(f"[NEURAL] Clinical notes length: {len(clinical_notes)} chars")

        # Build the user message
        parts = []

        if medical_history:
            parts.append(
                f"=== PATIENT MEDICAL HISTORY (background context) ===\n{medical_history}\n"
            )

        if policy_context:
            parts.append(
                f"=== TARGET POLICY CONTEXT (use to guide CPT/ICD selection) ===\n{policy_context}\n"
            )

        parts.append(
            f"=== CLINICAL NOTES TO EXTRACT FROM ===\n{clinical_notes}\n"
        )

        parts.append(
            f"\n=== EXTRACTION SCHEMA (return exactly these fields) ===\n"
            f"{json.dumps(EXTRACTION_SCHEMA, indent=2)}"
        )

        user_message = "\n".join(parts)

        # Call Gemini
        try:
            logger.info("[NEURAL] Calling Gemini API...")
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=user_message,
                config=self.gen_config,
            )
            raw_text = response.text.strip()
            logger.info("[NEURAL] Gemini response received.")
            logger.debug(f"[NEURAL] Raw response: {raw_text[:500]}...")
        except Exception as e:
            logger.error(f"[NEURAL] Gemini API call failed: {e}")
            raise RuntimeError(f"LLM API call failed: {e}") from e

        # Parse JSON
        extracted = self._parse_json_response(raw_text)

        # Post-process: normalize types
        extracted = self._normalize_extracted(extracted)

        logger.info(
            f"[NEURAL] Extraction complete. "
            f"Confidence: {extracted.get('extraction_confidence', 'UNKNOWN')}. "
            f"Diagnosis: {extracted.get('primary_diagnosis')} | "
            f"CPT: {extracted.get('proposed_procedure_cpt')} | "
            f"ICD-10: {extracted.get('primary_diagnosis_icd10')}"
        )

        return extracted

    def _parse_json_response(self, raw_text: str) -> dict:
        """
        Robustly parse JSON from LLM output.
        Handles cases where the model accidentally wraps in markdown code fences.
        """
        # Strip markdown code fences if present
        if raw_text.startswith("```"):
            raw_text = re.sub(r"^```(?:json)?\s*", "", raw_text)
            raw_text = re.sub(r"\s*```$", "", raw_text)

        try:
            return json.loads(raw_text)
        except json.JSONDecodeError as e:
            # Attempt to extract JSON from within the text
            json_match = re.search(r"\{.*\}", raw_text, re.DOTALL)
            if json_match:
                try:
                    return json.loads(json_match.group())
                except json.JSONDecodeError:
                    pass
            logger.error(f"[NEURAL] Failed to parse JSON: {e}\nRaw: {raw_text[:300]}")
            raise ValueError(f"LLM returned malformed JSON: {e}")

    def _normalize_extracted(self, data: dict) -> dict:
        """
        Normalize types: ensure numeric fields are numbers, lists are lists, etc.
        """
        # Ensure numeric fields
        for num_field in ["symptom_duration_weeks", "bmi", "age"]:
            val = data.get(num_field)
            if val is not None:
                try:
                    data[num_field] = float(val)
                except (TypeError, ValueError):
                    logger.warning(f"[NEURAL] Could not cast {num_field}={val!r} to float, setting null")
                    data[num_field] = None

        # Ensure list fields
        for list_field in ["symptoms", "conservative_treatments_tried"]:
            val = data.get(list_field)
            if val is None:
                data[list_field] = []
            elif isinstance(val, str):
                # Sometimes the model returns a comma-separated string
                data[list_field] = [v.strip() for v in val.split(",") if v.strip()]

        # Ensure boolean
        if "prior_auth_requested" in data:
            data["prior_auth_requested"] = bool(data["prior_auth_requested"])

        # Ensure CPT is a string (strip non-digits except decimal point... actually CPTs are 5-digit integers)
        cpt = data.get("proposed_procedure_cpt")
        if cpt:
            cpt_cleaned = re.sub(r"[^\d]", "", str(cpt))
            data["proposed_procedure_cpt"] = cpt_cleaned if cpt_cleaned else None

        return data
