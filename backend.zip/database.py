"""
database.py — SQLAlchemy models and database initialization for Medi-Guard AI.
Creates an SQLite database at ./medi_guard.db on first run.
"""

import os
import uuid
import random
import string
from datetime import datetime

from sqlalchemy import create_engine, Column, String, Text, Integer, DateTime, Float
from sqlalchemy.orm import declarative_base, sessionmaker, Session

# ─── Engine & Session ───────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_URL = f"sqlite:///{os.path.join(BASE_DIR, 'medi_guard.db')}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# ─── Models ────────────────────────────────────────────────────────────────────

class User(Base):
    """
    All users across every role live in this single table.
    Roles: doctor | insurer | patient | hospital | pharma
    patient_code is a unique human-readable ID, e.g. PT-B4X9Q1, generated only for patients.
    phone_number is the patient's unique identity anchor — one phone = one permanent patient code.
    organization_name is used by insurer, hospital, pharma to scope dashboard queries.
    """
    __tablename__ = "users"

    username         = Column(String, primary_key=True, index=True)
    role             = Column(String, nullable=False)          # doctor | insurer | patient | hospital | pharma
    password_hash    = Column(String, nullable=False)
    full_name        = Column(String, nullable=False)
    patient_code     = Column(String, unique=True, nullable=True)   # Only set for patients
    phone_number     = Column(String, unique=True, nullable=True)   # Unique phone for patients
    organization_name = Column(String, nullable=True)               # Insurer / hospital / pharma org


class MedicalHistory(Base):
    """
    Background medical context for a patient, used to augment the LLM extraction prompt.
    """
    __tablename__ = "medical_history"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    patient_code = Column(String, nullable=False, index=True)
    history_text = Column(Text, nullable=False)


class Submission(Base):
    """
    Each prior-authorization submission record.
    extracted_data and audit_trail are stored as JSON strings.
    status: SUBMISSION_READY | NEEDS_MORE_EVIDENCE | REJECTED | APPROVED_OVERRIDE | DENIED_OVERRIDE
    """
    __tablename__ = "submissions"

    id             = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_code   = Column(String, nullable=False, index=True)
    doctor_id      = Column(String, nullable=False)     # username of submitting doctor/hospital/pharma
    insurer_id     = Column(String, nullable=False)     # payer_id string (e.g. "starhealth_spinal_fusion")
    clinical_notes = Column(Text, nullable=False)
    extracted_data = Column(Text, nullable=True)        # JSON string from LLM extractor
    audit_trail    = Column(Text, nullable=True)        # JSON string from policy evaluator
    status         = Column(String, nullable=False, default="PENDING")
    timestamp      = Column(DateTime, default=datetime.utcnow)


class Bill(Base):
    """
    Financial bills submitted by hospitals or pharmacies.
    bill_type: inpatient | outpatient | pharmacy
    """
    __tablename__ = "bills"

    id             = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_code   = Column(String, nullable=False, index=True)
    submitted_by   = Column(String, nullable=False) # username of hospital/pharma
    amount         = Column(Float, nullable=False)
    bill_type      = Column(String, nullable=False)
    description    = Column(Text, nullable=False)
    timestamp      = Column(DateTime, default=datetime.utcnow)


class Report(Base):
    """
    Medical reports submitted by hospitals (e.g. labs, imaging, discharge summaries).
    """
    __tablename__ = "reports"

    id             = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_code   = Column(String, nullable=False, index=True)
    submitted_by   = Column(String, nullable=False) # username of hospital
    report_type    = Column(String, nullable=False)
    content        = Column(Text, nullable=False)
    timestamp      = Column(DateTime, default=datetime.utcnow)


# ─── Helpers ───────────────────────────────────────────────────────────────────

def generate_patient_code() -> str:
    """Generate a unique, human-readable patient code like PT-B4X9Q1."""
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"PT-{suffix}"


def init_db():
    """Create all tables if they do not already exist."""
    Base.metadata.create_all(bind=engine)


def get_db() -> Session:
    """FastAPI dependency: yield a DB session and close it after the request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
